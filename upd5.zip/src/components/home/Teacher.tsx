"use client";

import Image from "next/image";
import { Quote } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { CountUp } from "@/components/ui/CountUp";
import styles from "./Teacher.module.css";

const STATS = [
  { value: <span>2009</span>, label: "преподаёт английский в лицее «Orizont», Чадыр-Лунга", small: "с" },
  { value: <CountUp to={10} />, label: "учеников первой группы из Гагаузии сдали кембриджский экзамен" },
  { value: <CountUp to={9.75} decimals={2} />, label: "средний балл BAC по английскому — лучший результат в Гагаузии" },
];

export function Teacher() {
  return (
    <section id="teacher" className="section">
      <div className={`container ${styles.layout}`}>
        <Reveal className={styles.photoCol}>
          <figure className={styles.photo}>
            <Image
              src="/images/elena.jpg"
              alt="Елена Каранфил"
              fill
              sizes="(min-width: 1024px) 480px, 100vw"
              quality={95}
              priority
              className={styles.img}
            />
            <figcaption className={styles.caption}>
              <span className={styles.capName}>Елена Каранфил</span>
              <span className={styles.capRole}>Автор методики · тренер IELTS</span>
            </figcaption>
          </figure>
        </Reveal>

        <div className={styles.copy}>
          <Reveal>
            <span className={styles.eyebrow}>Преподаватель</span>
          </Reveal>
          <Reveal delay={0.06}>
            <h2 className={styles.title}>
              Методика, которая <span className="gradient-text">уже работает.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.12}>
            <p className={styles.lead}>
              Елена соединяет программу Cambridge с цифровыми платформами и превращает интерес
              учеников к смартфонам в ежедневную практику английского. Прошла международную
              программу подготовки тренеров IELTS — единственной участницей из Молдовы в своём
              потоке.
            </p>
          </Reveal>

          <Reveal delay={0.18}>
            <blockquote className={styles.quote}>
              <Quote size={20} className={styles.quoteIcon} aria-hidden="true" />
              Цель моей работы — показать, что образование может быть нескучным.
            </blockquote>
          </Reveal>

          <div className={styles.stats}>
            {STATS.map((s, i) => (
              <Reveal key={i} delay={0.2 + i * 0.08} className={styles.stat}>
                <span className={styles.statValue}>
                  {s.small && <small>{s.small}</small>}
                  {s.value}
                </span>
                <span className={styles.statLabel}>{s.label}</span>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
