import type { Metadata, Viewport } from "next";
import { IBM_Plex_Sans, Playfair_Display } from "next/font/google";
import { BackgroundAura } from "@/components/layout/BackgroundAura";
import { AuthProvider } from "@/lib/auth";
import "@/styles/globals.css";

// Заголовки — Playfair Display (британская антиква с кириллицей), текст — IBM Plex Sans
const playfair = Playfair_Display({
  subsets: ["latin", "cyrillic"],
  weight: ["500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-playfair",
  display: "swap",
});

const plex = IBM_Plex_Sans({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600"],
  variable: "--font-plex",
  display: "swap",
});

export const metadata: Metadata = {
  title: "FCE B2 Prep — подготовка к Cambridge B2 First",
  description:
    "Платформа подготовки к экзамену Cambridge B2 First: задания в формате экзамена, проверка с объяснениями и прогресс по каждому навыку.",
};

export const viewport: Viewport = {
  themeColor: "#0F1724",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className={`${playfair.variable} ${plex.variable}`}>
      <body>
        <BackgroundAura />
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
