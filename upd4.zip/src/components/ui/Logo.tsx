import Link from "next/link";
import { UnionJack } from "./UnionJack";
import styles from "./Logo.module.css";

/** Знак: флаг Великобритании и название платформы. */
export function Logo() {
  return (
    <Link href="/" className={styles.logo} aria-label="FCE B2 Prep — на главную">
      <span className={styles.mark}>
        <UnionJack width={34} />
      </span>
      <span className={styles.word}>
        FCE B2 <span className={styles.muted}>Prep</span>
      </span>
    </Link>
  );
}
