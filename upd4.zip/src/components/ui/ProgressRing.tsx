"use client";

import { motion, useInView } from "framer-motion";
import { useId, useRef, type ReactNode } from "react";
import { ease } from "@/lib/motion";

interface Props {
  value: number; // 0–100
  size?: number;
  stroke?: number;
  colors?: [string, string];
  children?: ReactNode;
  delay?: number;
}

/** Круговой индикатор с градиентной дугой и анимацией заполнения. */
export function ProgressRing({
  value,
  size = 96,
  stroke = 8,
  colors = ["#d9a84e", "#d9a84e"],
  children,
  delay = 0,
}: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.5 });
  const id = useId().replace(/:/g, "");
  const r = (size - stroke) / 2;
  const c = size / 2;

  return (
    <div ref={ref} style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: "rotate(-90deg)" }}>
        <defs>
          <linearGradient id={`ring-${id}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={colors[0]} />
            <stop offset="100%" stopColor={colors[0]} />
          </linearGradient>
        </defs>
        <circle cx={c} cy={c} r={r} fill="none" stroke="rgba(148,163,184,0.12)" strokeWidth={stroke} />
        <motion.circle
          cx={c}
          cy={c}
          r={r}
          fill="none"
          stroke={`url(#ring-${id})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={inView ? { pathLength: Math.max(0.001, value / 100) } : undefined}
          transition={{ duration: 1.6, ease: ease.out, delay }}
          style={{ filter: `drop-shadow(0 0 3px ${colors[0]}40)`, opacity: value > 0 ? 1 : 0 }}
        />
      </svg>
      {children && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "grid",
            placeItems: "center",
            textAlign: "center",
          }}
        >
          {children}
        </div>
      )}
    </div>
  );
}
