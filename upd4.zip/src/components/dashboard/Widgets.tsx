"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  Flame,
  PenLine,
  Target,
  TrendingUp,
  Trophy,
  CalendarDays,
  Sparkles,
  Timer,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/Button";
import { CountUp } from "@/components/ui/CountUp";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { EmptyState } from "@/components/ui/EmptyState";
import { demoUser, paperProgress, recentAttempts, type AttemptStatus } from "@/data/demo";
import { TASKS, taskHref } from "@/data/tasks";
import { bestBySlug, formatDate, formatDuration, percent, type Attempt } from "@/lib/history";
import { useHistory, useUser } from "@/lib/useLocalData";
import { useAuth } from "@/lib/auth";
import { CRITERIA, fetchMyReviews, reviewTotal } from "@/lib/cloud";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./Dashboard.module.css";

/* ------------------------------------------------------------------ */
/* Каскадное появление виджетов                                        */
/* ------------------------------------------------------------------ */

export function Appear({ children, i = 0, className }: { children: React.ReactNode; i?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: ease.out, delay: 0.05 + i * 0.06 }}
    >
      {children}
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/* Приветствие                                                         */
/* ------------------------------------------------------------------ */

function greetingFor(h: number) {
  if (h < 5) return "Доброй ночи";
  if (h < 12) return "Доброе утро";
  if (h < 18) return "Добрый день";
  return "Добрый вечер";
}

export function Greeting() {
  const user = useUser();
  const [info, setInfo] = useState<{ greet: string; days: number } | null>(null);

  useEffect(() => {
    const now = new Date();
    const exam = new Date(user.examDate + "T09:00:00");
    const days = Math.max(0, Math.ceil((exam.getTime() - now.getTime()) / 86_400_000));
    setInfo({ greet: greetingFor(now.getHours()), days });
  }, [user.examDate]);

  return (
    <div className={styles.greeting}>
      <div>
        <h1 className={styles.hello}>
          {info ? info.greet : "Здравствуйте"}, <span className="gradient-text">{user.firstName}</span>
        </h1>
        <p className={styles.helloSub}>
          <CalendarDays size={16} />
          {info ? (
            <>
              До экзамена <strong>{info.days} дн.</strong> · цель {user.targetScore}+ по шкале Cambridge ·{" "}
              <Link href="/settings" className={styles.inlineLink}>
                изменить
              </Link>
            </>
          ) : (
            <span className="skeleton" style={{ display: "inline-block", width: 260, height: 16 }} />
          )}
        </p>
      </div>
      <Button href="/practice" magnetic iconRight={<ArrowRight size={17} />}>
        Все задания
      </Button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Карточки статистики                                                 */
/* ------------------------------------------------------------------ */

interface Stat {
  label: string;
  icon: LucideIcon;
  value: number;
  suffix?: string;
  delta?: string;
  hint: string;
  tone: "violet" | "blue" | "cyan" | "amber";
}

const DEMO_STATS: Stat[] = [
  { label: "Прогноз балла", icon: Target, value: 172, delta: "+2", hint: "за неделю · B2", tone: "violet" },
  { label: "Выполнено заданий", icon: BadgeCheck, value: 128, delta: "+14", hint: "за неделю", tone: "blue" },
  { label: "Точность ответов", icon: TrendingUp, value: 76, suffix: "%", delta: "+3%", hint: "к прошлой неделе", tone: "cyan" },
  { label: "Серия занятий", icon: Flame, value: 9, suffix: " дн.", delta: "рекорд 14", hint: "", tone: "amber" },
];

/** Серия: сколько дней подряд (до сегодня/вчера) были занятия. */
function streak(history: Attempt[]) {
  const days = new Set(history.map((a) => a.date.slice(0, 10)));
  let n = 0;
  const d = new Date();
  if (!days.has(d.toISOString().slice(0, 10))) d.setDate(d.getDate() - 1);
  while (days.has(d.toISOString().slice(0, 10))) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}

function realStats(history: Attempt[]): Stat[] {
  const quiz = history.filter((a) => a.kind === "quiz" && a.total);
  const correct = quiz.reduce((s, a) => s + (a.correct ?? 0), 0);
  const total = quiz.reduce((s, a) => s + (a.total ?? 0), 0);
  const acc = total ? Math.round((correct / total) * 100) : 0;
  const best = bestBySlug(history);
  const covered = TASKS.filter((t) => best.has(t.slug)).length;
  const minutes = Math.round(history.reduce((s, a) => s + a.seconds, 0) / 60);
  return [
    { label: "Пройдено заданий", icon: BadgeCheck, value: covered, suffix: ` из ${TASKS.length}`, hint: "разных тестов", tone: "violet" },
    { label: "Точность ответов", icon: TrendingUp, value: acc, suffix: "%", hint: `${correct} из ${total} верно`, tone: "cyan" },
    { label: "Время практики", icon: Target, value: minutes, suffix: " мин", hint: `${history.length} попыток`, tone: "blue" },
    { label: "Серия занятий", icon: Flame, value: streak(history), suffix: " дн.", hint: "подряд", tone: "amber" },
  ];
}

export function StatCards() {
  const history = useHistory();
  const stats = history && history.length ? realStats(history) : DEMO_STATS;
  return (
    <div className={styles.stats}>
      {stats.map((s, i) => {
        const Icon = s.icon;
        return (
          <Appear key={s.label} i={i + 1}>
            <div className={cn(styles.panel, styles.stat)}>
              <div className={styles.statTop}>
                <span className={styles.statLabel}>{s.label}</span>
                <span className={cn(styles.statIcon, styles[s.tone])}>
                  <Icon size={17} strokeWidth={2} />
                </span>
              </div>
              <div className={styles.statValue}>
                <CountUp key={`${s.label}${s.value}`} to={s.value} suffix={s.suffix} />
              </div>
              <div className={styles.statFoot}>
                {s.delta && (
                  <span className={styles.delta}>
                    <ArrowUpRight size={13} />
                    {s.delta}
                  </span>
                )}
                {s.hint && <span>{s.hint}</span>}
              </div>
            </div>
          </Appear>
        );
      })}
    </div>
  );
}

/** Плашка демо-режима, пока у пользователя нет ни одной попытки. */
export function DemoNotice() {
  const history = useHistory();
  if (!history || history.length) return null;
  return (
    <div className={styles.notice}>
      <Sparkles size={18} />
      <p>
        <strong>Это пример кабинета с демо-данными.</strong> Пройдите первое задание — статистика и таблица начнут
        считаться по вашим результатам.
      </p>
      <Link href={taskHref(TASKS[0].slug)} className={styles.noticeLink}>
        Начать <ArrowRight size={14} />
      </Link>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Продолжить обучение                                                 */
/* ------------------------------------------------------------------ */

export function ContinueCard() {
  const history = useHistory();
  const pick = useMemo(() => {
    const best = bestBySlug(history ?? []);
    const next = TASKS.find((t) => !best.has(t.slug));
    if (next) return { task: next, last: null as Attempt | null };
    // всё пройдено — предлагаем задание с самым низким результатом
    const weakest = [...TASKS]
      .filter((t) => t.kind === "quiz")
      .sort((x, y) => (percent(best.get(x.slug)!) ?? 0) - (percent(best.get(y.slug)!) ?? 0))[0];
    return { task: weakest, last: best.get(weakest.slug) ?? null };
  }, [history]);

  const { task, last } = pick;
  const pct = last ? percent(last) ?? 0 : 0;
  const count = task.kind === "quiz" ? `${task.items.length} вопросов` : task.kind === "speaking" ? `${task.stages.length} этапов` : `${task.minWords}–${task.maxWords} слов`;

  return (
    <div className={cn(styles.panel, styles.continue)}>
      <div className={styles.continueGlow} aria-hidden="true" />
      <span className={styles.kicker}>{last ? "Подтянуть слабое место" : "Следующее задание"}</span>
      <div className={styles.continueBody}>
        <div>
          <span className={styles.chip}>
            {task.paper.replace("Reading & ", "")} · {task.part}
          </span>
          <h3 className={styles.continueTitle}>{task.title}</h3>
          <p className={styles.continueMeta}>
            {task.type} · {count} · ≈ {task.minutes} мин
          </p>
        </div>
        <ProgressRing value={pct} size={84} stroke={7}>
          <span className={styles.ringSmall}>
            {last && last.total ? `${last.correct}/${last.total}` : "—"}
            <small>{last ? "лучший" : "не начато"}</small>
          </span>
        </ProgressRing>
      </div>

      <p className={styles.preview}>{task.summary}. {task.instruction}</p>

      <Link href={taskHref(task.slug)} className={styles.continueBtn}>
        {last ? "Пройти ещё раз" : "Начать задание"}
        <ArrowRight size={16} />
      </Link>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Кольца по частям экзамена                                           */
/* ------------------------------------------------------------------ */

const SKILL_RING: Record<string, { short: string; colors: [string, string] }> = {
  rue: { short: "Reading & UoE", colors: ["#d9a84e", "#e0b866"] },
  writing: { short: "Writing", colors: ["#8fa3c4", "#b3c1d8"] },
  listening: { short: "Listening", colors: ["#d9a84e", "#e6c98f"] },
  speaking: { short: "Speaking", colors: ["#e0b866", "#d9a84e"] },
};

/** Готовность по истории: точность для частей с автопроверкой, доля выполненного — для Writing и Speaking. */
function realRings(history: Attempt[]) {
  const best = bestBySlug(history);
  return (["rue", "writing", "listening", "speaking"] as const).map((skill) => {
    const tasks = TASKS.filter((t) => t.skill === skill);
    const done = tasks.filter((t) => best.has(t.slug));
    if (skill === "rue" || skill === "listening") {
      const scores = done.map((t) => percent(best.get(t.slug)!) ?? 0);
      const value = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
      return { key: skill, value, sub: `${done.length} из ${tasks.length} частей`, accuracy: true, started: done.length > 0 };
    }
    const value = Math.round((done.length / tasks.length) * 100);
    return { key: skill, value, sub: `выполнено ${done.length} из ${tasks.length}`, accuracy: false, started: done.length > 0 };
  });
}

export function PaperRings() {
  const history = useHistory();
  const real = !!history && history.length > 0;
  const rings = real
    ? realRings(history!)
    : paperProgress.map((p) => ({ key: p.key, value: p.value, sub: "пример", accuracy: true, started: true }));
  const scored = rings.filter((r) => r.accuracy && r.started);
  const max = scored.length > 1 ? Math.max(...scored.map((r) => r.value)) : -1;
  const min = scored.length > 1 ? Math.min(...scored.map((r) => r.value)) : -1;

  return (
    <div className={styles.panel}>
      <div className={styles.panelHead}>
        <div>
          <h3 className={styles.panelTitle}>
            Готовность по частям экзамена {!real && <span className={styles.exampleTag}>пример</span>}
          </h3>
          <p className={styles.panelSub}>
            {real
              ? "Reading и Listening — средняя точность лучших попыток; Writing и Speaking — сколько заданий выполнено"
              : "Начнёт считаться после первых заданий"}
          </p>
        </div>
        <Link href="/mock" className={styles.linkMuted}>
          <Timer size={15} /> Пробный экзамен
        </Link>
      </div>
      <div className={styles.rings}>
        {rings.map((r, i) => {
          const meta = SKILL_RING[r.key];
          return (
            <div key={r.key} className={styles.ringItem}>
              <ProgressRing value={r.value} size={112} stroke={9} colors={meta.colors} delay={i * 0.12}>
                <span className={styles.ringValue}>
                  <CountUp key={`${r.key}${r.value}`} to={r.value} suffix="%" />
                </span>
              </ProgressRing>
              <span className={styles.ringName}>{meta.short}</span>
              {real && <span className={styles.ringSub}>{r.sub}</span>}
              {r.accuracy && r.value === max && <span className={cn(styles.ringTag, styles.tagGood)}>Сильная сторона</span>}
              {r.accuracy && r.value === min && <span className={cn(styles.ringTag, styles.tagWarn)}>Нужно внимание</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Таблица успеваемости                                                */
/* ------------------------------------------------------------------ */

const STATUS: Record<AttemptStatus, { label: string; cls: string }> = {
  excellent: { label: "Отлично", cls: styles.stExcellent },
  good: { label: "Хорошо", cls: styles.stGood },
  review: { label: "Повторить", cls: styles.stReview },
};

function realRows(history: Attempt[]) {
  return history.slice(0, 5).map((a, i) => {
    const pct = percent(a);
    const status: AttemptStatus = pct == null ? "good" : pct >= 80 ? "excellent" : pct >= 55 ? "good" : "review";
    return {
      id: `${a.slug}-${i}`,
      date: formatDate(a.date),
      paper: a.paper.replace("Reading & ", ""),
      part: `${a.part} · ${a.title}`,
      score: a.correct ?? (a.kind === "writing" ? a.words ?? 0 : a.answered ?? 0),
      total: a.total ?? 0,
      label: a.kind === "writing" ? `${a.words} сл.` : a.kind === "speaking" ? `${a.answered} отв.` : null,
      time: formatDuration(a.seconds),
      status,
    };
  });
}

export function AttemptsTable() {
  const history = useHistory();
  const real = !!history && history.length > 0;
  const rows = real
    ? realRows(history!)
    : recentAttempts.map((a) => ({ ...a, label: null as string | null }));
  return (
    <div className={styles.panel}>
      <div className={styles.panelHead}>
        <div>
          <h3 className={styles.panelTitle}>Последние результаты</h3>
          <p className={styles.panelSub}>{real ? "Ваши последние попытки" : "Пример — пока у вас нет попыток"}</p>
        </div>
        <Link href="/results" className={styles.linkMuted}>
          <Trophy size={15} /> Вся история
        </Link>
      </div>
      <div className={styles.tableWrap}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Задание</th>
              <th>Результат</th>
              <th>Время</th>
              <th>Статус</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((a, i) => {
              const pct = a.total ? (a.score / a.total) * 100 : 100;
              return (
                <motion.tr
                  key={a.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, ease: ease.out, delay: 0.4 + i * 0.06 }}
                >
                  <td>
                    <span className={styles.tdMain}>{a.paper}</span>
                    <span className={styles.tdSub}>
                      {a.part} · {a.date}
                    </span>
                  </td>
                  <td>
                    <div className={styles.scoreCell}>
                      <span className={styles.scoreNum}>{a.label ?? `${a.score}/${a.total}`}</span>
                      <span className={styles.miniTrack}>
                        <motion.span
                          className={styles.miniFill}
                          initial={{ width: 0 }}
                          animate={{ width: `${pct}%` }}
                          transition={{ duration: 1, ease: ease.out, delay: 0.6 + i * 0.06 }}
                        />
                      </span>
                    </div>
                  </td>
                  <td className={styles.tdTime}>{a.time}</td>
                  <td>
                    <span className={cn(styles.status, STATUS[a.status].cls)}>{STATUS[a.status].label}</span>
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Writing: пустое состояние                                           */
/* ------------------------------------------------------------------ */

export function WritingFeedback() {
  const { cloud, session } = useAuth();
  const history = useHistory();
  const [reviews, setReviews] = useState<Awaited<ReturnType<typeof fetchMyReviews>> | null>(null);

  useEffect(() => {
    if (!cloud || !session) return;
    fetchMyReviews()
      .then(setReviews)
      .catch(() => setReviews([]));
  }, [cloud, session]);

  const essays = (history ?? []).filter((a) => a.kind === "writing");
  const reviewed = new Set((reviews ?? []).map((r) => r.attempt_id));
  const waiting = essays.filter((e) => e.id && !reviewed.has(e.id)).length;

  return (
    <div className={cn(styles.panel, styles.fill)}>
      <div className={styles.panelHead}>
        <div>
          <h3 className={styles.panelTitle}>Отзывы на Writing</h3>
          <p className={styles.panelSub}>
            Проверка эссе преподавателем{waiting ? ` · ждут проверки: ${waiting}` : ""}
          </p>
        </div>
      </div>
      {reviews && reviews.length > 0 ? (
        <ul className={styles.reviews}>
          {reviews.slice(0, 3).map((r) => (
            <li key={r.id} className={styles.reviewItem}>
              <div className={styles.reviewTop}>
                <span>
                  <strong>{r.attempt.part}</strong> · {r.attempt.title}
                </span>
                <span className={styles.reviewScore}>{reviewTotal(r)}/20</span>
              </div>
              <div className={styles.reviewBars}>
                {CRITERIA.map((c) => (
                  <span key={c.key} title={`${c.label}: ${r[c.key]}/5`}>
                    <i style={{ width: `${(r[c.key] / 5) * 100}%` }} />
                  </span>
                ))}
              </div>
              {r.comment && <p className={styles.reviewComment}>«{r.comment}»</p>}
              <span className={styles.reviewDate}>{formatDate(r.created_at)}</span>
            </li>
          ))}
        </ul>
      ) : (
        <EmptyState
          icon={<PenLine size={22} />}
          title={waiting ? "Работы на проверке" : "Пока нет проверенных работ"}
          text={
            waiting
              ? "Преподаватель оценит эссе по четырём критериям Cambridge — оценка и комментарий появятся здесь."
              : cloud && session
                ? "Напишите эссе в тренажёре — оно уйдёт преподавателю на проверку."
                : "Войдите в аккаунт, чтобы отправлять эссе преподавателю. Пока доступна самопроверка."
          }
          action={
            <Button href="/practice/writing-part-1" variant="secondary" size="sm">
              Написать эссе
            </Button>
          }
        />
      )}
    </div>
  );
}
