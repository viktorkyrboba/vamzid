"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useRef, useState, type PointerEvent } from "react";
import { scoreHistory } from "@/data/demo";
import { formatDate, percent } from "@/lib/history";
import { useHistory, useUser } from "@/lib/useLocalData";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./Dashboard.module.css";

const W = 640;
const H = 260;
const PAD = { l: 40, r: 18, t: 18, b: 34 };
const RANGES = [4, 8, 12] as const;

interface Point {
  label: string;
  value: number;
  hint?: string;
}

interface Scale {
  min: number;
  max: number;
  ticks: number[];
  band?: { from: number; to: number; label: string };
  target?: { value: number; label: string };
  unit: string;
}

/** Сглаженная кривая через точки (Catmull-Rom → Bézier). */
function smoothPath(pts: Array<[number, number]>) {
  if (pts.length < 2) return "";
  // контрольные точки не выходят за область графика (без «выгиба» выше 100%)
  const cl = (v: number) => Math.min(H - PAD.b, Math.max(PAD.t, v));
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] ?? pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] ?? p2;
    const t = 0.18;
    d += ` C ${p1[0] + (p2[0] - p0[0]) * t} ${cl(p1[1] + (p2[1] - p0[1]) * t)}, ${p2[0] - (p3[0] - p1[0]) * t} ${cl(p2[1] - (p3[1] - p1[1]) * t)}, ${p2[0]} ${p2[1]}`;
  }
  return d;
}

export function ScoreChart() {
  const history = useHistory();
  const user = useUser();
  const [range, setRange] = useState<(typeof RANGES)[number]>(12);
  const [hover, setHover] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // реальные данные: точность каждой попытки с автопроверкой, по времени
  const quiz = (history ?? []).filter((a) => a.kind === "quiz" && a.total).slice().reverse();
  const manyDays = new Set(quiz.map((a) => a.date.slice(0, 10))).size > 1;
  const real: Point[] = quiz.map((a, i) => ({
    label: manyDays ? formatDate(a.date) : `№${i + 1}`,
    value: percent(a) ?? 0,
    hint: `${a.paper.replace("Reading & ", "")} · ${a.part} · ${formatDate(a.date)}`,
  }));
  const isReal = real.length >= 2;

  const all: Point[] = isReal ? real : scoreHistory.map((d) => ({ label: d.week, value: d.score }));
  const data = all.slice(-range);

  const scale: Scale = isReal
    ? {
        min: 0,
        max: 100,
        ticks: [0, 25, 50, 75, 100],
        band: { from: 60, to: 100, label: "B2 · от 60%" },
        target: { value: 75, label: "Уверенный B2 · 75%" },
        unit: "%",
      }
    : {
        min: 140,
        max: 186,
        ticks: [140, 150, 160, 170, 180],
        band: { from: 160, to: 179, label: "B2 · 160–179" },
        target: { value: user.targetScore, label: `Цель ${user.targetScore}` },
        unit: "",
      };

  const y = (v: number) => PAD.t + (1 - (v - scale.min) / (scale.max - scale.min)) * (H - PAD.t - PAD.b);
  const step = data.length > 1 ? (W - PAD.l - PAD.r) / (data.length - 1) : 0;
  const x = (i: number) => PAD.l + i * step;
  const pts = data.map((d, i) => [x(i), y(d.value)] as [number, number]);
  const line = smoothPath(pts);
  const area = pts.length ? `${line} L ${pts[pts.length - 1][0]} ${H - PAD.b} L ${pts[0][0]} ${H - PAD.b} Z` : "";

  const onMove = (e: PointerEvent<SVGRectElement>) => {
    const svg = svgRef.current;
    if (!svg || !step) return;
    const rect = svg.getBoundingClientRect();
    const sx = ((e.clientX - rect.left) / rect.width) * W;
    setHover(Math.max(0, Math.min(data.length - 1, Math.round((sx - PAD.l) / step))));
  };

  const first = data[0]?.value ?? 0;
  const last = data[data.length - 1]?.value ?? 0;
  const delta = last - first;
  const labelEvery = data.length > 8 ? 2 : 1;
  const active = hover ?? data.length - 1;

  return (
    <div className={cn(styles.panel, styles.chartPanel)}>
      <div className={styles.panelHead}>
        <div>
          <h3 className={styles.panelTitle}>
            {isReal ? "Точность по попыткам" : "Прогноз балла"}{" "}
            {!isReal && <span className={styles.exampleTag}>пример</span>}
          </h3>
          <p className={styles.panelSub}>
            {isReal ? "Задания с автопроверкой" : "Cambridge English Scale"} ·{" "}
            <span className={delta >= 0 ? styles.up : styles.down}>
              {delta >= 0 ? "+" : ""}
              {delta}
              {scale.unit}
            </span>{" "}
            за {data.length} {isReal ? "попыт." : "недель"}
          </p>
        </div>
        <div className={styles.segmented} role="tablist" aria-label="Период">
          {RANGES.map((r) => (
            <button
              key={r}
              role="tab"
              aria-selected={range === r}
              className={cn(styles.segBtn, range === r && styles.segActive)}
              onClick={() => {
                setRange(r);
                setHover(null);
              }}
            >
              {range === r && (
                <motion.span layoutId="range-pill" className={styles.segPill} transition={{ type: "spring", stiffness: 420, damping: 34 }} />
              )}
              <span>
                {r} {isReal ? "попыт." : "нед."}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className={styles.chartWrap}>
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className={styles.chart} role="img" aria-label={`График: от ${first} до ${last}`}>
          <defs>
            <linearGradient id="chart-line" x1="0" x2="1" y1="0" y2="0">
              <stop offset="0%" stopColor="#d9a84e" />
              <stop offset="100%" stopColor="#d9a84e" />
            </linearGradient>
            <linearGradient id="chart-area" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#d9a84e" stopOpacity="0.12" />
              <stop offset="100%" stopColor="#8fa3c4" stopOpacity="0" />
            </linearGradient>
          </defs>

          {scale.band && (
            <>
              <rect
                x={PAD.l}
                y={y(Math.min(scale.band.to, scale.max))}
                width={W - PAD.l - PAD.r}
                height={y(scale.band.from) - y(Math.min(scale.band.to, scale.max))}
                fill="rgba(217, 168, 78,0.05)"
              />
              <text x={W - PAD.r - 8} y={y(scale.band.from) + 16} textAnchor="end" className={styles.bandLabel}>
                {scale.band.label}
              </text>
            </>
          )}

          {scale.ticks.map((v) => (
            <g key={v}>
              <line x1={PAD.l} x2={W - PAD.r} y1={y(v)} y2={y(v)} stroke="rgba(148,163,184,0.08)" />
              <text x={PAD.l - 10} y={y(v) + 4} textAnchor="end" className={styles.axisLabel}>
                {v}
              </text>
            </g>
          ))}

          {scale.target && (
            <>
              <line x1={PAD.l} x2={W - PAD.r} y1={y(scale.target.value)} y2={y(scale.target.value)} stroke="#d9a84e" strokeOpacity="0.55" strokeDasharray="4 6" />
              <text x={PAD.l + 6} y={y(scale.target.value) - 7} className={styles.targetLabel}>
                {scale.target.label}
              </text>
            </>
          )}

          <AnimatePresence mode="wait">
            <motion.g key={`${range}-${isReal}`} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
              <motion.path d={area} fill="url(#chart-area)" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, ease: ease.out, delay: 0.3 }} />
              <motion.path
                d={line}
                fill="none"
                stroke="url(#chart-line)"
                strokeWidth={2.5}
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.3, ease: ease.out }}
                style={{ filter: "drop-shadow(0 4px 12px rgba(217, 168, 78,0.45))" }}
              />
            </motion.g>
          </AnimatePresence>

          {data.map((d, i) =>
            i % labelEvery === 0 || i === data.length - 1 ? (
              <text key={i} x={x(i)} y={H - 10} textAnchor="middle" className={styles.axisLabel}>
                {d.label}
              </text>
            ) : null,
          )}

          {pts[active] && (
            <>
              <line x1={pts[active][0]} x2={pts[active][0]} y1={PAD.t} y2={H - PAD.b} stroke="rgba(148,163,184,0.25)" strokeDasharray="2 4" />
              <circle cx={pts[active][0]} cy={pts[active][1]} r={9} fill="rgba(217, 168, 78,0.25)" />
              <circle cx={pts[active][0]} cy={pts[active][1]} r={4.5} fill="#ede6d8" stroke="#d9a84e" strokeWidth={2} />
            </>
          )}

          <rect x={PAD.l - step / 2} y={0} width={W - PAD.l - PAD.r + step} height={H} fill="transparent" onPointerMove={onMove} onPointerLeave={() => setHover(null)} />
        </svg>

        {pts[active] && (
          <div
            className={styles.tooltip}
            style={{
              left: `${(pts[active][0] / W) * 100}%`,
              top: `${(pts[active][1] / H) * 100}%`,
              // у краёв подсказка прижимается внутрь графика
              transform:
                pts[active][0] / W > 0.75
                  ? "translate(calc(-100% + 18px), calc(-100% - 16px))"
                  : pts[active][0] / W < 0.2
                    ? "translate(-18px, calc(-100% - 16px))"
                    : undefined,
            }}
          >
            <span className={styles.ttValue}>
              {data[active].value}
              {scale.unit}
            </span>
            <span className={styles.ttLabel}>{data[active].hint ?? data[active].label}</span>
          </div>
        )}
      </div>
    </div>
  );
}
