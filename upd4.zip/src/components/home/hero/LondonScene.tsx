"use client";

/**
 * Иллюстрация первого экрана: вечерний Вестминстер в фирменной палитре.
 * Чистый SVG — без внешних картинок и тяжёлых библиотек.
 * Слои двигаются с разной глубиной за курсором (параллакс), вода и огни мягко мерцают.
 */

import { useMemo, useRef } from "react";
import styles from "./LondonScene.module.css";

/* детерминированный генератор случайных чисел — одинаковая картинка на сервере и клиенте */
function rng(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const GROUND = 604; // линия набережной
/** Парламент сжат к башне, чтобы не уходить под заголовок; башня чуть уменьшена. */
const PARL_T = "translate(1080 0) scale(0.7 1) translate(-1080 0)";
const TOWER_T = `translate(1080 ${GROUND}) scale(0.86) translate(-1080 -${GROUND})`;
const r1 = (n: number) => Math.round(n * 10) / 10;

/* ---------- силуэт Парламента ---------- */
function parliamentPath() {
  const pts: Array<[number, number]> = [[560, GROUND]];
  const facade = (x0: number, x1: number, top: number, step: number, spike: number) => {
    for (let x = x0; x < x1; x += step) {
      pts.push([x, top], [x + step * 0.35, top], [x + step * 0.5, top - spike], [x + step * 0.65, top]);
    }
    pts.push([x1, top]);
  };
  // западное крыло
  facade(560, 600, 548, 20, 12);
  // башня Виктории
  pts.push([600, 392], [604, 392], [606, 362], [610, 392], [626, 392], [630, 376], [640, 376], [640, 340], [642, 340], [642, 376], [654, 376], [658, 392], [674, 392], [676, 362], [680, 392], [684, 392], [684, 520]);
  // главный фасад
  facade(684, 832, 520, 22, 14);
  // центральная башня со шпилем
  pts.push([832, 488], [840, 488], [844, 452], [852, 452], [855, 404], [858, 452], [866, 452], [870, 488], [878, 488]);
  facade(878, 1036, 520, 22, 14);
  // крупные турели
  pts.push([1036, 470], [1040, 462], [1044, 470], [1044, 540]);
  facade(1120, 1330, 538, 21, 11);
  pts.push([1330, GROUND]);
  return "M" + pts.map(([x, y]) => `${x},${y}`).join(" L") + " Z";
}

/* ---------- башня Елизаветы (Биг-Бен) ---------- */
function BigBen() {
  return (
    <g>
      {/* ствол башни */}
      <path d="M1052 604 L1052 304 L1108 304 L1108 604 Z" fill="url(#towerGrad)" />
      {Array.from({ length: 6 }).map((_, i) => (
        <line key={i} x1={1058 + i * 9.5} y1={312} x2={1058 + i * 9.5} y2={600} stroke="rgba(255,190,140,0.07)" strokeWidth="1.2" />
      ))}
      {Array.from({ length: 9 }).map((_, i) => (
        <line key={i} x1={1052} y1={330 + i * 30} x2={1108} y2={330 + i * 30} stroke="rgba(0,0,0,0.25)" strokeWidth="1" />
      ))}
      {/* окна ствола */}
      {Array.from({ length: 8 }).map((_, i) => (
        <rect key={i} x={1076} y={338 + i * 30} width={8} height={12} rx={4} fill="#ffcf87" opacity={i % 3 === 0 ? 0.55 : 0.18} />
      ))}
      {/* ярус часов */}
      <path d="M1044 304 L1044 226 L1116 226 L1116 304 Z" fill="url(#towerGrad)" />
      <path d="M1040 230 L1120 230 L1120 222 L1040 222 Z" fill="#1e2840" />
      <circle cx="1080" cy="265" r="44" fill="url(#clockGlow)" className={styles.clockGlow} />
      <circle cx="1080" cy="265" r="25" fill="#ffe2a6" />
      <circle cx="1080" cy="265" r="25" fill="none" stroke="#a8763a" strokeWidth="2.5" />
      <circle cx="1080" cy="265" r="19" fill="none" stroke="rgba(120,80,30,0.35)" strokeWidth="1" />
      {Array.from({ length: 12 }).map((_, i) => {
        const a = (i / 12) * Math.PI * 2;
        return (
          <line key={i} x1={r1(1080 + Math.sin(a) * 20)} y1={r1(265 - Math.cos(a) * 20)} x2={r1(1080 + Math.sin(a) * 23)} y2={r1(265 - Math.cos(a) * 23)} stroke="#6b4a22" strokeWidth="1.4" />
        );
      })}
      <line x1="1080" y1="265" x2="1080" y2="250" stroke="#3b2a14" strokeWidth="2" strokeLinecap="round" />
      <line x1="1080" y1="265" x2="1091" y2="270" stroke="#3b2a14" strokeWidth="1.6" strokeLinecap="round" />
      {/* звонница */}
      <path d="M1050 222 L1050 186 L1110 186 L1110 222 Z" fill="url(#towerGrad)" />
      {[1056, 1069, 1082, 1095].map((x) => (
        <path key={x} d={`M${x} 218 L${x} 198 Q${x + 4.5} 190 ${x + 9} 198 L${x + 9} 218 Z`} fill="#ffcf87" opacity="0.4" />
      ))}
      {/* крыша и шпиль */}
      <path d="M1046 188 L1114 188 L1094 130 L1066 130 Z" fill="url(#roofGrad)" />
      <path d="M1066 132 L1094 132 L1088 108 L1072 108 Z" fill="#1f2a44" />
      <path d="M1072 110 L1088 110 L1080 52 Z" fill="url(#roofGrad)" />
      <line x1="1080" y1="54" x2="1080" y2="38" stroke="#e8b86a" strokeWidth="2" />
      <circle cx="1080" cy="38" r="2.6" fill="#ffd88a" />
      {/* боковые шпили яруса */}
      {[1044, 1116].map((x) => (
        <path key={x} d={`M${x - 4} 228 L${x + 4} 228 L${x} 206 Z`} fill="#1b2538" />
      ))}
    </g>
  );
}

export function LondonScene() {
  const rootRef = useRef<SVGSVGElement>(null);

  const data = useMemo(() => {
    const r = rng(7);
    const stars = Array.from({ length: 70 }, () => ({
      x: r1(r() * 1600),
      y: r1(r() * 330),
      s: r1(0.5 + r() * 1.3),
      o: r1(0.25 + r() * 0.6),
      tw: r() > 0.7,
      d: r1(r() * 4),
    }));
    // окна Парламента
    const windows: Array<{ x: number; y: number; o: number }> = [];
    const spans: Array<[number, number, number]> = [
      [690, 830, 530],
      [880, 1032, 530],
      [1124, 1326, 548],
      [606, 680, 405],
    ];
    for (const [x0, x1, y0] of spans) {
      for (let y = y0; y < GROUND - 10; y += 15) {
        for (let x = x0; x < x1; x += 11) {
          if (r() > 0.55) windows.push({ x, y, o: r1(0.25 + r() * 0.7) });
        }
      }
    }
    // дальний город
    const city: Array<[number, number, number]> = [];
    for (let x = 0; x < 1600; ) {
      const w = 18 + r() * 46;
      city.push([r1(x), r1(w), r1(16 + r() * 44)]);
      x += w + r() * 6;
    }
    // блики на воде
    const glints = Array.from({ length: 90 }, () => {
      const x = 760 + (r() - 0.5) * 900 * (0.6 + r() * 0.6);
      return { x: r1(x), y: r1(618 + r() * 190), w: r1(10 + r() * 46), o: r1(0.15 + r() * 0.55), d: r1(r() * 3) };
    });
    // листья
    const leaf = (cx: number, cy: number, n: number, spread: number, seed: number) => {
      const rr = rng(seed);
      return Array.from({ length: n }, () => ({
        x: r1(cx + (rr() - 0.5) * spread),
        y: r1(cy + (rr() - 0.5) * spread * 1.1),
        rot: r1(rr() * 360),
        s: r1(0.6 + rr() * 1.1),
        tone: rr(),
        blur: rr() > 0.72,
      }));
    };
    const bokeh = Array.from({ length: 16 }, () => ({
      x: r1(500 + r() * 1100),
      y: r1(380 + r() * 420),
      rad: r1(6 + r() * 22),
      o: r1(0.08 + r() * 0.22),
      warm: r() > 0.4,
      d: r1(r() * 6),
    }));
    return {
      stars,
      windows,
      city,
      glints,
      bokeh,
      leavesTop: leaf(70, 120, 46, 300, 11),
      leavesBottom: leaf(80, 800, 40, 280, 23),
    };
  }, []);

  const leafPath = "M0 0 C 14 -13 44 -14 62 0 C 44 14 14 13 0 0 Z";
  const leafTones = ["#0c1a14", "#122419", "#1a3122", "#25402a"];

  return (
    <svg
      ref={rootRef}
      className={styles.scene}
      viewBox="0 0 1600 900"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#060a1d" />
          <stop offset="0.32" stopColor="#0f1a33" />
          <stop offset="0.52" stopColor="#1d2c4f" />
          <stop offset="0.63" stopColor="#3e4a6a" />
          <stop offset="0.68" stopColor="#9a7a5e" />
          <stop offset="0.7" stopColor="#d9a06a" />
        </linearGradient>
        <radialGradient id="sunset" cx="0.66" cy="0.66" r="0.42">
          <stop offset="0" stopColor="#ffb27a" stopOpacity="0.85" />
          <stop offset="0.35" stopColor="#d99a5e" stopOpacity="0.45" />
          <stop offset="1" stopColor="#3e4a6a" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="water" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2e3a5c" />
          <stop offset="0.25" stopColor="#1c2744" />
          <stop offset="1" stopColor="#090b1f" />
        </linearGradient>
        <linearGradient id="towerGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#0f1628" />
          <stop offset="0.65" stopColor="#1a2440" />
          <stop offset="1" stopColor="#2e3a52" />
        </linearGradient>
        <linearGradient id="roofGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#0d1424" />
          <stop offset="1" stopColor="#26324a" />
        </linearGradient>
        <linearGradient id="parl" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1c2640" />
          <stop offset="1" stopColor="#0f1628" />
        </linearGradient>
        <radialGradient id="clockGlow">
          <stop offset="0" stopColor="#ffe6a8" stopOpacity="0.9" />
          <stop offset="0.45" stopColor="#ffb86b" stopOpacity="0.35" />
          <stop offset="1" stopColor="#ffb86b" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="ledgeTop" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a5468" />
          <stop offset="1" stopColor="#232c3e" />
        </linearGradient>
        <linearGradient id="ledgeFront" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#161e2e" />
          <stop offset="1" stopColor="#090d16" />
        </linearGradient>
        <linearGradient id="cover" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#2a3570" />
          <stop offset="0.55" stopColor="#1b2452" />
          <stop offset="1" stopColor="#10173a" />
        </linearGradient>
        <linearGradient id="coverSheen" x1="1" y1="0" x2="0" y2="0.6">
          <stop offset="0" stopColor="#ffb27a" stopOpacity="0.28" />
          <stop offset="0.4" stopColor="#ffb27a" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#f6d79a" />
          <stop offset="0.5" stopColor="#d9a55c" />
          <stop offset="1" stopColor="#f3cf8d" />
        </linearGradient>
        <linearGradient id="pages" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#d9cbb5" />
          <stop offset="1" stopColor="#f5ead6" />
        </linearGradient>
        <linearGradient id="penBody" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3a4458" />
          <stop offset="0.45" stopColor="#151b28" />
          <stop offset="1" stopColor="#0a0d14" />
        </linearGradient>
        <linearGradient id="fadeBottom" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0f1724" stopOpacity="0" />
          <stop offset="1" stopColor="#0f1724" stopOpacity="1" />
        </linearGradient>
        <linearGradient id="reflFade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.5" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <mask id="reflMask">
          <rect x="0" y={GROUND} width="1600" height="300" fill="url(#reflFade)" />
        </mask>
        <filter id="blur6" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="6" />
        </filter>
        <filter id="blur22" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="22" />
        </filter>
        <filter id="blur3" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2.5" />
        </filter>
        {/* ткань флага: складки через карту смещений */}
        <filter id="cloth" x="-10%" y="-10%" width="120%" height="120%">
          <feTurbulence type="fractalNoise" baseFrequency="0.008 0.02" numOctaves="2" seed="4" result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale="38" xChannelSelector="R" yChannelSelector="G" />
        </filter>
        <linearGradient id="folds" x1="0" y1="0" x2="1" y2="0.3">
          <stop offset="0" stopColor="#000" stopOpacity="0.55" />
          <stop offset="0.18" stopColor="#000" stopOpacity="0.05" />
          <stop offset="0.32" stopColor="#000" stopOpacity="0.45" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0.08" />
          <stop offset="0.66" stopColor="#000" stopOpacity="0.4" />
          <stop offset="0.82" stopColor="#000" stopOpacity="0.1" />
          <stop offset="1" stopColor="#000" stopOpacity="0.6" />
        </linearGradient>
        <clipPath id="flagShape">
          <path d="M1268 752 C 1350 728 1440 716 1600 700 L 1600 920 L 1240 920 C 1250 860 1252 810 1268 752 Z" />
        </clipPath>
      </defs>

      {/* ===== Небо ===== */}
      <g data-depth="2">
        <rect x="-40" y="-40" width="1680" height="700" fill="url(#sky)" />
        <rect x="-40" y="-40" width="1680" height="700" fill="url(#sunset)" />
        {data.stars.map((s, i) => (
          <circle
            key={i}
            cx={s.x}
            cy={s.y}
            r={s.s}
            fill="#e6ecff"
            opacity={s.o}
            className={s.tw ? styles.twinkle : undefined}
            style={s.tw ? { animationDelay: `${s.d}s` } : undefined}
          />
        ))}
        <g className={styles.clouds} filter="url(#blur22)">
          <ellipse cx="1180" cy="300" rx="260" ry="26" fill="#e0a27a" opacity="0.32" />
          <ellipse cx="900" cy="350" rx="320" ry="20" fill="#c08a6a" opacity="0.28" />
          <ellipse cx="1380" cy="390" rx="240" ry="18" fill="#ffc08a" opacity="0.3" />
          <ellipse cx="620" cy="260" rx="280" ry="22" fill="#5f6f8f" opacity="0.25" />
          <ellipse cx="1250" cy="460" rx="300" ry="14" fill="#ffc38f" opacity="0.32" />
        </g>
      </g>

      {/* ===== Дальний город ===== */}
      <g data-depth="5" opacity="0.75">
        {data.city.map(([x, w, h], i) => (
          <rect key={i} x={x} y={GROUND - h} width={w} height={h + 2} fill="#1f2a46" />
        ))}
      </g>

      {/* ===== Парламент и Биг-Бен ===== */}
      <g data-depth="9">
        <g transform={PARL_T}>
          <path d={parliamentPath()} fill="url(#parl)" />
          {data.windows.map((w, i) => (
            <rect key={i} x={w.x} y={w.y} width="4" height="7" rx="1" fill="#ffcf87" opacity={w.o} />
          ))}
        </g>
        <g transform={TOWER_T}>
          <BigBen />
        </g>
        {/* мост */}
        <path d="M1258 598 L1640 586 L1640 604 L1258 614 Z" fill="#121a2c" />
        {[1290, 1370, 1450, 1530, 1610].map((x) => (
          <path key={x} d={`M${x - 34} 612 Q ${x} 584 ${x + 34} 610`} fill="none" stroke="#202b45" strokeWidth="5" />
        ))}
        {[1275, 1335, 1395, 1455, 1515, 1575].map((x, i) => (
          <g key={x}>
            <circle cx={x} cy={584 - i * 0.8} r="7" fill="#ffc98a" opacity="0.25" filter="url(#blur3)" />
            <circle cx={x} cy={584 - i * 0.8} r="2" fill="#ffe3b0" />
          </g>
        ))}
      </g>

      {/* ===== Темза ===== */}
      <g data-depth="12">
        <rect x="-40" y={GROUND} width="1680" height="340" fill="url(#water)" />
        {/* отражение башни */}
        <g mask="url(#reflMask)" opacity="0.55" filter="url(#blur3)">
          <g transform={`translate(0 ${GROUND * 2}) scale(1 -1)`}>
            <path d={parliamentPath()} fill="#1c2640" transform={PARL_T} />
            <g transform={TOWER_T}>
              <rect x="1052" y="226" width="56" height="378" fill="#1c2640" />
              <circle cx="1080" cy="265" r="22" fill="#ffd590" opacity="0.6" />
            </g>
          </g>
        </g>
        {data.glints.map((g, i) => (
          <rect
            key={i}
            x={g.x}
            y={g.y}
            width={g.w}
            height="1.2"
            rx="0.6"
            fill={i % 3 ? "#ffc28c" : "#ecc49a"}
            opacity={g.o}
            className={styles.glint}
            style={{ animationDelay: `${g.d}s` }}
          />
        ))}
      </g>

      {/* ===== Боке ===== */}
      <g data-depth="18">
        {data.bokeh.map((b, i) => (
          <circle
            key={i}
            cx={b.x}
            cy={b.y}
            r={b.rad}
            fill={b.warm ? "#ffc38f" : "#cfd8e8"}
            opacity={b.o}
            filter="url(#blur6)"
            className={styles.bokeh}
            style={{ animationDelay: `${b.d}s` }}
          />
        ))}
      </g>

      {/* ===== Передний план: парапет, книга, ручка, флаг ===== */}
      <g data-depth="24">
        {/* парапет */}
        <path d="M640 812 L1640 742 L1640 772 L640 846 Z" fill="url(#ledgeTop)" />
        <path d="M640 846 L1640 772 L1640 940 L640 940 Z" fill="url(#ledgeFront)" />
        <path d="M640 812 L1640 742" stroke="rgba(255,190,150,0.28)" strokeWidth="1.5" />

        {/* ручка */}
        <g transform="translate(960 800) rotate(-6) scale(0.9)">
          <ellipse cx="150" cy="16" rx="160" ry="6" fill="#000" opacity="0.5" filter="url(#blur3)" />
          <rect x="0" y="0" width="230" height="15" rx="7.5" fill="url(#penBody)" />
          <rect x="150" y="-0.5" width="8" height="16" fill="url(#gold)" />
          <rect x="168" y="-2" width="58" height="4" rx="2" fill="url(#gold)" opacity="0.9" />
          <path d="M230 1.5 L268 7.5 L230 13.5 Z" fill="url(#gold)" />
          <line x1="236" y1="7.5" x2="266" y2="7.5" stroke="#7a5a2a" strokeWidth="0.8" />
        </g>

        {/* флаг Великобритании, наброшенный на парапет */}
        <g clipPath="url(#flagShape)">
          <g filter="url(#cloth)" transform="translate(1230 690) rotate(-8)">
            <rect x="0" y="0" width="420" height="260" fill="#1f2f78" />
            {/* белые диагонали */}
            <path d="M0 0 L420 260 M420 0 L0 260" stroke="#f3efe8" strokeWidth="52" />
            {/* красные диагонали */}
            <path d="M0 0 L420 260 M420 0 L0 260" stroke="#b8243a" strokeWidth="17" />
            {/* белый крест */}
            <path d="M210 0 V260 M0 130 H420" stroke="#f3efe8" strokeWidth="86" />
            {/* красный крест */}
            <path d="M210 0 V260 M0 130 H420" stroke="#b8243a" strokeWidth="52" />
          </g>
          <path d="M1230 690 L1610 690 L1610 940 L1230 940 Z" fill="url(#folds)" />
          <path d="M1230 690 L1610 690 L1610 940 L1230 940 Z" fill="#1d2740" opacity="0.28" />
        </g>
      </g>

      {/* ===== Листва по краю ===== */}
      <g data-depth="34">
        {[...data.leavesTop, ...data.leavesBottom].map((l, i) => (
          <path
            key={i}
            d={leafPath}
            transform={`translate(${l.x} ${l.y}) rotate(${l.rot}) scale(${l.s})`}
            fill={leafTones[Math.floor(l.tone * leafTones.length)]}
            filter={l.blur ? "url(#blur3)" : undefined}
            opacity={l.blur ? 0.7 : 0.95}
          />
        ))}
        {/* подсветка краёв нескольких листьев тёплым светом */}
        {data.leavesTop.slice(0, 8).map((l, i) => (
          <path
            key={`h${i}`}
            d="M0 0 C 14 -13 44 -14 62 0"
            transform={`translate(${l.x} ${l.y}) rotate(${l.rot}) scale(${l.s})`}
            fill="none"
            stroke="#e7a77a"
            strokeOpacity="0.35"
            strokeWidth="1.2"
          />
        ))}
      </g>

      {/* плавный переход в фон страницы */}
      <rect x="-40" y="760" width="1680" height="180" fill="url(#fadeBottom)" />
    </svg>
  );
}
