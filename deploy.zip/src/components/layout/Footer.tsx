import { Logo } from "@/components/ui/Logo";
import styles from "./Footer.module.css";

export function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.top}>
          <div className={styles.brand}>
            <Logo />
            <p className={styles.tagline}>
              Подготовка к Cambridge B2 First по методике Елены Каранфил.
            </p>
          </div>
          <nav className={styles.cols} aria-label="Ссылки в подвале">
            <div>
              <span className={styles.head}>Платформа</span>
              <a href="/#exam">Формат экзамена</a>
              <a href="/#method">Методика</a>
              <a href="/practice">Все задания</a>
            </div>
            <div>
              <span className={styles.head}>О нас</span>
              <a href="/#teacher">Преподаватель</a>
              <a href="/#faq">Вопросы и ответы</a>
              <a href="/register">Регистрация</a>
              <a href="/login">Вход</a>
            </div>
          </nav>
        </div>
        <div className={styles.bottom}>
          <span>© {new Date().getFullYear()} FCE B2 Prep</span>
          <span className={styles.legal}>
            B2 First — экзамен Cambridge University Press &amp; Assessment. Платформа не является
            официальным ресурсом Cambridge.
          </span>
        </div>
      </div>
    </footer>
  );
}
