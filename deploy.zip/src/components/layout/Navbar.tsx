"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { UserRound } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { AnimatePresence, motion, useMotionValueEvent, useScroll, useSpring } from "framer-motion";
import { useEffect, useState } from "react";
import { Logo } from "@/components/ui/Logo";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./Navbar.module.css";

const links = [
  { href: "/", label: "Главная" },
  { href: "/practice", label: "Задания" },
  { href: "/dashboard", label: "Прогресс" },
  { href: "/results", label: "Статистика" },
  { href: "/#teacher", label: "О сайте" },
];

export function Navbar() {
  const { scrollY, scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 140, damping: 30, mass: 0.4 });
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const { session } = useAuth();

  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 24));

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <motion.header
      className={cn(styles.header, scrolled && styles.scrolled)}
      initial={{ y: -24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: ease.out, delay: 0.1 }}
    >
      <motion.span className={styles.progress} style={{ scaleX: progress }} aria-hidden="true" />
      <div className={cn("container", styles.bar)}>
        <Logo />

        <nav className={styles.nav} aria-label="Основная навигация">
          {links.map((l) => {
            const active = l.href === pathname;
            return (
              <Link key={l.href} href={l.href} className={cn(styles.link, active && styles.linkActive)} aria-current={active ? "page" : undefined}>
                {l.label}
                {active && <motion.span layoutId="nav-underline" className={styles.underline} />}
              </Link>
            );
          })}
        </nav>

        <div className={styles.actions}>
          <Link href={session ? "/dashboard" : "/login"} className={styles.login}>
            {session ? "Кабинет" : "Войти"}
            <UserRound size={17} strokeWidth={1.9} />
          </Link>
        </div>

        <button
          className={cn(styles.burger, open && styles.burgerOpen)}
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Закрыть меню" : "Открыть меню"}
          aria-expanded={open}
        >
          <span />
          <span />
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            className={styles.mobile}
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35, ease: ease.out }}
          >
            <nav className={styles.mobileNav}>
              {links.map((l, i) => (
                <motion.a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: ease.out, delay: 0.05 + i * 0.05 }}
                >
                  {l.label}
                </motion.a>
              ))}
            </nav>
            <div className={styles.mobileActions} onClick={() => setOpen(false)}>
              <Button href="/register" size="lg" className={styles.full}>
                Начать подготовку
              </Button>
              <Button href="/login" size="lg" variant="secondary" className={styles.full}>
                Войти
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
