import styles from "./BackgroundAura.module.css";

/**
 * Атмосферный фон: мягкие пятна света в цветах вечернего неба
 * (фиолетовый, тёплый закатный, глубокий синий) и лёгкое зерно.
 */
export function BackgroundAura() {
  return (
    <div className={styles.aura} aria-hidden="true">
      <div className={`${styles.blob} ${styles.b1}`} />
      <div className={`${styles.blob} ${styles.b2}`} />
      <div className={`${styles.blob} ${styles.b3}`} />
      <div className={styles.noise} />
      <div className={styles.vignette} />
    </div>
  );
}
