"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import {
  AlertTriangle,
  ArrowRight,
  Check,
  Circle,
  Copy,
  FileCheck2,
  LayoutGrid,
  ListChecks,
  Mail,
  Newspaper,
  PenLine,
  RotateCcw,
  Star,
  Timer,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import type { WritingGenre, WritingTask, WritingVariant } from "@/data/tasks/types";
import { saveAttempt, formatDuration, isMockRun } from "@/lib/history";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { FocusShell } from "./FocusShell";
import styles from "./WritingRunner.module.css";

const LINKERS = [
  "however", "moreover", "furthermore", "in addition", "on the other hand", "although", "therefore",
  "as a result", "for example", "for instance", "firstly", "secondly", "finally", "in conclusion",
  "to sum up", "to conclude", "while", "whereas", "despite", "in my opinion", "consequently",
  "nevertheless", "what is more", "what's more", "also", "because", "so that", "anyway", "by the way", "apart from",
];
const CONCLUSION = /\b(in conclusion|to sum up|to conclude|overall|all in all|on balance)\b/i;
const CONTRACTION = /\b\w+'(t|s|re|ve|ll|d|m)\b/gi;
const POINT_HINTS = [
  /\b(learn|learning|research|information|educational|knowledge|apps?|dictionar|study|studying)\w*/i,
  /\b(distract|attention|focus|concentrat|social media|games?|messages?|notifications?)\w*/i,
];

const GENRE_ICON: Record<WritingGenre, LucideIcon> = {
  essay: PenLine,
  article: Newspaper,
  email: Mail,
  review: Star,
  report: FileCheck2,
};

const GENRE_HINT: Record<WritingGenre, string> = {
  essay: "Нейтральный стиль, аргументы и вывод",
  article: "Заголовок, живой стиль, обращение к читателю",
  email: "Приветствие, дружеский тон, прощание",
  review: "Описание, плюсы и минусы, рекомендация",
  report: "Формальный стиль, подзаголовки, рекомендации",
};

const countWords = (t: string) => (t.trim() ? t.trim().split(/\s+/).length : 0);

interface CheckItem {
  id: string;
  group: string;
  label: string;
  auto: boolean;
  ok: boolean;
  warn?: boolean;
  detail?: string;
}

function buildChecks(v: WritingVariant, text: string, min: number, max: number, manual: Record<string, boolean>): CheckItem[] {
  const words = countWords(text);
  const paras = text.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  const lines = text.split(/\n/).map((l) => l.trim()).filter(Boolean);
  const lower = text.toLowerCase();
  const linkers = LINKERS.filter((l) => new RegExp(`\\b${l.replace("'", "['’]")}\\b`).test(lower));
  const contractions = text.match(CONTRACTION) ?? [];
  const first = lines[0] ?? "";
  const last = lines.slice(-2).join(" ");
  const formal = v.genre === "essay" || v.genre === "report";

  const checks: CheckItem[] = [
    { id: "len", group: "Content", label: `Объём ${min}–${max} слов`, auto: true, ok: words >= min && words <= max, detail: `${words} сл.` },
  ];

  if (v.genre === "essay" && v.notes) {
    checks.push(
      { id: "p1", group: "Content", label: `Пункт 1: ${v.notes[0]}`, auto: true, ok: POINT_HINTS[0].test(text) },
      { id: "p2", group: "Content", label: `Пункт 2: ${v.notes[1]}`, auto: true, ok: POINT_HINTS[1].test(text) },
      { id: "p3", group: "Content", label: "Пункт 3: собственная идея", auto: false, ok: !!manual.p3 },
    );
  } else {
    checks.push({ id: "all", group: "Content", label: "Ответил(а) на все вопросы задания", auto: false, ok: !!manual.all });
  }

  if (formal) {
    checks.push({
      id: "style",
      group: "Communicative achievement",
      label: "Нейтральный стиль, без сокращений",
      auto: true,
      ok: words > 0 && contractions.length === 0,
      warn: contractions.length > 0,
      detail: contractions.length ? `${contractions.length}: ${contractions.slice(0, 3).join(", ")}` : undefined,
    });
  }
  if (v.genre === "article") {
    checks.push(
      { id: "title", group: "Communicative achievement", label: "Есть заголовок", auto: true, ok: !!first && first.split(/\s+/).length <= 9 && !/[.!]$/.test(first) },
      { id: "reader", group: "Communicative achievement", label: "Обращение к читателю (вопрос)", auto: true, ok: /\?/.test(text) },
    );
  }
  if (v.genre === "email") {
    checks.push(
      { id: "greet", group: "Communicative achievement", label: "Приветствие (Hi / Dear …)", auto: true, ok: /^(hi|hello|dear|hey)\b/i.test(first) },
      { id: "bye", group: "Communicative achievement", label: "Прощание (Best wishes, Love, See you…)", auto: true, ok: /(best wishes|love|see you|take care|all the best|regards|bye|speak soon|write soon)/i.test(last) },
    );
  }
  if (v.genre === "review") {
    checks.push({ id: "rec", group: "Communicative achievement", label: "Есть рекомендация", auto: true, ok: /(recommend|worth|must[- ]have|don't miss|give it a try|would suggest)/i.test(text) });
  }

  const minParas = v.genre === "email" ? 3 : 4;
  checks.push(
    { id: "paras", group: "Organisation", label: `Абзацы (от ${minParas})`, auto: true, ok: paras.length >= minParas, detail: `${paras.length} абз.` },
    { id: "links", group: "Organisation", label: "Связки между идеями (от 4)", auto: true, ok: linkers.length >= 4, detail: linkers.length ? linkers.slice(0, 4).join(", ") : undefined },
  );
  if (v.genre === "essay") {
    checks.push({ id: "concl", group: "Organisation", label: "Вывод с вашим мнением", auto: true, ok: paras.length >= 2 && CONCLUSION.test(paras[paras.length - 1] ?? "") });
  }
  checks.push(
    { id: "range", group: "Language", label: "Разнообразная лексика и сложные конструкции", auto: false, ok: !!manual.range },
    { id: "proof", group: "Language", label: "Перечитал(а) и исправил(а) ошибки", auto: false, ok: !!manual.proof },
  );
  return checks;
}

export function WritingRunner({ task }: { task: WritingTask }) {
  const single = task.variants.length === 1;
  const [variant, setVariant] = useState<WritingVariant | null>(single ? task.variants[0] : null);
  const draftKey = `fce.draft.${task.slug}.${variant?.id ?? "none"}`;
  const [text, setText] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [saved, setSaved] = useState<"idle" | "saving" | "saved">("idle");
  const [manual, setManual] = useState<Record<string, boolean>>({});
  const [remaining, setRemaining] = useState(task.minutes * 60);
  const [phase, setPhase] = useState<"write" | "done">("write");
  const [copied, setCopied] = useState(false);
  const [mock, setMock] = useState(false);
  const started = useRef(Date.now());
  const { session } = useAuth();

  useEffect(() => setMock(isMockRun()), []);

  // черновик для выбранного задания
  useEffect(() => {
    if (!variant) return;
    setLoaded(false);
    try {
      setText(localStorage.getItem(draftKey) ?? "");
    } catch {
      /* noop */
    }
    setLoaded(true);
  }, [draftKey, variant]);

  useEffect(() => {
    if (!loaded || phase !== "write" || !variant) return;
    setSaved("saving");
    const id = window.setTimeout(() => {
      try {
        localStorage.setItem(draftKey, text);
      } catch {
        /* noop */
      }
      setSaved("saved");
    }, 600);
    return () => window.clearTimeout(id);
  }, [text, loaded, draftKey, phase, variant]);

  useEffect(() => {
    if (phase !== "write" || !variant) return;
    const id = window.setInterval(() => setRemaining((r) => Math.max(0, r - 1)), 1000);
    return () => window.clearInterval(id);
  }, [phase, variant]);

  const words = countWords(text);
  const checks = useMemo(
    () => (variant ? buildChecks(variant, text, task.minWords, task.maxWords, manual) : []),
    [variant, text, task.minWords, task.maxWords, manual],
  );
  const passed = checks.filter((c) => c.ok).length;
  const lengthState = words < task.minWords ? "under" : words > task.maxWords ? "over" : "ok";
  const groups = Array.from(new Set(checks.map((c) => c.group)));

  const submit = () => {
    if (!variant) return;
    saveAttempt({
      slug: task.slug,
      title: single ? task.title : `${task.title}: ${variant.label}`,
      paper: task.paper,
      part: task.part,
      kind: "writing",
      words,
      selfCheck: checks.length ? passed / checks.length : 0,
      text,
      prompt: `${variant.label}: ${variant.question}`,
      seconds: Math.round((Date.now() - started.current) / 1000),
      date: new Date().toISOString(),
    });
    setPhase("done");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const restart = () => {
    setText("");
    setManual({});
    setRemaining(task.minutes * 60);
    started.current = Date.now();
    try {
      localStorage.removeItem(draftKey);
    } catch {
      /* noop */
    }
    setPhase("write");
    if (!single) setVariant(null);
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      /* noop */
    }
  };

  /* ---------- выбор задания (Part 2) ---------- */
  if (!variant) {
    return (
      <FocusShell title={`Writing · ${task.part}`} progress={0}>
        <motion.div
          className={styles.choose}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: ease.out }}
        >
          <span className={styles.kicker}>
            {task.part} · {task.type}
          </span>
          <h1 className={styles.title}>Выберите задание</h1>
          <p className={styles.chooseLead}>{task.instruction}</p>
          <div className={styles.variants}>
            {task.variants.map((v, i) => {
              const Icon = GENRE_ICON[v.genre];
              return (
                <motion.button
                  key={v.id}
                  className={styles.variant}
                  onClick={() => {
                    setVariant(v);
                    started.current = Date.now();
                  }}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease: ease.out, delay: 0.1 + i * 0.07 }}
                >
                  <span className={styles.variantIcon}>
                    <Icon size={22} strokeWidth={1.8} />
                  </span>
                  <span className={styles.variantLabel}>{v.label}</span>
                  <span className={styles.variantHint}>{GENRE_HINT[v.genre]}</span>
                  <span className={styles.variantQuestion}>{v.question}</span>
                  <span className={styles.variantGo}>
                    Выбрать <ArrowRight size={15} />
                  </span>
                </motion.button>
              );
            })}
          </div>
        </motion.div>
      </FocusShell>
    );
  }

  return (
    <FocusShell
      title={`Writing · ${task.part}`}
      progress={phase === "done" ? 1 : Math.min(1, words / task.minWords)}
      timer={formatDuration(remaining)}
      timerWarn={remaining < 5 * 60}
    >
      <AnimatePresence mode="wait">
        {phase === "write" ? (
          <motion.div
            key="write"
            className={styles.layout}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.5, ease: ease.out }}
          >
            <div className={styles.main}>
              <span className={styles.kicker}>
                {task.part} · {variant.label}
              </span>
              <h1 className={styles.title}>{single ? task.title : variant.label}</h1>

              <div className={styles.brief}>
                <p className={styles.context}>{variant.context}</p>
                <p className={styles.question}>{variant.question}</p>
                {variant.notes && (
                  <div className={styles.notes}>
                    <span>Notes — write about:</span>
                    <ol>
                      {variant.notes.map((n, i) => (
                        <li key={n} className={cn(i === 2 && styles.own)}>
                          {i === 2 ? "……………… (your own idea)" : n}
                        </li>
                      ))}
                    </ol>
                  </div>
                )}
                {!single && (
                  <button className={styles.changeVariant} onClick={() => setVariant(null)}>
                    Выбрать другое задание
                  </button>
                )}
              </div>

              <div className={styles.editorWrap}>
                <textarea
                  className={styles.editor}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder={
                    variant.genre === "email"
                      ? "Hi Alex,\n\nРазделяйте абзацы пустой строкой."
                      : variant.genre === "article"
                        ? "Заголовок статьи на первой строке\n\nРазделяйте абзацы пустой строкой."
                        : "Start writing here…\n\nРазделяйте абзацы пустой строкой."
                  }
                  spellCheck={false}
                  aria-label="Текст работы"
                />
                <div className={styles.editorBar}>
                  <span className={cn(styles.count, styles[lengthState])}>
                    <strong>{words}</strong> / {task.minWords}–{task.maxWords} слов
                  </span>
                  <span className={styles.wordTrack}>
                    <motion.span
                      className={cn(styles.wordFill, styles[`fill_${lengthState}`])}
                      animate={{ width: `${Math.min(100, (words / task.maxWords) * 100)}%` }}
                      transition={{ duration: 0.4, ease: ease.out }}
                    />
                    <span className={styles.wordMin} style={{ left: `${(task.minWords / task.maxWords) * 100}%` }} />
                  </span>
                  <span className={styles.saved}>
                    {saved === "saving" ? "Сохранение…" : saved === "saved" ? "Черновик сохранён" : ""}
                  </span>
                </div>
              </div>
            </div>

            <aside className={styles.side}>
              <div className={styles.sideHead}>
                <ProgressRing value={checks.length ? (passed / checks.length) * 100 : 0} size={56} stroke={6}>
                  <span className={styles.sideScore}>{passed}</span>
                </ProgressRing>
                <div>
                  <h2 className={styles.sideTitle}>Самопроверка</h2>
                  <p className={styles.sideSub}>по критериям оценки Cambridge</p>
                </div>
              </div>

              {groups.map((g) => (
                <div key={g} className={styles.group}>
                  <span className={styles.groupLabel}>{g}</span>
                  {checks
                    .filter((c) => c.group === g)
                    .map((c) => (
                      <button
                        key={c.id}
                        className={cn(styles.check, c.ok && styles.checkOk, c.auto && styles.checkAuto)}
                        onClick={() => !c.auto && setManual((m) => ({ ...m, [c.id]: !m[c.id] }))}
                        disabled={c.auto}
                        aria-pressed={c.auto ? undefined : c.ok}
                      >
                        <span className={styles.checkIcon}>
                          {c.ok ? <Check size={12} strokeWidth={3} /> : c.warn ? <AlertTriangle size={12} /> : <Circle size={10} />}
                        </span>
                        <span className={styles.checkText}>
                          {c.label}
                          {c.detail && <small>{c.detail}</small>}
                        </span>
                        <span className={styles.checkTag}>{c.auto ? "авто" : "отметить"}</span>
                      </button>
                    ))}
                </div>
              ))}

              <p className={styles.disclaimer}>
                Автоматические подсказки — ориентир, а не оценка. Итоговый балл ставит преподаватель.
              </p>

              <button
                className={cn(styles.submit, lengthState === "ok" && styles.submitReady)}
                onClick={submit}
                disabled={words < 20}
              >
                <FileCheck2 size={17} /> Сдать работу
              </button>
            </aside>
          </motion.div>
        ) : (
          <motion.div
            key="done"
            className={styles.done}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: ease.out }}
          >
            <div className={styles.doneCard}>
              <div className={styles.doneIcon}>
                <PenLine size={26} />
              </div>
              <span className={styles.kicker}>
                Writing · {task.part} · {variant.label}
              </span>
              <h1 className={styles.doneTitle}>Работа сдана</h1>
              <p className={styles.doneText}>
                {words} слов · самопроверка {passed} из {checks.length}.{" "}
                {session
                  ? "Работа отправлена преподавателю. Оценка и комментарий появятся в кабинете в блоке «Отзывы на Writing»."
                  : "Работа сохранена в этом браузере. Войдите в аккаунт, чтобы отправлять работы преподавателю на проверку."}
              </p>
              <div className={styles.doneActions}>
                {mock && (
                  <Link href="/mock" className={styles.primaryBtn}>
                    <Timer size={16} /> К пробному экзамену
                  </Link>
                )}
                <button className={mock ? styles.secondaryBtn : styles.primaryBtn} onClick={copy}>
                  <Copy size={16} /> {copied ? "Скопировано" : "Скопировать текст"}
                </button>
                <button className={styles.secondaryBtn} onClick={restart}>
                  <RotateCcw size={16} /> Написать заново
                </button>
                <Link href="/practice" className={styles.secondaryBtn}>
                  <ListChecks size={16} /> Все задания
                </Link>
                <Link href="/dashboard" className={styles.secondaryBtn}>
                  <LayoutGrid size={16} /> Кабинет
                </Link>
              </div>
            </div>
            <article className={styles.essay}>
              <p className={styles.question}>{variant.question}</p>
              {text
                .split(/\n\s*\n/)
                .filter((p) => p.trim())
                .map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
            </article>
          </motion.div>
        )}
      </AnimatePresence>
    </FocusShell>
  );
}
