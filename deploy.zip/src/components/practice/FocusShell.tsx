"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Clock, X } from "lucide-react";
import type { ReactNode } from "react";
import { ease } from "@/lib/motion";
import styles from "./TaskRunner.module.css";

interface Props {
  title: string;
  /** 0–1 */
  progress: number;
  timer?: string;
  timerWarn?: boolean;
  children: ReactNode;
}

/** Фокус-режим: минимальная шапка, без декоративного фона сайта. */
export function FocusShell({ title, progress, timer, timerWarn, children }: Props) {
  return (
    <div className={styles.page}>
      <div className={styles.focusBg} aria-hidden="true" />
      <header className={styles.topbar}>
        <Link href="/practice" className={styles.exit} aria-label="Выйти к заданиям">
          <X size={18} />
          <span>Выйти</span>
        </Link>
        <div className={styles.topCenter}>
          <span className={styles.topTitle}>{title}</span>
          <div className={styles.topProgress} role="progressbar" aria-valuenow={Math.round(progress * 100)} aria-valuemin={0} aria-valuemax={100}>
            <motion.span
              className={styles.topProgressFill}
              animate={{ width: `${progress * 100}%` }}
              transition={{ duration: 0.6, ease: ease.out }}
            />
          </div>
        </div>
        {timer ? (
          <span className={styles.timer} data-warn={timerWarn || undefined}>
            <Clock size={15} />
            {timer}
          </span>
        ) : (
          <span />
        )}
      </header>
      {children}
    </div>
  );
}
