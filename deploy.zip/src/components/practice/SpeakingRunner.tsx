"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Check, LayoutGrid, ListChecks, Mic, MicOff, RotateCcw, Timer, Volume2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import type { SpeakingTask } from "@/data/tasks/types";
import { saveAttempt, isMockRun } from "@/lib/history";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { FocusShell } from "./FocusShell";
import { SPEAKING_SCENES } from "./SpeakingScenes";
import styles from "./SpeakingRunner.module.css";

type Phase = "intro" | "asking" | "answering" | "done";

const LEVEL_BARS = 24;

export function SpeakingRunner({ task }: { task: SpeakingTask }) {
  const [phase, setPhase] = useState<Phase>("intro");
  const [qi, setQi] = useState(0);
  const [left, setLeft] = useState(0);
  const [recordings, setRecordings] = useState<Array<string | null>>([]);
  const [micError, setMicError] = useState<string | null>(null);
  const [withMic, setWithMic] = useState(false);

  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const ctxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const barsRef = useRef<Array<HTMLSpanElement | null>>([]);
  const rafRef = useRef(0);
  const started = useRef(0);
  const urlsRef = useRef<string[]>([]);
  const micOnRef = useRef(false);
  const answerStartedRef = useRef(-1);
  const runRef = useRef(0);

  const q = task.stages[qi];
  const [mock, setMock] = useState(false);
  useEffect(() => setMock(isMockRun()), []);

  /* ---------- уборка ---------- */
  useEffect(() => {
    return () => {
      cancelAnimationFrame(rafRef.current);
      window.speechSynthesis?.cancel();
      streamRef.current?.getTracks().forEach((t) => t.stop());
      ctxRef.current?.close().catch(() => undefined);
      urlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    };
  }, []);

  /* ---------- индикатор громкости ---------- */
  const loop = useCallback(() => {
    const an = analyserRef.current;
    if (an) {
      const data = new Uint8Array(an.frequencyBinCount);
      an.getByteFrequencyData(data);
      const step = Math.floor(data.length / LEVEL_BARS);
      barsRef.current.forEach((bar, i) => {
        if (!bar) return;
        const v = data[i * step] / 255;
        bar.style.transform = `scaleY(${0.12 + v * 0.88})`;
      });
    }
    rafRef.current = requestAnimationFrame(loop);
  }, []);

  const enableMic = async () => {
    setMicError(null);
    if (streamRef.current) {
      begin(true);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctx();
      const src = ctx.createMediaStreamSource(stream);
      const an = ctx.createAnalyser();
      an.fftSize = 128;
      src.connect(an);
      ctxRef.current = ctx;
      analyserRef.current = an;
      setWithMic(true);
      begin(true);
    } catch {
      setMicError("Нет доступа к микрофону. Разрешите его в настройках браузера или продолжите без записи.");
    }
  };

  const begin = (mic: boolean) => {
    micOnRef.current = mic;
    answerStartedRef.current = -1;
    runRef.current++;
    setWithMic(mic);
    setRecordings(Array(task.stages.length).fill(null));
    started.current = Date.now();
    setQi(0);
    ask(0);
  };

  /* ---------- вопрос: озвучиваем, затем отвечаем ---------- */
  const ask = (i: number) => {
    setPhase("asking");
    const text = task.stages[i].text;
    const synth = typeof window !== "undefined" ? window.speechSynthesis : undefined;
    if (!synth) {
      startAnswer(i);
      return;
    }
    synth.cancel();
    const run = runRef.current;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-GB";
    u.rate = 0.95;
    const v = synth.getVoices().find((x) => x.lang.replace("_", "-").startsWith("en-GB"));
    if (v) u.voice = v;
    const go = () => run === runRef.current && startAnswer(i);
    u.onend = go;
    u.onerror = go;
    synth.speak(u);
    // страховка: некоторые браузеры не присылают onend
    window.setTimeout(go, text.length * 90 + 2500);
  };

  const startAnswer = (i: number) => {
    if (answerStartedRef.current >= i) return; // уже начат (onend и страховочный таймер)
    answerStartedRef.current = i;
    setPhase("answering");
    setLeft(task.stages[i].seconds);
    const stream = streamRef.current;
    if (micOnRef.current && stream && typeof MediaRecorder !== "undefined") {
      chunksRef.current = [];
      const rec = new MediaRecorder(stream);
      rec.ondataavailable = (e) => e.data.size && chunksRef.current.push(e.data);
      rec.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        const url = URL.createObjectURL(blob);
        urlsRef.current.push(url);
        setRecordings((r) => {
          const next = [...r];
          next[i] = url;
          return next;
        });
      };
      rec.start();
      recorderRef.current = rec;
      cancelAnimationFrame(rafRef.current);
      rafRef.current = requestAnimationFrame(loop);
    }
  };

  const next = useCallback(() => {
    recorderRef.current?.state === "recording" && recorderRef.current.stop();
    recorderRef.current = null;
    cancelAnimationFrame(rafRef.current);
    if (qi < task.stages.length - 1) {
      const n = qi + 1;
      setQi(n);
      ask(n);
    } else {
      setPhase("done");
      saveAttempt({
        slug: task.slug,
        title: task.title,
        paper: task.paper,
        part: task.part,
        kind: "speaking",
        answered: task.stages.length,
        seconds: Math.round((Date.now() - started.current) / 1000),
        date: new Date().toISOString(),
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qi, task]);

  /* ---------- обратный отсчёт ---------- */
  useEffect(() => {
    if (phase !== "answering") return;
    if (left <= 0) {
      next();
      return;
    }
    const id = window.setTimeout(() => setLeft((l) => l - 1), 1000);
    return () => window.clearTimeout(id);
  }, [phase, left, next]);

  const restart = () => {
    window.speechSynthesis?.cancel();
    answerStartedRef.current = Infinity;
    runRef.current++;
    setPhase("intro");
    setQi(0);
  };

  const progress =
    phase === "done" ? 1 : phase === "intro" ? 0 : (qi + (phase === "answering" ? 0.5 : 0)) / task.stages.length;

  return (
    <FocusShell title={`Speaking · ${task.part}`} progress={progress}>
      <div className={styles.wrap}>
        <AnimatePresence mode="wait">
          {phase === "intro" && (
            <motion.section
              key="intro"
              className={styles.card}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.5, ease: ease.out }}
            >
              <div className={styles.micIcon}>
                <Mic size={28} />
              </div>
              <span className={styles.kicker}>
                {task.part} · {task.type}
              </span>
              <h1 className={styles.title}>{task.title}</h1>
              <p className={styles.lead}>{task.instruction}</p>
              <ul className={styles.facts}>
                <li>{task.stages.length} этапов</li>
                <li>≈ {Math.ceil(task.stages.reduce((n, st) => n + st.seconds, 0) / 60)} мин разговора</li>
                <li>вопросы озвучиваются</li>
              </ul>
              <div className={styles.actions}>
                <button className={styles.primaryBtn} onClick={enableMic}>
                  <Mic size={17} /> Включить микрофон и начать
                </button>
                <button className={styles.secondaryBtn} onClick={() => begin(false)}>
                  <MicOff size={17} /> Без записи
                </button>
              </div>
              {micError && <p className={styles.error}>{micError}</p>}
              <p className={styles.privacy}>Записи остаются только в этой вкладке браузера и никуда не отправляются.</p>
            </motion.section>
          )}

          {(phase === "asking" || phase === "answering") && (
            <motion.section
              key={`q${qi}`}
              className={styles.stage}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.45, ease: ease.out }}
            >
              <span className={styles.counter}>
                {q.label ? `${q.label} · ` : ""}
                {qi + 1} из {task.stages.length}
              </span>
              <h2 className={cn(styles.question, (q.mindmap || q.images) && styles.questionSmall)}>{q.text}</h2>
              {q.images && (
                <div className={styles.pictures}>
                  {q.question && <p className={styles.picQuestion}>{q.question}</p>}
                  <div className={styles.picGrid}>
                    {q.images.map((key) => {
                      const Scene = SPEAKING_SCENES[key];
                      return Scene ? (
                        <figure key={key} className={styles.picture}>
                          <Scene />
                        </figure>
                      ) : null;
                    })}
                  </div>
                </div>
              )}
              {q.mindmap && (
                <div className={styles.mindmap}>
                  <div className={styles.mmCenter}>{q.mindmap.center}</div>
                  <ul className={styles.mmPrompts}>
                    {q.mindmap.prompts.map((p) => (
                      <li key={p}>{p}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className={styles.status}>
                {phase === "asking" ? (
                  <span className={styles.listening}>
                    <Volume2 size={16} /> Экзаменатор задаёт вопрос…
                  </span>
                ) : (
                  <span className={cn(styles.listening, withMic && styles.rec)}>
                    {withMic ? (
                      <>
                        <span className={styles.recDot} /> Идёт запись
                      </>
                    ) : (
                      "Отвечайте вслух"
                    )}
                  </span>
                )}
              </div>

              <div className={styles.meter}>
                <ProgressRing
                  value={phase === "answering" ? (left / q.seconds) * 100 : 100}
                  size={q.mindmap || q.images ? 110 : 150}
                  stroke={8}
                  colors={left <= 5 && phase === "answering" ? ["#F59E0B", "#F87171"] : ["#8B5CF6", "#e2b77a"]}
                >
                  <span className={styles.seconds}>{phase === "answering" ? left : "…"}</span>
                </ProgressRing>
                {withMic && (
                  <div className={styles.levels} aria-hidden="true">
                    {Array.from({ length: LEVEL_BARS }).map((_, i) => (
                      <span
                        key={i}
                        ref={(el) => {
                          barsRef.current[i] = el;
                        }}
                        className={styles.level}
                      />
                    ))}
                  </div>
                )}
              </div>

              <button className={styles.nextBtn} onClick={next} disabled={phase !== "answering"}>
                {qi < task.stages.length - 1 ? "Дальше" : "Завершить"} <ArrowRight size={16} />
              </button>
            </motion.section>
          )}

          {phase === "done" && (
            <motion.section
              key="done"
              className={styles.doneWrap}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: ease.out }}
            >
              <div className={styles.card}>
                <div className={cn(styles.micIcon, styles.micDone)}>
                  <Check size={28} />
                </div>
                <h1 className={styles.title}>Отлично, {task.part} пройден</h1>
                <p className={styles.lead}>
                  {withMic
                    ? "Прослушайте свои ответы: обратите внимание на паузы, развёрнутость и разнообразие лексики."
                    : "В следующий раз включите микрофон — запись помогает услышать себя со стороны."}
                </p>
                <div className={styles.actions}>
                  {mock && (
                    <Link href="/mock" className={styles.primaryBtn}>
                      <Timer size={16} /> К пробному экзамену
                    </Link>
                  )}
                  <button className={mock ? styles.secondaryBtn : styles.primaryBtn} onClick={restart}>
                    <RotateCcw size={16} /> Ещё раз
                  </button>
                  <Link href="/practice" className={styles.secondaryBtn}>
                    <ListChecks size={16} /> Все задания
                  </Link>
                  <Link href="/dashboard" className={styles.secondaryBtn}>
                    <LayoutGrid size={16} /> Кабинет
                  </Link>
                </div>
              </div>

              <ol className={styles.answers}>
                {task.stages.map((qq, i) => (
                  <li key={i} className={styles.answer}>
                    <span className={styles.answerN}>{i + 1}</span>
                    <div className={styles.answerBody}>
                      <p>{qq.text}</p>
                      {recordings[i] ? (
                        <audio controls src={recordings[i]!} className={styles.audio} />
                      ) : (
                        <span className={styles.noRec}>{withMic ? "Запись обрабатывается…" : "Без записи"}</span>
                      )}
                    </div>
                  </li>
                ))}
              </ol>

              <div className={styles.tips}>
                <h3>Как отвечать в {task.part}</h3>
                <ul>
                  {task.tips.map((t) => (
                    <li key={t}>
                      <Check size={14} /> {t}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.section>
          )}
        </AnimatePresence>
      </div>
    </FocusShell>
  );
}
