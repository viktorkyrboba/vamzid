"use client";

import { Pause, Play, Square, Volume2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/cn";
import styles from "./TaskRunner.module.css";

const MAX_PLAYS = 2;
const BARS = 36;

type State = "loading" | "idle" | "playing" | "paused" | "unsupported";
type Gender = "f" | "m" | null;

const FEMALE = /female|libby|sonia|serena|kate|hazel|martha|susan|mia|fiona|maisie|emma|amy|zira|aria|jenny/i;
const MALE = /male|daniel|george|ryan|arthur|thomas|oliver|alfie|ethan|brian|guy|david|mark|james/i;

/** Абзац «M: текст» → голос и текст. Абзацы без метки читаются основным голосом. */
function parseChunk(raw: string): { gender: Gender; text: string } {
  const m = raw.match(/^([MF]):\s*/);
  if (!m) return { gender: null, text: raw };
  return { gender: m[1] === "M" ? "m" : "f", text: raw.slice(m[0].length) };
}

/**
 * Озвучка сценария через Web Speech API (британские голоса, если они есть в системе).
 * Текст разбит на абзацы: длинные фразы в некоторых браузерах обрываются.
 * Как на экзамене — две прослушки.
 */
export function ListeningPlayer({ script, label = "Запись", compact = false }: { script: string; label?: string; compact?: boolean }) {
  const [state, setState] = useState<State>("loading");
  const [progress, setProgress] = useState(0);
  const [plays, setPlays] = useState(0);
  const voicesRef = useRef<{ f: SpeechSynthesisVoice | null; m: SpeechSynthesisVoice | null; any: SpeechSynthesisVoice | null }>({
    f: null,
    m: null,
    any: null,
  });
  const runId = useRef(0);

  const chunks = script
    .split(/\n\n+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map(parseChunk);
  const total = chunks.reduce((n, c) => n + c.text.length, 0);

  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      setState("unsupported");
      return;
    }
    const synth = window.speechSynthesis;
    const pick = () => {
      const all = synth.getVoices();
      const gb = all.filter((v) => v.lang.replace("_", "-").startsWith("en-GB"));
      const en = all.filter((v) => v.lang.startsWith("en"));
      const pool = gb.length ? gb : en;
      const f = pool.find((v) => FEMALE.test(v.name)) ?? en.find((v) => FEMALE.test(v.name)) ?? null;
      const m = pool.find((v) => MALE.test(v.name) && !FEMALE.test(v.name)) ?? en.find((v) => MALE.test(v.name) && !FEMALE.test(v.name)) ?? null;
      voicesRef.current = { f, m, any: pool[0] ?? null };
    };
    pick();
    synth.addEventListener("voiceschanged", pick);
    setState("idle");
    return () => {
      synth.removeEventListener("voiceschanged", pick);
      synth.cancel();
    };
  }, []);

  const play = useCallback(() => {
    const synth = window.speechSynthesis;
    if (state === "paused") {
      synth.resume();
      setState("playing");
      return;
    }
    synth.cancel();
    const id = ++runId.current;
    let done = 0;
    setProgress(0);
    const v = voicesRef.current;
    chunks.forEach(({ gender, text }, i) => {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "en-GB";
      u.rate = 0.93;
      const voice = gender === "m" ? v.m ?? v.any : gender === "f" ? v.f ?? v.any : v.f ?? v.any;
      if (voice) u.voice = voice;
      // если отдельного мужского голоса нет — хотя бы понижаем тон
      if (gender === "m" && !v.m) u.pitch = 0.75;
      const offset = done;
      u.onboundary = (e) => {
        if (runId.current === id) setProgress((offset + e.charIndex) / total);
      };
      u.onend = () => {
        if (runId.current !== id) return;
        setProgress((offset + text.length) / total);
        if (i === chunks.length - 1) {
          setState("idle");
          setPlays((p) => p + 1);
        }
      };
      done += text.length;
      synth.speak(u);
    });
    setState("playing");
  }, [chunks, state, total]);

  const pause = () => {
    window.speechSynthesis.pause();
    setState("paused");
  };

  const stop = () => {
    runId.current++;
    window.speechSynthesis.cancel();
    setState("idle");
    setProgress(0);
  };

  if (state === "unsupported") {
    return (
      <div className={styles.player}>
        <p className={styles.playerNote}>
          Ваш браузер не поддерживает озвучку текста. Откройте задание в Chrome, Edge или Safari, либо
          посмотрите расшифровку после проверки.
        </p>
      </div>
    );
  }

  const exhausted = plays >= MAX_PLAYS && state === "idle";
  const playing = state === "playing";

  return (
    <div className={cn(styles.player, playing && styles.playerOn, compact && styles.playerCompact)}>
      <div className={styles.playerTop}>
        <button
          className={styles.playBtn}
          onClick={(e) => {
            e.stopPropagation();
            if (playing) pause();
            else play();
          }}
          disabled={exhausted || state === "loading"}
          aria-label={playing ? "Пауза" : "Слушать"}
        >
          {playing ? <Pause size={compact ? 18 : 22} /> : <Play size={compact ? 18 : 22} style={{ marginLeft: 3 }} />}
        </button>

        <div className={styles.playerInfo}>
          <span className={styles.playerTitle}>
            <Volume2 size={15} /> {label}
          </span>
          <span className={styles.playerSub}>
            {exhausted
              ? "Прослушано дважды — как на экзамене"
              : `Прослушивание ${Math.min(plays + 1, MAX_PLAYS)} из ${MAX_PLAYS}`}
          </span>
        </div>

        {(playing || state === "paused") && (
          <button
            className={styles.stopBtn}
            onClick={(e) => {
              e.stopPropagation();
              stop();
            }}
            aria-label="Остановить"
          >
            <Square size={14} />
          </button>
        )}
      </div>

      {!compact && (
        <div className={styles.wave} aria-hidden="true">
          {Array.from({ length: BARS }).map((_, i) => {
            const passed = i / BARS < progress;
            return (
              <span
                key={i}
                className={cn(styles.bar, passed && styles.barPassed, playing && styles.barLive)}
                style={{
                  height: `${28 + Math.abs(Math.sin(i * 1.7)) * 60 + (i % 3) * 6}%`,
                  animationDelay: `${(i % 7) * 0.09}s`,
                }}
              />
            );
          })}
        </div>
      )}
      {compact && (
        <div className={styles.thinTrack} aria-hidden="true">
          <span style={{ width: `${progress * 100}%` }} />
        </div>
      )}
    </div>
  );
}
