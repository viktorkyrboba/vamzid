"use client";

import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";
import { Reveal } from "./Reveal";
import { ease } from "@/lib/motion";
import styles from "./SectionHeading.module.css";
import { cn } from "@/lib/cn";

interface Props {
  eyebrow: string;
  title: ReactNode;
  lead?: ReactNode;
  align?: "left" | "center";
}

/** Заголовок секции: eyebrow, заголовок «выезжает» из-под маски, затем подзаголовок. */
export function SectionHeading({ eyebrow, title, lead, align = "left" }: Props) {
  const reduce = useReducedMotion();
  return (
    <div className={cn(styles.wrap, align === "center" && styles.center)}>
      <Reveal>
        <span className={styles.eyebrow}>{eyebrow}</span>
      </Reveal>
      <div className={styles.mask}>
        <motion.h2
          className={styles.title}
          initial={reduce ? false : { y: "105%", rotate: 2 }}
          whileInView={{ y: "0%", rotate: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 1, ease: ease.out, delay: 0.05 }}
        >
          {title}
        </motion.h2>
      </div>
      {lead && (
        <Reveal delay={0.15}>
          <p className={styles.lead}>{lead}</p>
        </Reveal>
      )}
    </div>
  );
}
