"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/cn";
import { useTilt } from "./Tilt";
import styles from "./SpotlightCard.module.css";

interface Props {
  children: ReactNode;
  className?: string;
  /** цвет подсветки под курсором */
  glow?: "violet" | "blue" | "cyan";
}

/**
 * Базовая карточка дизайн-системы: 3D-наклон за курсором, мягкий блик
 * в точке под мышью и тонкая подсвеченная рамка.
 */
export function SpotlightCard({ children, className, glow = "violet" }: Props) {
  const t = useTilt<HTMLDivElement>(6);
  return (
    <div ref={t.ref} onMouseMove={t.onMouseMove} onMouseLeave={t.onMouseLeave} className={cn(styles.card, styles[glow], className)}>
      <div className={styles.content}>{children}</div>
    </div>
  );
}
