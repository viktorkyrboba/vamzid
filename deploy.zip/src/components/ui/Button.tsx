"use client";

import Link from "next/link";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useRef, type ReactNode, type MouseEvent } from "react";
import { cn } from "@/lib/cn";
import { softSpring } from "@/lib/motion";
import styles from "./Button.module.css";

type Variant = "primary" | "secondary" | "ghost";
type Size = "sm" | "md" | "lg";

interface ButtonProps {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: Variant;
  size?: Size;
  magnetic?: boolean;
  iconRight?: ReactNode;
  className?: string;
  type?: "button" | "submit";
  ariaLabel?: string;
}

/**
 * Кнопка дизайн-системы. Варианты: primary / secondary / ghost.
 * magnetic — лёгкое притяжение к курсору (только для устройств с мышью).
 */
export function Button({
  children,
  href,
  onClick,
  variant = "primary",
  size = "md",
  magnetic = false,
  iconRight,
  className,
  type = "button",
  ariaLabel,
}: ButtonProps) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, softSpring);
  const sy = useSpring(y, softSpring);
  const innerX = useTransform(sx, (v) => v * 0.35);
  const innerY = useTransform(sy, (v) => v * 0.35);

  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!magnetic || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const dx = e.clientX - (rect.left + rect.width / 2);
    const dy = e.clientY - (rect.top + rect.height / 2);
    x.set(dx * 0.22);
    y.set(dy * 0.3);
  };

  const reset = () => {
    x.set(0);
    y.set(0);
  };

  const classes = cn(styles.btn, styles[variant], styles[size], className);

  const content = (
    <motion.span className={styles.inner} style={{ x: innerX, y: innerY }}>
      <span>{children}</span>
      {iconRight && <span className={styles.icon}>{iconRight}</span>}
    </motion.span>
  );

  return (
    <motion.div
      ref={ref}
      className={styles.wrap}
      style={{ x: sx, y: sy }}
      onMouseMove={handleMove}
      onMouseLeave={reset}
    >
      {href ? (
        <Link href={href} className={classes} aria-label={ariaLabel}>
          {content}
        </Link>
      ) : (
        <button type={type} onClick={onClick} className={classes} aria-label={ariaLabel}>
          {content}
        </button>
      )}
    </motion.div>
  );
}
