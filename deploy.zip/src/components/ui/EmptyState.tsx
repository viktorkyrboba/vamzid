import type { ReactNode } from "react";
import styles from "./EmptyState.module.css";

interface Props {
  icon: ReactNode;
  title: string;
  text: string;
  action?: ReactNode;
}

/** Пустое состояние: иконка в «орбите», короткий текст и действие. */
export function EmptyState({ icon, title, text, action }: Props) {
  return (
    <div className={styles.empty}>
      <div className={styles.iconWrap} aria-hidden="true">
        <span className={styles.orbit} />
        <span className={styles.icon}>{icon}</span>
      </div>
      <h4 className={styles.title}>{title}</h4>
      <p className={styles.text}>{text}</p>
      {action && <div className={styles.action}>{action}</div>}
    </div>
  );
}
