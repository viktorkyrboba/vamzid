"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Check, Eye, EyeOff, Loader2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { saveUser } from "@/lib/useLocalData";
import { supabase } from "@/lib/supabase";
import { authErrorText } from "@/lib/cloud";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./Auth.module.css";

type Mode = "login" | "register";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function strength(p: string) {
  let s = 0;
  if (p.length >= 8) s++;
  if (/[A-ZА-Я]/.test(p) && /[a-zа-я]/.test(p)) s++;
  if (/\d/.test(p)) s++;
  if (/[^A-Za-zА-Яа-я0-9]/.test(p) || p.length >= 12) s++;
  return s; // 0–4
}
const STRENGTH = ["Слишком короткий", "Слабый", "Средний", "Хороший", "Надёжный"];

interface FieldProps {
  id: string;
  label: string;
  type?: string;
  value: string;
  onChange: (v: string) => void;
  onBlur: () => void;
  error?: string | null;
  valid?: boolean;
  autoComplete?: string;
  right?: React.ReactNode;
}

function Field({ id, label, type = "text", value, onChange, onBlur, error, valid, autoComplete, right }: FieldProps) {
  return (
    <div className={styles.field}>
      <label htmlFor={id} className={styles.label}>
        {label}
      </label>
      <div className={cn(styles.control, error && styles.controlError, valid && styles.controlValid)}>
        <input
          id={id}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onBlur={onBlur}
          autoComplete={autoComplete}
          aria-invalid={!!error}
          aria-describedby={error ? `${id}-error` : undefined}
          className={styles.input}
        />
        {right}
        {valid && !right && (
          <span className={styles.validIcon}>
            <Check size={14} strokeWidth={3} />
          </span>
        )}
      </div>
      <AnimatePresence initial={false}>
        {error && (
          <motion.span
            id={`${id}-error`}
            className={styles.error}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2, ease: ease.out }}
          >
            {error}
          </motion.span>
        )}
      </AnimatePresence>
    </div>
  );
}

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const isReg = mode === "register";

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agree, setAgree] = useState(false);
  const [show, setShow] = useState(false);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const { cloud, session } = useAuth();

  useEffect(() => {
    if (cloud && session) router.replace(nextUrl());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cloud, session]);

  const nextUrl = () => {
    const n = new URLSearchParams(window.location.search).get("next");
    return n && n.startsWith("/") ? n : "/dashboard";
  };

  const errors = {
    name: isReg && name.trim().length < 2 ? "Введите имя" : null,
    email: !email ? "Введите email" : !EMAIL.test(email) ? "Проверьте адрес — похоже, в нём опечатка" : null,
    password: !password
      ? "Введите пароль"
      : isReg && password.length < 8
        ? "Минимум 8 символов"
        : null,
    agree: isReg && !agree ? "Нужно согласие с условиями" : null,
  };
  const show_ = (k: keyof typeof errors) => (touched[k] || submitted ? errors[k] : null);
  const valid = Object.values(errors).every((e) => !e);
  const pw = strength(password);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setFormError(null);
    setInfo(null);
    if (!valid) return;
    setLoading(true);

    /* ---------- настоящие аккаунты (Supabase) ---------- */
    if (supabase) {
      const [first, ...rest] = name.trim().split(/\s+/);
      const { data, error } = isReg
        ? await supabase.auth.signUp({
            email,
            password,
            options: {
              data: { first_name: first ?? "", last_name: rest.join(" ") },
              emailRedirectTo: `${window.location.origin}/dashboard`,
            },
          })
        : await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) {
        setFormError(authErrorText(error.message));
        return;
      }
      if (!data.session) {
        setInfo(`Мы отправили письмо на ${email}. Перейдите по ссылке из письма, чтобы подтвердить аккаунт.`);
        return;
      }
      router.push(nextUrl());
      return;
    }

    /* ---------- демо-режим: профиль только в браузере ---------- */
    await new Promise((r) => setTimeout(r, 900));
    const first = isReg ? name.trim().split(/\s+/)[0] : email.split("@")[0];
    const last = isReg ? name.trim().split(/\s+/).slice(1).join(" ") : "";
    saveUser({ firstName: first.charAt(0).toUpperCase() + first.slice(1), lastName: last, email });
    router.push(nextUrl());
  };

  const forgot = async () => {
    setFormError(null);
    setInfo(null);
    if (!supabase) {
      setInfo("Восстановление пароля работает после подключения сервера.");
      return;
    }
    if (!EMAIL.test(email)) {
      setTouched((t) => ({ ...t, email: true }));
      setFormError("Введите email, на который зарегистрирован аккаунт");
      return;
    }
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) setFormError(authErrorText(error.message));
    else setInfo(`Ссылка для смены пароля отправлена на ${email}.`);
  };

  return (
    <motion.div
      className={styles.formWrap}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: ease.out }}
    >
      <h1 className={styles.title}>{isReg ? "Создайте аккаунт" : "С возвращением"}</h1>
      <p className={styles.sub}>
        {isReg ? "Диагностика, план подготовки и прогресс по каждой части B2 First." : "Продолжите подготовку с того места, где остановились."}
      </p>

      <form className={styles.form} onSubmit={onSubmit} noValidate>
        {isReg && (
          <Field
            id="name"
            label="Имя и фамилия"
            value={name}
            onChange={setName}
            onBlur={() => setTouched((t) => ({ ...t, name: true }))}
            error={show_("name")}
            valid={touched.name && !errors.name}
            autoComplete="name"
          />
        )}
        <Field
          id="email"
          label="Email"
          type="email"
          value={email}
          onChange={setEmail}
          onBlur={() => setTouched((t) => ({ ...t, email: true }))}
          error={show_("email")}
          valid={touched.email && !errors.email}
          autoComplete="email"
        />
        <Field
          id="password"
          label="Пароль"
          type={show ? "text" : "password"}
          value={password}
          onChange={setPassword}
          onBlur={() => setTouched((t) => ({ ...t, password: true }))}
          error={show_("password")}
          autoComplete={isReg ? "new-password" : "current-password"}
          right={
            <button
              type="button"
              className={styles.eye}
              onClick={() => setShow((v) => !v)}
              aria-label={show ? "Скрыть пароль" : "Показать пароль"}
            >
              {show ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          }
        />

        {isReg && password && (
          <div className={styles.strength} aria-live="polite">
            <div className={styles.strengthBars}>
              {[0, 1, 2, 3].map((i) => (
                <span key={i} className={cn(styles.sBar, i < pw && styles[`s${pw}`])} />
              ))}
            </div>
            <span>{STRENGTH[pw]}</span>
          </div>
        )}

        {!isReg && (
          <div className={styles.row}>
            <span />
            <button type="button" className={styles.forgot} onClick={forgot}>
              Забыли пароль?
            </button>
          </div>
        )}

        {isReg && (
          <label className={cn(styles.checkbox, show_("agree") && styles.checkboxError)}>
            <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
            <span className={styles.box}>{agree && <Check size={12} strokeWidth={3} />}</span>
            <span>Согласен(на) с условиями использования и обработкой персональных данных</span>
          </label>
        )}

        <AnimatePresence>
          {(formError || info) && (
            <motion.p
              className={formError ? styles.formError : styles.formInfo}
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              role={formError ? "alert" : "status"}
            >
              {formError ?? info}
            </motion.p>
          )}
        </AnimatePresence>

        <button type="submit" className={cn(styles.submit, valid && styles.submitReady)} disabled={loading}>
          {loading ? (
            <Loader2 size={18} className={styles.spin} />
          ) : (
            <>
              {isReg ? "Создать аккаунт" : "Войти"} <ArrowRight size={17} />
            </>
          )}
        </button>
      </form>

      <p className={styles.switch}>
        {isReg ? "Уже есть аккаунт?" : "Ещё нет аккаунта?"}{" "}
        <Link href={isReg ? "/login" : "/register"}>{isReg ? "Войти" : "Зарегистрироваться"}</Link>
      </p>

      {!cloud && (
        <p className={styles.demo}>
          Демо-режим: аккаунт хранится только в этом браузере, пароль никуда не отправляется.
        </p>
      )}
    </motion.div>
  );
}
