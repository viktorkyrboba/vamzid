"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowRight, Eye, EyeOff, Loader2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { supabase } from "@/lib/supabase";
import { authErrorText } from "@/lib/cloud";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./Auth.module.css";

/** Новый пароль по ссылке из письма. Supabase сам подхватывает токен из адреса. */
export function ResetPassword() {
  const router = useRouter();
  const { ready, session } = useAuth();
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const valid = password.length >= 8;

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!supabase || !valid) return;
    setLoading(true);
    const { error: err } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (err) setError(authErrorText(err.message));
    else router.push("/dashboard");
  };

  return (
    <motion.div className={styles.formWrap} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: ease.out }}>
      <h1 className={styles.title}>Новый пароль</h1>
      {!supabase ? (
        <p className={styles.sub}>Смена пароля работает после подключения сервера.</p>
      ) : ready && !session ? (
        <>
          <p className={styles.sub}>Ссылка устарела или уже использована. Запросите новую на странице входа.</p>
          <p className={styles.switch}>
            <Link href="/login">Ко входу</Link>
          </p>
        </>
      ) : (
        <>
          <p className={styles.sub}>Придумайте новый пароль — не короче 8 символов.</p>
          <form className={styles.form} onSubmit={onSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="new-password" className={styles.label}>
                Новый пароль
              </label>
              <div className={styles.control}>
                <input
                  id="new-password"
                  type={show ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="new-password"
                  className={styles.input}
                />
                <button type="button" className={styles.eye} onClick={() => setShow((v) => !v)} aria-label={show ? "Скрыть пароль" : "Показать пароль"}>
                  {show ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </div>
            {error && (
              <p className={styles.formError} role="alert">
                {error}
              </p>
            )}
            <button type="submit" className={cn(styles.submit, valid && styles.submitReady)} disabled={loading || !valid}>
              {loading ? <Loader2 size={18} className={styles.spin} /> : <>Сохранить пароль <ArrowRight size={17} /></>}
            </button>
          </form>
        </>
      )}
    </motion.div>
  );
}
