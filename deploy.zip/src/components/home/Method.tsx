"use client";

import { AnimatePresence, motion, useInView } from "framer-motion";
import { Check, X, RotateCcw } from "lucide-react";
import { useRef, useState } from "react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./Method.module.css";

const STEPS = [
  {
    n: "01",
    title: "Диагностика",
    text: "Короткий тест показывает текущий уровень по каждому навыку и строит личный план.",
  },
  {
    n: "02",
    title: "Тренировка по частям",
    text: "Задания каждого типа экзамена с мгновенной проверкой и понятным разбором ошибок.",
  },
  {
    n: "03",
    title: "Пробный экзамен",
    text: "Полный тест на время в условиях, максимально близких к настоящему B2 First.",
  },
];

const OPTIONS = ["went", "came", "took", "got"];
const CORRECT = 0;

const SKILLS = [
  { name: "Reading", value: 78, color: "var(--violet)" },
  { name: "Use of English", value: 64, color: "#a78bfa" },
  { name: "Writing", value: 70, color: "var(--blue)" },
  { name: "Listening", value: 82, color: "var(--cyan)" },
  { name: "Speaking", value: 68, color: "#a3a9f2" },
];

function DemoQuestion() {
  const [picked, setPicked] = useState<number | null>(null);
  const answered = picked !== null;
  const right = picked === CORRECT;

  return (
    <div className={styles.demo}>
      <div className={styles.demoHead}>
        <span className={styles.badge}>Use of English · Part 1</span>
        <span className={styles.counter}>Вопрос 1 / 8</span>
      </div>

      <p className={styles.question}>
        Despite the heavy rain, the final{" "}
        <span className={cn(styles.gap, answered && (right ? styles.gapRight : styles.gapWrong))}>
          {answered ? OPTIONS[picked] : " ".repeat(8)}
        </span>{" "}
        ahead as planned.
      </p>

      <div className={styles.options}>
        {OPTIONS.map((o, i) => {
          const state = !answered ? "" : i === CORRECT ? styles.optRight : i === picked ? styles.optWrong : styles.optDim;
          return (
            <motion.button
              key={o}
              className={cn(styles.option, state)}
              onClick={() => !answered && setPicked(i)}
              disabled={answered}
              whileTap={!answered ? { scale: 0.97 } : undefined}
            >
              <span className={styles.letter}>{String.fromCharCode(65 + i)}</span>
              {o}
              {answered && i === CORRECT && <Check size={16} className={styles.optIcon} />}
              {answered && i === picked && !right && <X size={16} className={styles.optIcon} />}
            </motion.button>
          );
        })}
      </div>

      <AnimatePresence>
        {answered && (
          <motion.div
            className={cn(styles.feedback, right ? styles.fbRight : styles.fbWrong)}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.45, ease: ease.out }}
          >
            <div className={styles.fbInner}>
              <strong>{right ? "Верно!" : "Почти."}</strong> <em>go ahead</em> — «состояться, пройти по
              плану». С <em>came</em>, <em>took</em> и <em>got</em> такого устойчивого сочетания нет.
              <button className={styles.retry} onClick={() => setPicked(null)}>
                <RotateCcw size={14} /> Ещё раз
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SkillBars() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.5 });

  return (
    <div ref={ref} className={styles.progress}>
      <div className={styles.progressHead}>
        <span>Прогресс по навыкам</span>
        <span className={styles.example}>пример</span>
      </div>
      <ul className={styles.bars}>
        {SKILLS.map((s, i) => (
          <li key={s.name}>
            <div className={styles.barLabel}>
              <span>{s.name}</span>
              <span className={styles.barValue}>{s.value}%</span>
            </div>
            <div className={styles.track}>
              <motion.div
                className={styles.fill}
                style={{ background: s.color }}
                initial={{ scaleX: 0 }}
                animate={inView ? { scaleX: s.value / 100 } : undefined}
                transition={{ duration: 1.4, ease: ease.out, delay: 0.15 + i * 0.1 }}
              />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Method() {
  return (
    <section id="method" className="section">
      <div className={`container ${styles.layout}`}>
        <div>
          <SectionHeading
            eyebrow="Как это работает"
            title={
              <>
                Учитесь так, <span className="gradient-text">как сдаёте.</span>
              </>
            }
            lead="Программа Cambridge, усиленная цифровыми инструментами: короткие сессии, честная обратная связь и видимый прогресс каждый день."
          />
          <div className={styles.steps}>
            {STEPS.map((s, i) => (
              <Reveal key={s.n} delay={i * 0.08}>
                <div className={styles.step}>
                  <span className={styles.stepN}>{s.n}</span>
                  <div>
                    <h3 className={styles.stepTitle}>{s.title}</h3>
                    <p className={styles.stepText}>{s.text}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        <Reveal delay={0.1} className={styles.panelCol}>
          <div className={styles.panel}>
            <DemoQuestion />
            <SkillBars />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
