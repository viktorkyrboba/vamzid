import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SkillCarousel } from "./SkillCarousel";
import styles from "./FinalCta.module.css";

export function FinalCta() {
  return (
    <section id="start" className="section">
      <div className="container">
        <Reveal>
          <div className={styles.panel}>
            <div className={styles.glow} aria-hidden="true" />
            <div className={styles.rings} aria-hidden="true">
              <span />
              <span />
              <span />
            </div>
            <SkillCarousel />
            <span className={styles.eyebrow}>Ваш путь к B2</span>
            <h2 className={styles.title}>
              Первый шаг — <span className="gradient-text">сегодня.</span>
            </h2>
            <p className={styles.lead}>
              Создайте аккаунт, пройдите диагностику и получите план подготовки по каждой части
              экзамена.
            </p>
            <div className={styles.ctas}>
              <Button href="/register" size="lg" magnetic iconRight={<ArrowRight size={18} strokeWidth={2.2} />}>
                Создать аккаунт
              </Button>
              <Button href="/practice/uoe-part-1" size="lg" variant="secondary" magnetic>
                Попробовать задание
              </Button>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
