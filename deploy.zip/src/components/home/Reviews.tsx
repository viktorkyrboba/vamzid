import Image from "next/image";
import { Quote } from "lucide-react";
import { REVIEWS } from "@/data/reviews";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { SpotlightCard } from "@/components/ui/SpotlightCard";
import { Reveal } from "@/components/ui/Reveal";
import styles from "./Reviews.module.css";

/** Отзывы из src/data/reviews.ts. Пока список пуст, секция не выводится. */
export function Reviews() {
  if (!REVIEWS.length) return null;
  return (
    <section id="reviews" className="section">
      <div className="container">
        <SectionHeading
          eyebrow="Отзывы"
          title={
            <>
              Что говорят <span className="gradient-text">ученики.</span>
            </>
          }
        />
        <div className={styles.grid}>
          {REVIEWS.map((r, i) => (
            <Reveal key={r.name + i} delay={i * 0.06}>
              <SpotlightCard className={styles.card}>
                <Quote size={22} className={styles.quote} aria-hidden="true" />
                <p className={styles.text}>{r.text}</p>
                <div className={styles.author}>
                  {r.photo ? (
                    <Image src={r.photo} alt="" width={44} height={44} className={styles.photo} />
                  ) : (
                    <span className={styles.initial}>{r.name[0]}</span>
                  )}
                  <span>
                    <strong>{r.name}</strong>
                    <small>{r.role}</small>
                  </span>
                </div>
              </SpotlightCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
