"use client";

import { useEffect, useRef } from "react";
import styles from "./Book3D.module.css";

/**
 * Объёмная книга на CSS 3D: обложка, корешок, обрез страниц.
 * Медленно парит, поворачивается за курсором, при наведении приоткрывает обложку.
 */
export function Book3D() {
  const bookRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = bookRef.current;
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let tx = 0,
      ty = 0,
      cx = 0,
      cy = 0,
      raf = 0;
    const onMove = (e: PointerEvent) => {
      tx = (e.clientX / window.innerWidth - 0.5) * 2;
      ty = (e.clientY / window.innerHeight - 0.5) * 2;
    };
    const tick = (t: number) => {
      cx += (tx - cx) * 0.06;
      cy += (ty - cy) * 0.06;
      const float = Math.sin(t / 1400) * 8;
      el.style.transform = `translateY(${float.toFixed(2)}px) rotateX(${(8 - cy * 9).toFixed(2)}deg) rotateY(${(-30 + cx * 20).toFixed(2)}deg) rotateZ(${(2 + cx * 1.5).toFixed(2)}deg)`;
      raf = requestAnimationFrame(tick);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    raf = requestAnimationFrame(tick);
    return () => {
      window.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div className={styles.stage} aria-hidden="true">
      <div className={styles.shadow} />
      <div ref={bookRef} className={styles.book}>
        {/* задняя обложка */}
        <div className={`${styles.face} ${styles.back}`} />
        {/* обрез страниц: правый, верхний, нижний */}
        <div className={`${styles.face} ${styles.pagesRight}`} />
        <div className={`${styles.face} ${styles.pagesTop}`} />
        <div className={`${styles.face} ${styles.pagesBottom}`} />
        {/* корешок */}
        <div className={`${styles.face} ${styles.spine}`}>
          <span>B2 FIRST · EXAM PREPARATION</span>
        </div>
        {/* первая страница под обложкой */}
        <div className={`${styles.face} ${styles.firstPage}`}>
          <span className={styles.pageKicker}>Unit 1</span>
          <span className={styles.pageTitle}>Getting ready for B2</span>
          {Array.from({ length: 9 }).map((_, i) => (
            <i key={i} style={{ width: `${70 + ((i * 37) % 28)}%` }} />
          ))}
        </div>
        {/* обложка (открывается на петле) */}
        <div className={styles.cover}>
          <div className={`${styles.face} ${styles.coverFront}`}>
            <div className={styles.frame} />
            <svg className={styles.emblem} viewBox="-40 -40 80 80" aria-hidden="true">
              <defs>
                <linearGradient id="b3d-gold" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#f6d79a" />
                  <stop offset="0.5" stopColor="#d9a55c" />
                  <stop offset="1" stopColor="#f3cf8d" />
                </linearGradient>
              </defs>
              <ellipse rx="34" ry="13" transform="rotate(-24)" fill="none" stroke="url(#b3d-gold)" strokeWidth="1.6" />
              <rect x="-21" y="-21" width="42" height="42" rx="12" fill="none" stroke="url(#b3d-gold)" strokeWidth="2" />
              <text y="7" textAnchor="middle" fill="url(#b3d-gold)" fontSize="19" fontWeight="800" fontFamily="var(--font-display)">
                B2
              </text>
            </svg>
            <span className={styles.course}>Practice Course</span>
            <span className={styles.big}>B2</span>
            <span className={styles.first}>First</span>
            <span className={styles.rule} />
            <span className={styles.prep}>Exam Preparation</span>
            <span className={styles.brand}>FCE B2 PREP</span>
            <div className={styles.sheen} />
          </div>
          <div className={`${styles.face} ${styles.coverInside}`} />
        </div>
      </div>
    </div>
  );
}
