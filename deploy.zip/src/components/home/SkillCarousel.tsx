"use client";

import Link from "next/link";
import { BookOpenText, Headphones, Layers, Mic, PenLine } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import styles from "./SkillCarousel.module.css";

const SKILLS: Array<{ title: string; meta: string; icon: LucideIcon; href: string }> = [
  { title: "Reading", meta: "Parts 5–7", icon: BookOpenText, href: "/practice/reading-part-5" },
  { title: "Use of English", meta: "Parts 1–4", icon: Layers, href: "/practice/uoe-part-1" },
  { title: "Writing", meta: "Essay · Article · Email", icon: PenLine, href: "/practice/writing-part-1" },
  { title: "Listening", meta: "Parts 1–4", icon: Headphones, href: "/practice/listening-part-1" },
  { title: "Speaking", meta: "Parts 1–4", icon: Mic, href: "/practice/speaking-part-1" },
];

/** Вращающееся 3D-кольцо карточек навыков. Останавливается при наведении. */
export function SkillCarousel() {
  const step = 360 / SKILLS.length;
  return (
    <div className={styles.stage}>
      <div className={styles.floor} aria-hidden="true" />
      <div className={styles.ring}>
        {SKILLS.map((s, i) => {
          const Icon = s.icon;
          return (
            <Link
              key={s.title}
              href={s.href}
              className={styles.card}
              style={{ transform: `rotateY(${i * step}deg) translateZ(var(--radius))` }}
            >
              <span className={styles.icon}>
                <Icon size={22} strokeWidth={1.7} />
              </span>
              <strong>{s.title}</strong>
              <small>{s.meta}</small>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
