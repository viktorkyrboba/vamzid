import { BookOpenText, Headphones, Mic, PenLine, Clock, Layers } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { SpotlightCard } from "@/components/ui/SpotlightCard";
import { Reveal } from "@/components/ui/Reveal";
import { cn } from "@/lib/cn";
import styles from "./ExamPapers.module.css";

interface Paper {
  name: string;
  icon: LucideIcon;
  time: string;
  parts: string;
  weight: string;
  text: string;
  glow: "violet" | "blue" | "cyan";
  tags: string[];
  wide?: boolean;
}

const PAPERS: Paper[] = [
  {
    name: "Reading & Use of English",
    icon: BookOpenText,
    time: "1 ч 15 мин",
    parts: "7 частей · 52 вопроса",
    weight: "40%",
    text: "Грамматика, лексика и понимание текстов — от multiple-choice cloze до word formation и key word transformations.",
    glow: "violet",
    tags: ["Multiple-choice cloze", "Open cloze", "Word formation", "Key word transformations", "Gapped text", "Multiple matching"],
    wide: true,
  },
  {
    name: "Writing",
    icon: PenLine,
    time: "1 ч 20 мин",
    parts: "2 части",
    weight: "20%",
    text: "Обязательное эссе и один текст на выбор: статья, письмо, отчёт или рецензия.",
    glow: "blue",
    tags: ["Essay", "Article", "Review"],
  },
  {
    name: "Listening",
    icon: Headphones,
    time: "≈ 40 мин",
    parts: "4 части · 30 вопросов",
    weight: "20%",
    text: "Короткие диалоги, интервью и монологи с заданиями на понимание деталей и мнений.",
    glow: "cyan",
    tags: ["Multiple choice", "Sentence completion"],
  },
  {
    name: "Speaking",
    icon: Mic,
    time: "14 мин",
    parts: "4 части · в паре",
    weight: "20%",
    text: "Интервью, сравнение фотографий, совместное обсуждение и дискуссия с экзаменатором.",
    glow: "violet",
    tags: ["Interview", "Long turn", "Collaborative task"],
  },
];

export function ExamPapers() {
  return (
    <section id="exam" className="section">
      <div className="container">
        <SectionHeading
          eyebrow="Формат экзамена"
          title={
            <>
              Четыре части.
              <br />
              <span className="gradient-text">Один понятный маршрут.</span>
            </>
          }
          lead="Каждая часть B2 First — отдельный модуль платформы: теория, тренировка по типам заданий и полноценные пробные тесты на время."
        />

        <div className={styles.grid}>
          {PAPERS.map((p, i) => {
            const Icon = p.icon;
            return (
              <Reveal key={p.name} delay={i * 0.08} className={cn(styles.cell, p.wide && styles.wide)}>
                <SpotlightCard glow={p.glow} className={styles.card}>
                  <div className={styles.head}>
                    <span className={cn(styles.icon, styles[p.glow])}>
                      <Icon size={22} strokeWidth={1.8} />
                    </span>
                    <span className={styles.weight}>
                      {p.weight}
                      <small>итоговой оценки</small>
                    </span>
                  </div>

                  <h3 className={styles.name}>{p.name}</h3>
                  <p className={styles.text}>{p.text}</p>

                  <div className={styles.facts}>
                    <span>
                      <Clock size={14} /> {p.time}
                    </span>
                    <span>
                      <Layers size={14} /> {p.parts}
                    </span>
                  </div>

                  <ul className={styles.tags}>
                    {p.tags.map((t) => (
                      <li key={t}>{t}</li>
                    ))}
                  </ul>
                </SpotlightCard>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
