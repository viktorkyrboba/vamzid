"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, Trash2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { demoUser } from "@/data/demo";
import { clearHistory } from "@/lib/history";
import { resetMock } from "@/lib/mock";
import { clearUser, loadUser, saveUser } from "@/lib/useLocalData";
import { useAuth } from "@/lib/auth";
import { deleteMyAttempts, updateProfile } from "@/lib/cloud";
import { HISTORY_EVENT } from "@/lib/history";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./Settings.module.css";

const TARGETS = [
  { value: 160, label: "160 — B2, Grade C" },
  { value: 173, label: "173 — B2, Grade B" },
  { value: 176, label: "176 — уверенный B2" },
  { value: 180, label: "180 — C1, Grade A" },
];

export function Settings() {
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    examDate: demoUser.examDate,
    targetScore: demoUser.targetScore,
  });
  const [saved, setSaved] = useState(false);
  const [confirm, setConfirm] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { cloud, profile, refreshProfile, signOut } = useAuth();

  useEffect(() => {
    if (profile) {
      setForm({
        firstName: profile.first_name,
        lastName: profile.last_name,
        email: profile.email ?? "",
        examDate: profile.exam_date || demoUser.examDate,
        targetScore: profile.target_score || demoUser.targetScore,
      });
      return;
    }
    const u = loadUser();
    if (u)
      setForm({
        firstName: u.firstName ?? "",
        lastName: u.lastName ?? "",
        email: u.email ?? "",
        examDate: u.examDate || demoUser.examDate,
        targetScore: u.targetScore || demoUser.targetScore,
      });
  }, [profile]);

  const set = (k: keyof typeof form) => (v: string | number) => {
    setForm((f) => ({ ...f, [k]: v }));
    setSaved(false);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.firstName.trim()) return;
    setError(null);
    if (profile) {
      try {
        await updateProfile(profile.id, {
          first_name: form.firstName.trim(),
          last_name: form.lastName.trim(),
          exam_date: form.examDate || null,
          target_score: form.targetScore,
        });
        await refreshProfile();
      } catch {
        setError("Не удалось сохранить на сервере. Проверьте интернет и попробуйте ещё раз.");
        return;
      }
    } else {
      saveUser({ ...form, firstName: form.firstName.trim(), lastName: form.lastName.trim(), email: form.email.trim() });
    }
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };

  const danger = (id: string, action: () => void, done: string) => {
    if (confirm === id) {
      action();
      setConfirm(null);
      setNotice(done);
      window.setTimeout(() => setNotice(null), 2500);
    } else {
      setConfirm(id);
      window.setTimeout(() => setConfirm((c) => (c === id ? null : c)), 3000);
    }
  };

  return (
    <div className={styles.page}>
      <header>
        <h1 className={styles.h1}>Настройки</h1>
        <p className={styles.sub}>Профиль и цель подготовки. Данные хранятся в этом браузере.</p>
      </header>

      <motion.form
        className={styles.panel}
        onSubmit={onSubmit}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: ease.out }}
      >
        <h2 className={styles.h2}>Профиль</h2>
        <div className={styles.grid}>
          <label className={styles.field}>
            <span>Имя</span>
            <input value={form.firstName} onChange={(e) => set("firstName")(e.target.value)} required autoComplete="given-name" />
          </label>
          <label className={styles.field}>
            <span>Фамилия</span>
            <input value={form.lastName} onChange={(e) => set("lastName")(e.target.value)} autoComplete="family-name" />
          </label>
          <label className={cn(styles.field, styles.wide)}>
            <span>Email</span>
            <input
              type="email"
              value={form.email}
              onChange={(e) => set("email")(e.target.value)}
              autoComplete="email"
              readOnly={!!profile}
              title={profile ? "Email аккаунта меняется через поддержку" : undefined}
            />
          </label>
        </div>

        <h2 className={styles.h2}>Цель</h2>
        <div className={styles.grid}>
          <label className={styles.field}>
            <span>Дата экзамена</span>
            <input type="date" value={form.examDate} onChange={(e) => set("examDate")(e.target.value)} />
          </label>
          <label className={styles.field}>
            <span>Целевой балл (Cambridge English Scale)</span>
            <select value={form.targetScore} onChange={(e) => set("targetScore")(Number(e.target.value))}>
              {TARGETS.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className={styles.actions}>
          <button type="submit" className={styles.save} disabled={!form.firstName.trim()}>
            <AnimatePresence mode="wait" initial={false}>
              {saved ? (
                <motion.span key="ok" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                  <Check size={16} /> Сохранено
                </motion.span>
              ) : (
                <motion.span key="save" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                  Сохранить
                </motion.span>
              )}
            </AnimatePresence>
          </button>
          {!form.firstName.trim() && <span className={styles.hint}>Укажите имя, чтобы сохранить профиль</span>}
          {error && <span className={styles.errorText}>{error}</span>}
          {cloud && profile && <span className={styles.hint}>Сохраняется в вашем аккаунте</span>}
        </div>
      </motion.form>

      <motion.section
        className={cn(styles.panel, styles.dangerPanel)}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: ease.out, delay: 0.08 }}
      >
        <h2 className={styles.h2}>Данные</h2>
        <div className={styles.dangerRow}>
          <div>
            <strong>История попыток</strong>
            <p>Все результаты заданий в этом браузере.</p>
          </div>
          <button className={cn(styles.danger, confirm === "history" && styles.dangerConfirm)} onClick={() =>
              danger(
                "history",
                () => {
                  clearHistory();
                  if (profile)
                    deleteMyAttempts()
                      .then(() => window.dispatchEvent(new Event(HISTORY_EVENT)))
                      .catch(() => setError("Не удалось удалить историю на сервере"));
                },
                "История очищена",
              )
            }>
            <Trash2 size={15} /> {confirm === "history" ? "Точно удалить?" : "Очистить"}
          </button>
        </div>
        <div className={styles.dangerRow}>
          <div>
            <strong>Пробный экзамен</strong>
            <p>Прогресс текущего пробного экзамена.</p>
          </div>
          <button className={cn(styles.danger, confirm === "mock" && styles.dangerConfirm)} onClick={() => danger("mock", resetMock, "Пробный экзамен сброшен")}>
            <Trash2 size={15} /> {confirm === "mock" ? "Точно сбросить?" : "Сбросить"}
          </button>
        </div>
        {profile ? (
          <div className={styles.dangerRow}>
            <div>
              <strong>Аккаунт</strong>
              <p>{profile.email}. Чтобы удалить аккаунт полностью, напишите преподавателю.</p>
            </div>
            <button className={styles.danger} onClick={() => void signOut()}>
              Выйти
            </button>
          </div>
        ) : (
        <div className={styles.dangerRow}>
          <div>
            <strong>Профиль</strong>
            <p>Имя, email и цель. Кабинет вернётся к демо-профилю.</p>
          </div>
          <button
            className={cn(styles.danger, confirm === "user" && styles.dangerConfirm)}
            onClick={() =>
              danger(
                "user",
                () => {
                  clearUser();
                  setForm({ firstName: "", lastName: "", email: "", examDate: demoUser.examDate, targetScore: demoUser.targetScore });
                },
                "Профиль удалён",
              )
            }
          >
            <Trash2 size={15} /> {confirm === "user" ? "Точно удалить?" : "Удалить"}
          </button>
        </div>
        )}
        <AnimatePresence>
          {notice && (
            <motion.p className={styles.notice} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <Check size={14} /> {notice}
            </motion.p>
          )}
        </AnimatePresence>
      </motion.section>
    </div>
  );
}
