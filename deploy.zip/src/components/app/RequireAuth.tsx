"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect, type ReactNode } from "react";
import { useAuth } from "@/lib/auth";

/**
 * Кабинет доступен только после входа — если подключён сервер.
 * В локальном режиме (без ключей Supabase) пускаем всех: там демо-профиль.
 */
export function RequireAuth({ children }: { children: ReactNode }) {
  const { cloud, ready, session } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const blocked = cloud && ready && !session;

  useEffect(() => {
    if (blocked) router.replace(`/login?next=${encodeURIComponent(pathname)}`);
  }, [blocked, pathname, router]);

  if (cloud && (!ready || !session)) {
    return (
      <div style={{ display: "grid", gap: 20, maxWidth: 1320 }} aria-busy="true">
        <div className="skeleton" style={{ width: 300, height: 36 }} />
        <div className="skeleton" style={{ height: 140, borderRadius: 20 }} />
        <div className="skeleton" style={{ height: 380, borderRadius: 20 }} />
      </div>
    );
  }
  return <>{children}</>;
}
