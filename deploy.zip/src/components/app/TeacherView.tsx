"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronDown, FileText, GraduationCap, Search, Server, Users } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth";
import {
  CRITERIA,
  fetchAllAttempts,
  fetchAllReviews,
  fetchStudents,
  reviewTotal,
  saveReview,
  type CriterionKey,
  type Profile,
  type Review,
} from "@/lib/cloud";
import { TASKS } from "@/data/tasks";
import { formatDate, formatDuration, percent, type Attempt } from "@/lib/history";
import { EmptyState } from "@/components/ui/EmptyState";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./TeacherView.module.css";

type Tab = "students" | "essays";

function nameOf(p?: Profile) {
  if (!p) return "Ученик";
  const n = `${p.first_name} ${p.last_name}`.trim();
  return n || p.email || "Ученик";
}

function skillOf(slug: string) {
  return TASKS.find((t) => t.slug === slug)?.skill;
}

/** Средняя точность по лучшим попыткам каждого задания навыка. */
function skillAccuracy(attempts: Attempt[], skill: "rue" | "listening") {
  const best = new Map<string, number>();
  for (const a of attempts) {
    if (a.kind !== "quiz" || skillOf(a.slug) !== skill) continue;
    const p = percent(a) ?? 0;
    best.set(a.slug, Math.max(best.get(a.slug) ?? -1, p));
  }
  const values = Array.from(best.values());
  return values.length ? Math.round(values.reduce((x, y) => x + y, 0) / values.length) : null;
}

export function TeacherView() {
  const { cloud, profile, ready } = useAuth();
  const [tab, setTab] = useState<Tab>("students");
  const [students, setStudents] = useState<Profile[] | null>(null);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [openStudent, setOpenStudent] = useState<string | null>(null);
  const [essayId, setEssayId] = useState<string | null>(null);

  const isTeacher = profile?.role === "teacher";

  const load = useCallback(async () => {
    try {
      const [s, a, r] = await Promise.all([fetchStudents(), fetchAllAttempts(), fetchAllReviews()]);
      setStudents(s);
      setAttempts(a);
      setReviews(r);
      setError(null);
    } catch {
      setError("Не удалось загрузить данные. Проверьте интернет и обновите страницу.");
      setStudents([]);
    }
  }, []);

  useEffect(() => {
    if (cloud && isTeacher) void load();
  }, [cloud, isTeacher, load]);

  const byStudent = useMemo(() => {
    const m = new Map<string, Attempt[]>();
    for (const a of attempts) {
      if (!a.userId) continue;
      if (!m.has(a.userId)) m.set(a.userId, []);
      m.get(a.userId)!.push(a);
    }
    return m;
  }, [attempts]);

  const reviewByAttempt = useMemo(() => new Map(reviews.map((r) => [r.attempt_id, r])), [reviews]);
  const essays = attempts.filter((a) => a.kind === "writing" && a.id);
  const pending = essays.filter((a) => !reviewByAttempt.has(a.id!));
  const profileById = useMemo(() => new Map((students ?? []).map((s) => [s.id, s])), [students]);

  /* ---------- состояния доступа ---------- */
  if (!cloud) {
    return (
      <div className={styles.page}>
        <h1 className={styles.h1}>Ученики</h1>
        <div className={styles.panel}>
          <EmptyState
            icon={<Server size={22} />}
            title="Кабинет преподавателя работает с сервером"
            text="Подключите Supabase по инструкции в README — после этого здесь появятся все ученики, их результаты и эссе на проверку."
          />
        </div>
      </div>
    );
  }
  if (!ready || (profile && isTeacher && students === null)) {
    return (
      <div className={styles.page}>
        <div className="skeleton" style={{ width: 240, height: 36 }} />
        <div className="skeleton" style={{ height: 420, marginTop: 28, borderRadius: 20 }} />
      </div>
    );
  }
  if (!isTeacher) {
    return (
      <div className={styles.page}>
        <h1 className={styles.h1}>Ученики</h1>
        <div className={styles.panel}>
          <EmptyState
            icon={<GraduationCap size={22} />}
            title="Раздел для преподавателя"
            text="Доступ открывается аккаунту с ролью преподавателя. Её назначают в базе данных (см. README)."
          />
        </div>
      </div>
    );
  }

  const list = (students ?? []).filter((s) => {
    const q = query.trim().toLowerCase();
    return !q || nameOf(s).toLowerCase().includes(q) || (s.email ?? "").toLowerCase().includes(q);
  });
  const weekAgo = Date.now() - 7 * 86_400_000;
  const activeWeek = new Set(attempts.filter((a) => new Date(a.date).getTime() > weekAgo).map((a) => a.userId)).size;
  const essay = essays.find((e) => e.id === essayId) ?? null;

  return (
    <div className={styles.page}>
      <header className={styles.head}>
        <div>
          <h1 className={styles.h1}>Ученики</h1>
          <p className={styles.sub}>Успеваемость и работы на проверку</p>
        </div>
        <div className={styles.tabs} role="tablist">
          {([
            ["students", "Успеваемость", null],
            ["essays", "Эссе на проверку", pending.length],
          ] as const).map(([key, label, count]) => (
            <button key={key} role="tab" aria-selected={tab === key} className={cn(styles.tab, tab === key && styles.tabOn)} onClick={() => setTab(key)}>
              {tab === key && <motion.span layoutId="teacher-tab" className={styles.tabPill} transition={{ type: "spring", stiffness: 420, damping: 34 }} />}
              <span>
                {label}
                {count ? <b className={styles.badge}>{count}</b> : null}
              </span>
            </button>
          ))}
        </div>
      </header>

      {error && <p className={styles.error}>{error}</p>}

      <div className={styles.tiles}>
        <div className={styles.tile}>
          <Users size={18} />
          <strong>{students?.length ?? 0}</strong>
          <span>учеников</span>
        </div>
        <div className={styles.tile}>
          <Check size={18} />
          <strong>{activeWeek}</strong>
          <span>занимались за неделю</span>
        </div>
        <div className={styles.tile}>
          <FileText size={18} />
          <strong>{pending.length}</strong>
          <span>эссе ждут проверки</span>
        </div>
      </div>

      {tab === "students" ? (
        <section className={styles.panel}>
          <div className={styles.searchRow}>
            <Search size={16} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Поиск по имени или email" aria-label="Поиск ученика" />
          </div>
          {list.length === 0 ? (
            <EmptyState
              icon={<Users size={22} />}
              title={students?.length ? "Никого не нашлось" : "Пока нет учеников"}
              text={students?.length ? "Измените запрос поиска." : "Когда ученики зарегистрируются на сайте, они появятся здесь."}
            />
          ) : (
            <div className={styles.tableWrap}>
              <table className={styles.table}>
                <thead>
                  <tr>
                    <th>Ученик</th>
                    <th>Попыток</th>
                    <th>Reading & UoE</th>
                    <th>Listening</th>
                    <th>Writing</th>
                    <th>Speaking</th>
                    <th>Активность</th>
                    <th aria-label="Подробнее" />
                  </tr>
                </thead>
                <tbody>
                  {list.map((s) => {
                    const own = byStudent.get(s.id) ?? [];
                    const rue = skillAccuracy(own, "rue");
                    const lis = skillAccuracy(own, "listening");
                    const wr = own.filter((a) => a.kind === "writing").length;
                    const sp = own.filter((a) => a.kind === "speaking").length;
                    const last = own[0]?.date;
                    const isOpen = openStudent === s.id;
                    return (
                      <FragmentRow
                        key={s.id}
                        open={isOpen}
                        onToggle={() => setOpenStudent(isOpen ? null : s.id)}
                        cells={
                          <>
                            <td>
                              <span className={styles.who}>
                                <span className={styles.avatar}>{nameOf(s)[0]?.toUpperCase()}</span>
                                <span>
                                  <strong>{nameOf(s)}</strong>
                                  <small>{s.email}</small>
                                </span>
                              </span>
                            </td>
                            <td className={styles.num}>{own.length}</td>
                            <td>
                              <Meter value={rue} />
                            </td>
                            <td>
                              <Meter value={lis} />
                            </td>
                            <td className={styles.num}>{wr || "—"}</td>
                            <td className={styles.num}>{sp || "—"}</td>
                            <td className={styles.muted}>{last ? formatDate(last) : "—"}</td>
                          </>
                        }
                        detail={
                          own.length ? (
                            <ul className={styles.attempts}>
                              {own.slice(0, 12).map((a) => {
                                const r = a.id ? reviewByAttempt.get(a.id) : undefined;
                                return (
                                  <li key={a.id ?? a.date}>
                                    <span className={styles.aDate}>{formatDate(a.date)}</span>
                                    <span className={styles.aTitle}>
                                      {a.paper.replace("Reading & ", "")} · {a.part} — {a.title}
                                    </span>
                                    <span className={styles.aScore}>
                                      {a.kind === "quiz" && a.total
                                        ? `${a.correct}/${a.total} · ${percent(a)}%`
                                        : a.kind === "writing"
                                          ? r
                                            ? `${reviewTotal(r)}/20`
                                            : `${a.words} сл. · не проверено`
                                          : `${a.answered} отв.`}
                                    </span>
                                    <span className={styles.aTime}>{formatDuration(a.seconds)}</span>
                                    {a.kind === "writing" && a.id && (
                                      <button
                                        className={styles.aLink}
                                        onClick={() => {
                                          setEssayId(a.id!);
                                          setTab("essays");
                                        }}
                                      >
                                        {r ? "Открыть" : "Проверить"}
                                      </button>
                                    )}
                                  </li>
                                );
                              })}
                            </ul>
                          ) : (
                            <p className={styles.muted}>Ученик ещё не проходил задания.</p>
                          )
                        }
                      />
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      ) : (
        <section className={styles.essaysLayout}>
          <div className={styles.panel}>
            <h2 className={styles.h2}>Работы</h2>
            {essays.length === 0 ? (
              <EmptyState icon={<FileText size={22} />} title="Пока нет эссе" text="Когда ученики сдадут работы по Writing, они появятся здесь." />
            ) : (
              <ul className={styles.essayList}>
                {[...pending, ...essays.filter((e) => reviewByAttempt.has(e.id!))].map((e) => {
                  const r = reviewByAttempt.get(e.id!);
                  return (
                    <li key={e.id}>
                      <button className={cn(styles.essayItem, essayId === e.id && styles.essayOn)} onClick={() => setEssayId(e.id!)}>
                        <span className={styles.essayTop}>
                          <strong>{nameOf(profileById.get(e.userId ?? ""))}</strong>
                          <span className={r ? styles.done : styles.pending}>{r ? `${reviewTotal(r)}/20` : "ждёт"}</span>
                        </span>
                        <span className={styles.essayMeta}>
                          {e.part} · {e.title} · {e.words} сл. · {formatDate(e.date)}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <div className={styles.panel}>
            {essay ? (
              <EssayReview
                key={essay.id}
                essay={essay}
                student={profileById.get(essay.userId ?? "")}
                review={reviewByAttempt.get(essay.id!)}
                onSaved={load}
              />
            ) : (
              <EmptyState icon={<FileText size={22} />} title="Выберите работу" text="Слева — список эссе. Непроверенные стоят первыми." />
            )}
          </div>
        </section>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */

function Meter({ value }: { value: number | null }) {
  if (value == null) return <span className={styles.muted}>—</span>;
  return (
    <span className={styles.meter}>
      <span className={styles.meterTrack}>
        <span className={cn(styles.meterFill, value >= 75 ? styles.good : value < 60 && styles.low)} style={{ width: `${value}%` }} />
      </span>
      <b>{value}%</b>
    </span>
  );
}

function FragmentRow({ cells, detail, open, onToggle }: { cells: React.ReactNode; detail: React.ReactNode; open: boolean; onToggle: () => void }) {
  return (
    <>
      <tr className={cn(styles.row, open && styles.rowOpen)} onClick={onToggle}>
        {cells}
        <td>
          <motion.span className={styles.chev} animate={{ rotate: open ? 180 : 0 }}>
            <ChevronDown size={16} />
          </motion.span>
        </td>
      </tr>
      <AnimatePresence initial={false}>
        {open && (
          <tr className={styles.detailRow}>
            <td colSpan={8}>
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.3, ease: ease.out }} style={{ overflow: "hidden" }}>
                <div className={styles.detail}>{detail}</div>
              </motion.div>
            </td>
          </tr>
        )}
      </AnimatePresence>
    </>
  );
}

function EssayReview({ essay, student, review, onSaved }: { essay: Attempt; student?: Profile; review?: Review; onSaved: () => Promise<void> }) {
  const [scores, setScores] = useState<Record<CriterionKey, number>>({
    content: review?.content ?? 3,
    communicative: review?.communicative ?? 3,
    organisation: review?.organisation ?? 3,
    language: review?.language ?? 3,
  });
  const [comment, setComment] = useState(review?.comment ?? "");
  const [state, setState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const total = (Object.values(scores) as number[]).reduce((a, b) => a + b, 0);

  const save = async () => {
    setState("saving");
    try {
      await saveReview({ attempt_id: essay.id!, ...scores, comment: comment.trim() });
      await onSaved();
      setState("saved");
    } catch {
      setState("error");
    }
  };

  return (
    <div className={styles.review}>
      <div className={styles.reviewHead}>
        <div>
          <span className={styles.kicker}>
            {essay.paper} · {essay.part}
          </span>
          <h2 className={styles.h2}>{nameOf(student)}</h2>
          <p className={styles.muted}>
            {formatDate(essay.date)} · {essay.words} слов · время {formatDuration(essay.seconds)}
            {essay.selfCheck != null && ` · самопроверка ${Math.round(essay.selfCheck * 100)}%`}
          </p>
        </div>
        <div className={styles.total}>
          <strong>{total}</strong>
          <span>/ 20</span>
        </div>
      </div>

      {essay.prompt && <p className={styles.prompt}>{essay.prompt}</p>}
      <article className={styles.essayText}>
        {(essay.text ?? "").split(/\n\s*\n/).filter((p) => p.trim()).map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </article>

      <div className={styles.criteria}>
        {CRITERIA.map((c) => (
          <div key={c.key} className={styles.criterion}>
            <div>
              <strong>{c.label}</strong>
              <small>{c.hint}</small>
            </div>
            <div className={styles.scale} role="radiogroup" aria-label={c.label}>
              {[0, 1, 2, 3, 4, 5].map((v) => (
                <button
                  key={v}
                  role="radio"
                  aria-checked={scores[c.key] === v}
                  className={cn(styles.scaleBtn, scores[c.key] === v && styles.scaleOn)}
                  onClick={() => {
                    setScores((s) => ({ ...s, [c.key]: v }));
                    setState("idle");
                  }}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <label className={styles.commentLabel}>
        Комментарий для ученика
        <textarea
          value={comment}
          onChange={(e) => {
            setComment(e.target.value);
            setState("idle");
          }}
          rows={5}
          placeholder="Что получилось хорошо, что исправить в следующий раз…"
        />
      </label>

      <div className={styles.reviewActions}>
        <button className={styles.save} onClick={save} disabled={state === "saving"}>
          {state === "saving" ? "Сохранение…" : review ? "Обновить оценку" : "Отправить оценку"}
        </button>
        {state === "saved" && (
          <span className={styles.savedText}>
            <Check size={14} /> Ученик увидит оценку в кабинете
          </span>
        )}
        {state === "error" && <span className={styles.errorText}>Не удалось сохранить, попробуйте ещё раз</span>}
      </div>
    </div>
  );
}
