"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  LayoutGrid,
  ListChecks,
  Activity,
  BookOpenText,
  PenLine,
  Headphones,
  Mic,
  Timer,
  Settings,
  LogOut,
  GraduationCap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Logo } from "@/components/ui/Logo";
import { cn } from "@/lib/cn";
import { clearUser, useUser } from "@/lib/useLocalData";
import { useAuth } from "@/lib/auth";
import styles from "./Sidebar.module.css";

interface Item {
  label: string;
  short?: string;
  icon: LucideIcon;
  href?: string;
  match?: string;
}

const MAIN: Item[] = [
  { label: "Обзор", icon: LayoutGrid, href: "/dashboard", match: "/dashboard" },
  { label: "Все задания", short: "Задания", icon: ListChecks, href: "/practice", match: "/practice" },
  { label: "Результаты", icon: Activity, href: "/results", match: "/results" },
];

const PRACTICE: Item[] = [
  { label: "Reading & UoE", icon: BookOpenText, href: "/practice#rue" },
  { label: "Writing", icon: PenLine, href: "/practice/writing-part-1" },
  { label: "Listening", icon: Headphones, href: "/practice/listening-part-2" },
  { label: "Speaking", icon: Mic, href: "/practice/speaking-part-1" },
];

const MORE: Item[] = [{ label: "Пробный экзамен", icon: Timer, href: "/mock", match: "/mock" }];

function NavItem({ item, active }: { item: Item; active: boolean }) {
  const Icon = item.icon;
  const inner = (
    <>
      {active && (
        <motion.span
          layoutId="sidebar-active"
          className={styles.activeBg}
          transition={{ type: "spring", stiffness: 400, damping: 34 }}
        />
      )}
      <Icon size={18} strokeWidth={1.8} className={styles.icon} />
      <span className={styles.label}>{item.label}</span>
      {!item.href && <span className={styles.soon}>скоро</span>}
    </>
  );

  if (!item.href) {
    return (
      <span className={cn(styles.item, styles.disabled)} aria-disabled="true">
        {inner}
      </span>
    );
  }
  return (
    <Link
      href={item.href}
      className={cn(styles.item, active && styles.active)}
      aria-current={active ? "page" : undefined}
    >
      {inner}
    </Link>
  );
}

export function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const user = useUser();
  const { cloud, signOut } = useAuth();
  const isActive = (i: Item) => !!i.match && pathname.startsWith(i.match);
  const teacherItem: Item = { label: "Ученики", icon: GraduationCap, href: "/teacher", match: "/teacher" };

  const logout = async () => {
    if (cloud) await signOut();
    clearUser();
    router.push("/");
  };

  return (
    <>
      <aside className={styles.sidebar}>
        <div className={styles.logo}>
          <Logo />
        </div>

        <nav className={styles.nav} aria-label="Меню кабинета">
          <div className={styles.group}>
            {MAIN.map((i) => (
              <NavItem key={i.label} item={i} active={isActive(i)} />
            ))}
          </div>
          {user.role === "teacher" && (
            <div className={styles.group}>
              <span className={styles.groupLabel}>Преподаватель</span>
              <NavItem item={teacherItem} active={isActive(teacherItem)} />
            </div>
          )}
          <div className={styles.group}>
            <span className={styles.groupLabel}>Практика</span>
            {PRACTICE.map((i) => (
              <NavItem key={i.label} item={i} active={false} />
            ))}
          </div>
          <div className={styles.group}>
            <span className={styles.groupLabel}>Экзамен</span>
            {MORE.map((i) => (
              <NavItem key={i.label} item={i} active={isActive(i)} />
            ))}
          </div>
        </nav>

        <div className={styles.footer}>
          <NavItem item={{ label: "Настройки", icon: Settings, href: "/settings", match: "/settings" }} active={pathname.startsWith("/settings")} />
          <div className={styles.profile}>
            <span className={styles.avatar}>{user.initials}</span>
            <span className={styles.who}>
              <span className={styles.name}>
                {user.firstName} {user.lastName}
              </span>
              <span className={styles.plan}>
                {user.demo ? "Демо-профиль" : user.role === "teacher" ? "Преподаватель" : `Цель: ${user.targetScore}+`}
              </span>
            </span>
            <button onClick={logout} className={styles.logout} aria-label="Выйти">
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </aside>

      {/* Мобильная нижняя панель */}
      <nav className={styles.tabbar} aria-label="Меню кабинета (мобильное)">
        {MAIN.map((i) => {
          const Icon = i.icon;
          const active = isActive(i);
          return (
            <Link key={i.label} href={i.href!} className={cn(styles.tab, active && styles.tabActive)}>
              <Icon size={20} strokeWidth={1.8} />
              <span>{i.short ?? i.label}</span>
            </Link>
          );
        })}
        <button className={styles.tab} onClick={logout}>
          <LogOut size={20} strokeWidth={1.8} />
          <span>Выйти</span>
        </button>
      </nav>
    </>
  );
}
