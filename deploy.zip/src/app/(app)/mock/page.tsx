import type { Metadata } from "next";
import { MockExam } from "@/components/app/MockExam";

export const metadata: Metadata = { title: "Пробный экзамен — FCE B2 Prep" };

export default function MockPage() {
  return <MockExam />;
}
