import type { Metadata } from "next";
import { TeacherView } from "@/components/app/TeacherView";

export const metadata: Metadata = { title: "Ученики — FCE B2 Prep" };

export default function TeacherPage() {
  return <TeacherView />;
}
