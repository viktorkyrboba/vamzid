import styles from "@/components/dashboard/Dashboard.module.css";

/** Skeleton кабинета: повторяет сетку, чтобы при загрузке ничего не «прыгало». */
export default function Loading() {
  return (
    <div className={styles.grid} aria-busy="true" aria-label="Загрузка кабинета">
      <div className={styles.span12} style={{ padding: "8px 0 16px" }}>
        <div className="skeleton" style={{ width: 320, height: 36 }} />
        <div className="skeleton" style={{ width: 240, height: 16, marginTop: 14 }} />
      </div>
      <div className={`${styles.span12} ${styles.stats}`}>
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={`skeleton ${styles.skelStat}`} />
        ))}
      </div>
      <div className={`skeleton ${styles.skelBig} ${styles.span8}`} />
      <div className={`skeleton ${styles.skelBig} ${styles.span4}`} />
    </div>
  );
}
