import type { Metadata } from "next";
import { ScoreChart } from "@/components/dashboard/ScoreChart";
import {
  Appear,
  AttemptsTable,
  ContinueCard,
  DemoNotice,
  Greeting,
  PaperRings,
  StatCards,
  WritingFeedback,
} from "@/components/dashboard/Widgets";
import styles from "@/components/dashboard/Dashboard.module.css";

export const metadata: Metadata = {
  title: "Личный кабинет — FCE B2 Prep",
};

export default function DashboardPage() {
  return (
    <div className={styles.grid}>
      <Appear className={styles.span12}>
        <Greeting />
      </Appear>
      <div className={styles.span12}>
        <DemoNotice />
        <StatCards />
      </div>
      <Appear i={5} className={styles.span8}>
        <ScoreChart />
      </Appear>
      <Appear i={6} className={styles.span4}>
        <ContinueCard />
      </Appear>
      <Appear i={7} className={styles.span12}>
        <PaperRings />
      </Appear>
      <Appear i={8} className={styles.span8}>
        <AttemptsTable />
      </Appear>
      <Appear i={9} className={styles.span4}>
        <WritingFeedback />
      </Appear>
    </div>
  );
}
