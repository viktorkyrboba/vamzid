import type { Metadata } from "next";
import { PracticeHub } from "@/components/app/PracticeHub";

export const metadata: Metadata = { title: "Задания — FCE B2 Prep" };

export default function PracticePage() {
  return <PracticeHub />;
}
