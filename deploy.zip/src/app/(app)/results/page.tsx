import type { Metadata } from "next";
import { ResultsView } from "@/components/app/ResultsView";

export const metadata: Metadata = { title: "Результаты — FCE B2 Prep" };

export default function ResultsPage() {
  return <ResultsView />;
}
