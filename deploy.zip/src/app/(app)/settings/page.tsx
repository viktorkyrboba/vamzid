import type { Metadata } from "next";
import { Settings } from "@/components/app/Settings";

export const metadata: Metadata = { title: "Настройки — FCE B2 Prep" };

export default function SettingsPage() {
  return <Settings />;
}
