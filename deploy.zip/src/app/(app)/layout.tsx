import { Sidebar } from "@/components/app/Sidebar";
import { RequireAuth } from "@/components/app/RequireAuth";
import styles from "./layout.module.css";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className={styles.shell}>
      <Sidebar />
      <main className={styles.main}>
        <RequireAuth>{children}</RequireAuth>
      </main>
    </div>
  );
}
