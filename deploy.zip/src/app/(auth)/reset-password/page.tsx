import type { Metadata } from "next";
import { ResetPassword } from "@/components/auth/ResetPassword";

export const metadata: Metadata = { title: "Новый пароль — FCE B2 Prep" };

export default function ResetPasswordPage() {
  return <ResetPassword />;
}
