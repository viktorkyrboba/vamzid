import Link from "next/link";
import { Logo } from "@/components/ui/Logo";
import { AuthAside } from "@/components/auth/AuthAside";
import styles from "@/components/auth/Auth.module.css";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className={styles.shell}>
      <main className={styles.main}>
        <div className={styles.top}>
          <Logo />
          <Link href="/" className={styles.back}>
            ← На главную
          </Link>
        </div>
        <div className={styles.center}>{children}</div>
      </main>
      <AuthAside />
    </div>
  );
}
