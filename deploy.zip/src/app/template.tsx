"use client";

import { motion, useReducedMotion } from "framer-motion";
import styles from "./template.module.css";

/**
 * Переход между страницами: фирменная шторка с логотипом закрывает экран
 * и уезжает вверх, открывая новую страницу.
 * Контент анимируется только по прозрачности — transform/filter у обёртки
 * сломали бы fixed-элементы (шапку, сайдбар).
 */
export default function Template({ children }: { children: React.ReactNode }) {
  const reduce = useReducedMotion();
  return (
    <>
      {!reduce && (
        <motion.div
          className={styles.curtain}
          initial={{ clipPath: "inset(0% 0% 0% 0%)" }}
          animate={{ clipPath: "inset(0% 0% 100% 0%)" }}
          transition={{ duration: 0.85, ease: [0.76, 0, 0.24, 1], delay: 0.25 }}
          aria-hidden="true"
        >
          <motion.div
            className={styles.mark}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: [0, 1, 1, 0], scale: [0.9, 1, 1, 1.04] }}
            transition={{ duration: 0.9, times: [0, 0.25, 0.7, 1] }}
          >
            <span className={styles.logo}>B2</span>
            <span className={styles.line} />
          </motion.div>
        </motion.div>
      )}
      <motion.div
        initial={reduce ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: reduce ? 0 : 0.45 }}
      >
        {children}
      </motion.div>
    </>
  );
}
