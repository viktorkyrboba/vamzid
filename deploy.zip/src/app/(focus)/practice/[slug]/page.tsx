import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { TASKS, getTask } from "@/data/tasks";
import { TaskRunner } from "@/components/practice/TaskRunner";
import { WritingRunner } from "@/components/practice/WritingRunner";
import { SpeakingRunner } from "@/components/practice/SpeakingRunner";

type Params = { slug: string };

export function generateStaticParams() {
  return TASKS.map((t) => ({ slug: t.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const task = getTask(slug);
  return { title: task ? `${task.paper} · ${task.part} — FCE B2 Prep` : "Задание — FCE B2 Prep" };
}

export default async function PracticeTaskPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const task = getTask(slug);
  if (!task) return notFound();

  if (task.kind === "writing") return <WritingRunner task={task} />;
  if (task.kind === "speaking") return <SpeakingRunner task={task} />;
  return <TaskRunner task={task} />;
}
