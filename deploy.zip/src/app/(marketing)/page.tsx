import { Hero } from "@/components/home/hero/Hero";
import { ExamPapers } from "@/components/home/ExamPapers";
import { Method } from "@/components/home/Method";
import { Teacher } from "@/components/home/Teacher";
import { Reviews } from "@/components/home/Reviews";
import { Faq } from "@/components/home/Faq";
import { FinalCta } from "@/components/home/FinalCta";

export default function HomePage() {
  return (
    <>
      <Hero />
      <ExamPapers />
      <Method />
      <Teacher />
      <Reviews />
      <Faq />
      <FinalCta />
    </>
  );
}
