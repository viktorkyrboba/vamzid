import type { Metadata, Viewport } from "next";
import { Inter, Manrope } from "next/font/google";
import { BackgroundAura } from "@/components/layout/BackgroundAura";
import { AuthProvider } from "@/lib/auth";
import "@/styles/globals.css";

const manrope = Manrope({
  subsets: ["latin", "cyrillic"],
  weight: ["500", "600", "700", "800"],
  variable: "--font-manrope",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "FCE B2 Prep — подготовка к Cambridge B2 First",
  description:
    "Платформа подготовки к экзамену Cambridge B2 First: задания в формате экзамена, проверка с объяснениями и прогресс по каждому навыку.",
};

export const viewport: Viewport = {
  themeColor: "#080D1C",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className={`${manrope.variable} ${inter.variable}`}>
      <body>
        <BackgroundAura />
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
