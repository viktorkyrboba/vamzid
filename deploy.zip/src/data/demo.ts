/**
 * Демо-данные личного кабинета. Заменяются данными API, когда появится бэкенд.
 */

export const demoUser = {
  firstName: "Анна",
  lastName: "Мунтяну",
  initials: "АМ",
  examDate: "2027-01-16",
  targetScore: 176,
};

/** Прогноз балла по шкале Cambridge English (B2: 160–179) по неделям */
export const scoreHistory = [
  { week: "1 сен", score: 148 },
  { week: "8 сен", score: 151 },
  { week: "15 сен", score: 153 },
  { week: "22 сен", score: 152 },
  { week: "29 сен", score: 156 },
  { week: "6 окт", score: 159 },
  { week: "13 окт", score: 158 },
  { week: "20 окт", score: 162 },
  { week: "27 окт", score: 165 },
  { week: "3 ноя", score: 167 },
  { week: "10 ноя", score: 170 },
  { week: "17 ноя", score: 172 },
];

export const paperProgress = [
  { key: "rue", name: "Reading & Use of English", short: "Reading & UoE", value: 74, colors: ["#8B5CF6", "#A78BFA"] as [string, string] },
  { key: "writing", name: "Writing", short: "Writing", value: 66, colors: ["#7b83eb", "#a3a9f2"] as [string, string] },
  { key: "listening", name: "Listening", short: "Listening", value: 81, colors: ["#e2b77a", "#f0d4a3"] as [string, string] },
  { key: "speaking", name: "Speaking", short: "Speaking", value: 70, colors: ["#A78BFA", "#e2b77a"] as [string, string] },
];

export type AttemptStatus = "excellent" | "good" | "review";

export const recentAttempts: Array<{
  id: string;
  date: string;
  paper: string;
  part: string;
  score: number;
  total: number;
  time: string;
  status: AttemptStatus;
}> = [
  { id: "a1", date: "17 ноя", paper: "Use of English", part: "Part 4 · Key word transformations", score: 9, total: 12, time: "14:20", status: "good" },
  { id: "a2", date: "16 ноя", paper: "Listening", part: "Part 2 · Sentence completion", score: 9, total: 10, time: "09:45", status: "excellent" },
  { id: "a3", date: "15 ноя", paper: "Reading", part: "Part 7 · Multiple matching", score: 7, total: 10, time: "16:02", status: "good" },
  { id: "a4", date: "14 ноя", paper: "Use of English", part: "Part 3 · Word formation", score: 4, total: 8, time: "07:31", status: "review" },
  { id: "a5", date: "12 ноя", paper: "Reading", part: "Part 5 · Multiple choice", score: 5, total: 6, time: "12:10", status: "excellent" },
];
