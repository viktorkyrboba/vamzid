import type { QuizTask } from "./types";

/* ==========================================================================
   Listening Parts 1, 3, 4 — оригинальные сценарии в формате B2 First.
   Строки «M:» и «F:» читаются мужским и женским голосом.
   ========================================================================== */

export const listeningPart1: QuizTask = {
  kind: "quiz",
  slug: "listening-part-1",
  skill: "listening",
  paper: "Listening",
  part: "Part 1",
  type: "Short extracts",
  title: "Eight everyday situations",
  summary: "Восемь коротких диалогов и монологов, по вопросу к каждому",
  instruction: "Вы услышите восемь не связанных между собой фрагментов. Для каждого выберите лучший ответ (A, B или C). Каждый фрагмент можно прослушать два раза.",
  minutes: 12,
  layout: "extracts",
  items: [
    {
      kind: "choice",
      n: 1,
      context: "You hear a woman talking about a new gym.",
      prompt: "What does she like most about it?",
      options: ["the price", "the opening hours", "the instructors"],
      answer: 1,
      script: "F: I joined the new gym on Park Road last month. Honestly, it isn't cheap. It's more than I was paying before, and the instructors are friendly enough, but nothing special. What really makes the difference for me is that it's open until midnight. With my shifts at the hospital, I can finally exercise after work instead of trying to fit it in at six in the morning.",
      explanation: "Цена выше прежней, инструкторы «nothing special». Главное для неё — «it's open until midnight», то есть часы работы.",
    },
    {
      kind: "choice",
      n: 2,
      context: "You hear two friends talking about a film.",
      prompt: "What do they agree about?",
      options: ["The story was too long.", "The acting was impressive.", "The ending was disappointing."],
      answer: 0,
      script: "M: So, what did you think?\n\nF: I loved the main actress. She was brilliant.\n\nM: Really? I found her a bit flat, to be honest. But the story did drag on, didn't it?\n\nF: Oh, definitely. They could have cut at least half an hour.\n\nM: Still, I didn't expect that ending at all.\n\nF: Me neither. It was the best part.",
      explanation: "Об актрисе мнения разошлись, концовка обоим понравилась. Согласны они в том, что история затянута: «could have cut at least half an hour»." ,
    },
    {
      kind: "choice",
      n: 3,
      context: "You hear a man leaving a voicemail message.",
      prompt: "Why is he calling?",
      options: ["to cancel an appointment", "to change the time of a meeting", "to ask for directions"],
      answer: 1,
      script: "M: Hi Sarah, it's James. About tomorrow, I'm still happy to meet, but my train gets in later than I thought, so could we make it half past eleven instead of ten? I know where the café is, so no need to send directions. Let me know if that works for you. Bye!",
      explanation: "Встреча в силе («still happy to meet»), дорогу он знает. Он просит перенести время: «half past eleven instead of ten»." ,
    },
    {
      kind: "choice",
      n: 4,
      context: "You hear a student talking about a school trip.",
      prompt: "How did she feel during the trip?",
      options: ["surprised by how much she enjoyed it", "disappointed with the weather", "nervous about the activities"],
      answer: 0,
      script: "F: I almost didn't go on the trip, because I'm not really an outdoor person. And it rained most of the time, which I'd expected. But the kayaking turned out to be amazing. I was laughing the whole time. I honestly didn't think I'd have so much fun. I've already signed up for next year's trip!",
      explanation: "Дождь она ожидала, так что разочарования нет. Ключ: «I honestly didn't think I'd have so much fun»." ,
    },
    {
      kind: "choice",
      n: 5,
      context: "You hear a chef talking on the radio.",
      prompt: "What advice does he give?",
      options: ["Buy fresh ingredients every day.", "Follow recipes exactly.", "Taste food while you are cooking."],
      answer: 2,
      script: "M: People often ask me for the secret to good cooking. They imagine it's about expensive ingredients or following a recipe to the letter. It's neither. The most important thing is to keep tasting as you go. A recipe can't know how salty your tomatoes are or how strong your onions are. Only you can.",
      explanation: "Он прямо отвергает дорогие продукты и точное следование рецепту («It's neither») и советует «keep tasting as you go»." ,
    },
    {
      kind: "choice",
      n: 6,
      context: "You hear a woman talking about her neighbour.",
      prompt: "What is the problem?",
      options: ["He plays loud music.", "He parks in her space.", "His dog barks."],
      answer: 1,
      script: "F: I don't mind his music, actually. He's got quite good taste. And the dog is lovely, very quiet. It's just that every evening when I get home, his car is sitting right outside my door, in the spot that's supposed to be mine. I've left him two notes, but nothing's changed.",
      explanation: "Музыка и собака её не беспокоят. Проблема: его машина стоит «in the spot that's supposed to be mine»." ,
    },
    {
      kind: "choice",
      n: 7,
      context: "You hear a man talking about learning the guitar.",
      prompt: "Why did he start playing?",
      options: ["He was given a guitar as a present.", "A friend encouraged him.", "He wanted to join a band."],
      answer: 0,
      script: "M: Everyone assumes I started because I wanted to be in a band, but that came much later. Actually, my aunt gave me an old guitar for my fourteenth birthday. I didn't really want it at first. I was more into football. But it sat in my room, and one rainy weekend I picked it up. My friend Joe taught me my first chords after that.",
      explanation: "Группа появилась позже, друг научил аккордам уже после. Начал он потому, что тётя подарила гитару на день рождения." ,
    },
    {
      kind: "choice",
      n: 8,
      context: "You hear a tour guide speaking to a group.",
      prompt: "What is she doing?",
      options: ["recommending a restaurant", "describing the history of a building", "explaining a change of plan"],
      answer: 2,
      script: "F: Right, everyone, can I have your attention? I'm afraid the castle is closed this afternoon because of a private event, so we won't be able to go inside as planned. Instead, we'll take the boat trip this afternoon and visit the castle tomorrow morning. Lunch is still at the same restaurant at one o'clock.",
      explanation: "Замок закрыт, поэтому программа меняется: «Instead, we'll take the boat trip this afternoon»." ,
    },
  ],
};

const P3_OPTIONS = [
  "I became more confident talking to strangers.",
  "I realised I spend too much money at home.",
  "I discovered how much I value routine.",
  "I learnt to deal with unexpected problems calmly.",
  "I understood the importance of planning ahead.",
  "I found it easier to make decisions.",
  "I appreciated my family more.",
  "I learnt to enjoy my own company.",
];

export const listeningPart3: QuizTask = {
  kind: "quiz",
  slug: "listening-part-3",
  skill: "listening",
  paper: "Listening",
  part: "Part 3",
  type: "Multiple matching",
  title: "Travelling alone",
  summary: "Пять говорящих: что каждый понял, путешествуя в одиночку",
  instruction: "Пять человек рассказывают, чему их научило путешествие в одиночку. Выберите из списка A–H, что говорит каждый. Три варианта лишние.",
  minutes: 8,
  layout: "listening",
  script: `Speaker one.

F: My first solo trip was to Portugal, and on the second day my bag was stolen with my passport in it. A few years earlier I would have panicked completely. Instead, I sat down, made a list, went to the police and then the embassy. It took three days to sort out, but I stayed calm the whole time. Since then, when something goes wrong, I just deal with it.

Speaker two.

M: Before I went to Japan on my own, I'd never even eaten in a restaurant alone. I thought I'd feel lonely, and I suppose I did call home quite often at first. But after a week or so, I started to really like it. I could sit in a café for hours with a book, walk wherever I wanted, and I never felt bored. Now I actually look forward to time by myself.

Speaker three.

F: I'm quite a spontaneous person, so I just booked a flight to Mexico and assumed I'd work out the rest when I got there. Big mistake. It was a holiday weekend, every hostel was full, and I spent my first night at the airport. I'm not saying you need to organise every minute, but these days I always book somewhere to stay and check the dates before I go.

Speaker four.

M: I've always been shy. At parties I'm usually the one standing in the kitchen. Travelling alone in Scotland, though, there was nobody else to ask for help, so I had to start conversations with people: on trains, in shops, at the hostel. By the end I was chatting to anyone. My friends say I'm a different person now, at least when it comes to meeting new people.

Speaker five.

F: I spent a whole summer travelling around Australia by myself. It was amazing, and I didn't miss my normal life at all. I'd happily have stayed longer. What I did miss, though I didn't expect to, was my parents and my little brother. We argue a lot at home, but being so far away made me see how much they matter to me. I phone them every Sunday now.`,
  items: [
    { kind: "choice", n: 1, prompt: "Speaker 1", options: P3_OPTIONS, answer: 3, explanation: "После кражи паспорта она не запаниковала: «I stayed calm the whole time… when something goes wrong, I just deal with it»." },
    { kind: "choice", n: 2, prompt: "Speaker 2", options: P3_OPTIONS, answer: 7, explanation: "«Now I actually look forward to time by myself». Звонки домой — отвлекающая деталь, не про семью." },
    { kind: "choice", n: 3, prompt: "Speaker 3", options: P3_OPTIONS, answer: 4, explanation: "После ночи в аэропорту: «these days I always book somewhere to stay and check the dates before I go»." },
    { kind: "choice", n: 4, prompt: "Speaker 4", options: P3_OPTIONS, answer: 0, explanation: "Застенчивый человек научился заговаривать с людьми: «By the end I was chatting to anyone»." },
    { kind: "choice", n: 5, prompt: "Speaker 5", options: P3_OPTIONS, answer: 6, explanation: "«being so far away made me see how much they matter to me». Фраза про «normal life» — ловушка для варианта C." },
  ],
};

export const listeningPart4: QuizTask = {
  kind: "quiz",
  slug: "listening-part-4",
  skill: "listening",
  paper: "Listening",
  part: "Part 4",
  type: "Interview",
  title: "A life behind the lens",
  summary: "Интервью с фотографом дикой природы, 7 вопросов",
  instruction: "Вы услышите интервью с фотографом дикой природы Маркусом Беллом. Для каждого вопроса выберите лучший ответ (A, B или C).",
  minutes: 10,
  layout: "listening",
  script: `F: Today I'm talking to Marcus Bell, a wildlife photographer whose work has appeared in magazines all over the world. Marcus, how did you get started?

M: Well, it wasn't something I planned. I studied biology at university, and I only picked up a camera because I needed pictures of birds for my final project. My professor saw them and suggested I enter a competition. I didn't win, but I was hooked.

F: Many people imagine your job is very glamorous. Is it?

M: Not really. People see the final picture, but they don't see the hours of waiting. Last year I spent eleven days in a tiny shelter in the mountains to photograph a snow leopard, and I saw it for about four minutes. Most of the job is patience, not travel or adventure.

F: What makes a good wildlife photograph, in your opinion?

M: Technically perfect pictures are everywhere now. Cameras do so much for you. For me, the best images tell you something about the animal's behaviour: a mother protecting her young, two birds arguing over food. If a photo makes you curious about the animal's life, it's done its job.

F: You've said that you worry about the effect of photographers on wildlife.

M: Yes. Some photographers get far too close, or use food to attract animals, just to get a dramatic shot. That can change how animals behave, sometimes permanently. I'd rather miss a picture than put an animal under stress.

F: Do you think social media has been good for nature photography?

M: It's a mixed picture. On the one hand, more people than ever see images of endangered species, which is fantastic. On the other, there's pressure to post something new every day, and that encourages exactly the kind of behaviour I just described.

F: What advice would you give a young person who wants to do what you do?

M: Start where you are. You don't need to fly to Africa. There's amazing wildlife in your local park. Learn about the animals first, then the camera. And be prepared to earn very little for quite a long time!

F: And what's next for you?

M: I'm working on a book about city foxes, actually. After years in remote places, I've realised some of the most interesting stories are right on our doorstep.`,
  items: [
    { kind: "choice", n: 1, prompt: "How did Marcus become interested in photography?", options: ["He won a competition at university.", "He needed photos for his studies.", "A teacher gave him a camera."], answer: 1, explanation: "«I only picked up a camera because I needed pictures of birds for my final project». Конкурс он не выиграл." },
    { kind: "choice", n: 2, prompt: "What does Marcus say about his job?", options: ["It involves a lot of waiting.", "It is more exciting than people think.", "It requires a lot of travel."], answer: 0, explanation: "«Most of the job is patience, not travel or adventure»." },
    { kind: "choice", n: 3, prompt: "According to Marcus, a good wildlife photo should", options: ["be technically perfect.", "show how an animal behaves.", "include the animal's natural habitat."], answer: 1, explanation: "«the best images tell you something about the animal's behaviour». Технически идеальных снимков, по его словам, и так полно." },
    { kind: "choice", n: 4, prompt: "What worries Marcus about some photographers?", options: ["They disturb the animals.", "They take too many pictures.", "They copy other people's ideas."], answer: 0, explanation: "Они подходят слишком близко или подкармливают животных, и это «can change how animals behave»." },
    { kind: "choice", n: 5, prompt: "What is Marcus's opinion of social media?", options: ["It has mostly harmed nature photography.", "It is the best way for young photographers to succeed.", "It has both advantages and disadvantages."], answer: 2, explanation: "«It's a mixed picture. On the one hand… On the other…»." },
    { kind: "choice", n: 6, prompt: "What advice does Marcus give young photographers?", options: ["Buy the best camera they can afford.", "Travel abroad as soon as possible.", "Study animals near where they live."], answer: 2, explanation: "«Start where you are… There's amazing wildlife in your local park. Learn about the animals first»." },
    { kind: "choice", n: 7, prompt: "Marcus's next project is about", options: ["animals living in cities.", "animals in remote mountains.", "endangered birds."], answer: 0, explanation: "«I'm working on a book about city foxes»." },
  ],
};
