import type { QuizTask } from "./types";

/* ==========================================================================
   Reading Parts 6–7 — оригинальные тексты в формате B2 First
   ========================================================================== */

const P6_SENTENCES = [
  "Most of them, however, soon discover that they enjoy learning something new.",
  "For them, the café offers a chance to feel useful again.",
  "Lena now hopes to find a larger building.",
  "It quickly became clear that the town had been waiting for something like this.",
  "Crucially, though, nothing is simply taken away and returned fixed.",
  "In these cases, volunteers can do little more than recommend recycling.",
  "Some visitors prefer to pay a professional to do the job.",
];

export const readingPart6: QuizTask = {
  kind: "quiz",
  slug: "reading-part-6",
  skill: "rue",
  paper: "Reading & Use of English",
  part: "Part 6",
  type: "Gapped text",
  title: "Fixing things, fixing friendships",
  summary: "Логика и связность текста: какое предложение пропущено",
  instruction:
    "Из статьи убрали шесть предложений. Выберите из A–G предложение, которое подходит к каждому пропуску. Одно предложение лишнее.",
  minutes: 12,
  layout: "cloze",
  gapStyle: "letter",
  segments: [
    "When Lena Hartley opened a repair café in a disused community hall three years ago, she expected a handful of visitors. On the first Saturday, more than sixty people turned up carrying broken toasters, torn jackets and bicycles with flat tyres. ",
    1,
    "\n\nThe idea is simple. Volunteers with practical skills give their time for free, and visitors bring items that would otherwise be thrown away. ",
    2,
    " Instead, the owner sits beside the volunteer and is shown how to do the repair themselves.\n\nLena admits that this approach can be slow. Some visitors arrive hoping for a quick fix and are surprised to be handed a screwdriver. ",
    3,
    " 'People leave feeling proud of what they've done,' she says. 'That's something you can't buy in a shop.'\n\nThe café has also become an important social space. Many of the regular volunteers are retired engineers and tailors who had begun to feel that their skills were no longer valued. ",
    4,
    " One of them, a former electrician called Ray, now spends every weekend teaching teenagers how to rewire lamps.\n\nNot everything can be saved, of course. Modern electronic devices are often designed in a way that makes them almost impossible to open. ",
    5,
    " Lena has written to several manufacturers about the problem, although so far only one has replied.\n\nDespite these difficulties, the café continues to grow. Last year volunteers repaired over two thousand items, and similar projects have since opened in four neighbouring towns. ",
    6,
    " 'If we can keep that many things out of the bin,' she says, 'imagine what we could do with a bit more space.'",
  ],
  items: [
    { kind: "choice", n: 1, options: P6_SENTENCES, answer: 3, explanation: "Шестьдесят человек в первый же день — значит, город «ждал чего-то подобного». Предложение D объясняет неожиданный успех." },
    { kind: "choice", n: 2, options: P6_SENTENCES, answer: 4, explanation: "После пропуска стоит Instead: «вместо этого владелец сидит рядом». Значит, перед ним сказано, чего не происходит: вещь не забирают и не возвращают готовой (E)." },
    { kind: "choice", n: 3, options: P6_SENTENCES, answer: 0, explanation: "However в A противопоставляет удивление посетителей тому, что им в итоге нравится учиться. Дальше идёт цитата о гордости. G не подходит: оно противоречит этой цитате." },
    { kind: "choice", n: 4, options: P6_SENTENCES, answer: 1, explanation: "«For them» отсылает к пенсионерам, которые чувствовали себя ненужными: кафе даёт им шанс снова быть полезными (B)." },
    { kind: "choice", n: 5, options: P6_SENTENCES, answer: 5, explanation: "«In these cases» — случаи, когда устройство невозможно открыть. Тогда остаётся только посоветовать сдать его в переработку (F)." },
    { kind: "choice", n: 6, options: P6_SENTENCES, answer: 2, explanation: "Последняя цитата — «представьте, что мы сделали бы с бо́льшим помещением». Её подготавливает предложение C о поиске здания побольше." },
  ],
};

const P7_OPTIONS = ["A · Daniel", "B · Priya", "C · Tom", "D · Elif"];

export const readingPart7: QuizTask = {
  kind: "quiz",
  slug: "reading-part-7",
  skill: "rue",
  paper: "Reading & Use of English",
  part: "Part 7",
  type: "Multiple matching",
  title: "My first job",
  summary: "Поиск конкретной информации в нескольких текстах",
  instruction: "Четыре человека рассказывают о своей первой работе. Для каждого вопроса выберите человека (A–D). Людей можно выбирать несколько раз.",
  minutes: 15,
  layout: "passage",
  sections: [
    {
      label: "A",
      title: "Daniel",
      text: "My first job was in a small bookshop near the station. I'd always loved reading, so I assumed the work would be easy, but I was wrong. The owner expected me to know where every title was kept, and on my first day I sent a customer to the wrong floor twice. What I appreciated, though, was that she never lost her temper. She simply made me a list of the sections and told me to learn it by the weekend. I still write things down like that whenever I start something new.",
    },
    {
      label: "B",
      title: "Priya",
      text: "I spent one summer working in a café at the beach. The pay was terrible, and most days I was on my feet for nine hours without a proper break. Still, I wouldn't change it. I was quite shy back then, and talking to dozens of strangers every day forced me to become more confident. By August I was chatting to customers as if I'd known them for years. The manager even asked me to come back the following summer, but by then I had a place at university in another city.",
    },
    {
      label: "C",
      title: "Tom",
      text: "I got my first job through a friend of my father's, which made me feel I had to prove I deserved it. I was an assistant in a busy office, mostly answering phones and filing documents. It wasn't exciting, but I learnt how a business actually works. The thing I found hardest was the commute: two buses each way, which meant leaving home before seven. Looking back, I think the job taught me more about organising my time than anything I studied at school.",
    },
    {
      label: "D",
      title: "Elif",
      text: "At sixteen I started helping younger children with their maths homework after school. I was nervous at first because I wasn't sure I could explain things clearly. One boy in particular found fractions really confusing, and it took weeks before he understood them. The day he got full marks on a test, his mother phoned me to say thank you — I was so happy I nearly cried. That experience is the main reason I'm now training to become a teacher.",
    },
  ],
  items: [
    { kind: "choice", n: 1, prompt: "Which person admits making mistakes at the start?", options: P7_OPTIONS, answer: 0, explanation: "Daniel: «on my first day I sent a customer to the wrong floor twice»." },
    { kind: "choice", n: 2, prompt: "Which person says the job changed their personality?", options: P7_OPTIONS, answer: 1, explanation: "Priya была застенчивой, а работа «forced me to become more confident»." },
    { kind: "choice", n: 3, prompt: "Which person mentions a long journey to work?", options: P7_OPTIONS, answer: 2, explanation: "Tom: «two buses each way, which meant leaving home before seven»." },
    { kind: "choice", n: 4, prompt: "Which person felt under pressure because of how they got the job?", options: P7_OPTIONS, answer: 2, explanation: "Tom получил работу через друга отца и чувствовал, что должен «prove I deserved it»." },
    { kind: "choice", n: 5, prompt: "Which person was offered the chance to return?", options: P7_OPTIONS, answer: 1, explanation: "Priya: «The manager even asked me to come back the following summer»." },
    { kind: "choice", n: 6, prompt: "Which person describes a very emotional moment?", options: P7_OPTIONS, answer: 3, explanation: "Elif: «I was so happy I nearly cried»." },
    { kind: "choice", n: 7, prompt: "Which person still follows a habit they learnt in the job?", options: P7_OPTIONS, answer: 0, explanation: "Daniel до сих пор всё записывает, когда начинает что-то новое, — так его научила хозяйка магазина." },
    { kind: "choice", n: 8, prompt: "Which person explains how the job influenced their career choice?", options: P7_OPTIONS, answer: 3, explanation: "Elif: «That experience is the main reason I'm now training to become a teacher»." },
    { kind: "choice", n: 9, prompt: "Which person says the job was badly paid?", options: P7_OPTIONS, answer: 1, explanation: "Priya: «The pay was terrible»." },
    { kind: "choice", n: 10, prompt: "Which person found the work boring but useful?", options: P7_OPTIONS, answer: 2, explanation: "Tom: «It wasn't exciting, but I learnt how a business actually works»." },
  ],
};
