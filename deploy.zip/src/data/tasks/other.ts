import type { QuizTask, SpeakingTask, WritingTask } from "./types";

/* ==========================================================================
   Listening, Writing, Speaking — оригинальные материалы в формате B2 First
   ========================================================================== */

export const listeningPart2: QuizTask = {
  kind: "quiz",
  slug: "listening-part-2",
  skill: "listening",
  paper: "Listening",
  part: "Part 2",
  type: "Sentence completion",
  title: "A summer with sea turtles",
  summary: "Монолог: волонтёрство в проекте по защите черепах",
  instruction:
    "Вы услышите, как девушка по имени Ханна рассказывает о волонтёрстве. Дополните предложения словом или короткой фразой. Запись можно прослушать два раза.",
  minutes: 10,
  layout: "listening",
  script: `Hi everyone. My name's Hannah, and last summer I spent six weeks volunteering at a sea turtle project on the coast of Greece. I'd like to tell you a bit about what it was like.

I actually found out about the project through a podcast. I'd been looking at websites for months, but it was an interview with one of the organisers that finally convinced me to apply.

Most volunteers were students, but there were people of all ages. The oldest was a retired dentist of seventy-two! Before we started, everyone had to attend a three-day training course, where we learnt how to identify nests and handle the baby turtles safely.

Our day started very early. We had to be on the beach by five thirty in the morning, before the sun got too hot, to look for tracks left by turtles during the night. I'd expected the early starts to be the worst part, but what I found hardest was actually the heat in the afternoons.

One of my main jobs was protecting the nests. We put a metal cage over each one, because foxes often dig up the eggs. People sometimes think birds are the biggest danger, but on that beach it was definitely the foxes.

In the evenings, we gave short talks to tourists. Many of them had no idea that bright lights on the beach confuse young turtles, so we asked hotels to switch off their lights after dark.

The highlight for me was seeing a group of about forty babies make their way to the sea. It happened just after midnight, and the whole team cheered quietly.

I came home with lots of photos, but the thing I'm proudest of is a notebook where I recorded every nest we found. If you're thinking about volunteering, my advice is simple: bring good sun cream and lots of patience!`,
  items: [
    { kind: "input", n: 1, prompt: "Hannah first heard about the project from a ___.", accepted: ["podcast"], explanation: "«I actually found out about the project through a podcast». Сайты (websites) — отвлекающий вариант." },
    { kind: "input", n: 2, prompt: "The oldest volunteer used to work as a ___.", accepted: ["dentist", "retired dentist"], explanation: "«The oldest was a retired dentist of seventy-two»." },
    { kind: "input", n: 3, prompt: "The training course lasted ___ days.", accepted: ["three", "3"], explanation: "«a three-day training course»." },
    { kind: "input", n: 4, prompt: "Volunteers had to be on the beach by ___ in the morning.", accepted: ["five thirty", "5:30", "5.30", "half past five", "5 30", "five-thirty"], explanation: "«We had to be on the beach by five thirty in the morning»." },
    { kind: "input", n: 5, prompt: "Hannah found the ___ the hardest part of the work.", accepted: ["heat", "afternoon heat", "heat in the afternoons", "heat in the afternoon"], explanation: "Она ожидала, что тяжелее всего будут ранние подъёмы, но труднее оказалась the heat in the afternoons." },
    { kind: "input", n: 6, prompt: "Metal cages protected the nests from ___.", accepted: ["foxes", "the foxes"], explanation: "Птицы — отвлекающий вариант, на этом пляже главной угрозой были foxes." },
    { kind: "input", n: 7, prompt: "Volunteers asked hotels to switch off their ___ after dark.", accepted: ["lights", "bright lights"], explanation: "«we asked hotels to switch off their lights after dark»." },
    { kind: "input", n: 8, prompt: "Hannah is proudest of the ___ she kept.", accepted: ["notebook"], explanation: "Фотографии — отвлекающий вариант. Гордится она notebook, где записывала каждое гнездо." },
  ],
};

export const writingPart1: WritingTask = {
  kind: "writing",
  slug: "writing-part-1",
  skill: "writing",
  paper: "Writing",
  part: "Part 1",
  type: "Essay",
  title: "Smartphones in the classroom",
  summary: "Эссе 140–190 слов по трём пунктам",
  instruction: "Напишите эссе на 140–190 слов. Раскройте оба пункта из заметок и добавьте собственную идею.",
  minutes: 40,
  minWords: 140,
  maxWords: 190,
  variants: [
    {
      id: "essay",
      genre: "essay",
      label: "Essay",
      context:
        "In your English class you have been talking about technology and education. Now your English teacher has asked you to write an essay.",
      question: "Should schools allow students to use smartphones during lessons?",
      notes: ["learning opportunities", "distraction", "your own idea"],
    },
  ],
};

export const writingPart2: WritingTask = {
  kind: "writing",
  slug: "writing-part-2",
  skill: "writing",
  paper: "Writing",
  part: "Part 2",
  type: "Article / Email / Review",
  title: "Choose your task",
  summary: "Один текст на выбор: статья, письмо или рецензия",
  instruction: "Выберите одно из трёх заданий и напишите текст на 140–190 слов в подходящем стиле.",
  minutes: 40,
  minWords: 140,
  maxWords: 190,
  variants: [
    {
      id: "article",
      genre: "article",
      label: "Article",
      context: "You have seen this announcement in an English-language magazine for teenagers.",
      question:
        "Articles wanted! A place that means a lot to me. Tell us about a place that is special to you. Why is it important to you? What do you do there? The best articles will be published next month.",
    },
    {
      id: "email",
      genre: "email",
      label: "Email",
      context: "You have received this email from your English-speaking friend, Alex.",
      question:
        "I'm coming to visit your town for a week in July! What's the best way to spend my time there? Is there anything I should bring? And what's the weather usually like? Write soon, Alex",
    },
    {
      id: "review",
      genre: "review",
      label: "Review",
      context: "You see this notice on an English-language website for students.",
      question:
        "Reviews wanted: apps for learning. Have you used an app that helped you learn something? Tell us what the app does, what you liked and didn't like about it, and whether you would recommend it to other students.",
    },
  ],
};

export const speakingPart1: SpeakingTask = {
  kind: "speaking",
  slug: "speaking-part-1",
  skill: "speaking",
  paper: "Speaking",
  part: "Part 1",
  type: "Interview",
  title: "Talking about yourself",
  summary: "Короткие ответы на вопросы о себе, с записью голоса",
  instruction:
    "Экзаменатор задаёт вопросы о вас. Отвечайте по 20–30 секунд: развёрнуто, с примером или причиной. Ответы записываются, чтобы вы могли их прослушать.",
  minutes: 4,
  stages: [
    { text: "Where are you from, and what do you like most about living there?", seconds: 30 },
    { text: "What do you usually do in your free time?", seconds: 30 },
    { text: "Tell us about a teacher who has influenced you.", seconds: 30 },
    { text: "How do you prefer to learn new English words? Why?", seconds: 30 },
    { text: "What kind of job would you like to do in the future?", seconds: 30 },
    { text: "Do you prefer spending time with a big group of friends or with just one or two people?", seconds: 30 },
  ],
  tips: [
    "Отвечайте развёрнуто: мнение + причина + пример.",
    "Избегайте ответов из одного слова — экзаменатору нужно услышать ваш английский.",
    "Используйте разные времена: I've been…, I used to…, I'd like to…",
    "Если забыли слово — перефразируйте, не замолкайте.",
  ],
};

export const speakingPart2: SpeakingTask = {
  kind: "speaking",
  slug: "speaking-part-2",
  skill: "speaking",
  paper: "Speaking",
  part: "Part 2",
  type: "Long turn",
  title: "Studying in different places",
  summary: "Сравнение двух картинок: минута монолога и короткий ответ",
  instruction:
    "Сравните две картинки и ответьте на вопрос над ними. Говорите около минуты без пауз. Затем коротко ответьте на вопрос, который на экзамене задают второму кандидату.",
  minutes: 3,
  stages: [
    {
      label: "Part 2",
      text: "Here are two pictures. They show people studying in different places. Compare the pictures, and say why you think the people have chosen to study in these places.",
      question: "Why have the people chosen to study in these places?",
      images: ["study-night", "study-park"],
      seconds: 60,
    },
    {
      label: "Part 2",
      text: "Which of these places would you prefer to study in? Why?",
      question: "Which of these places would you prefer to study in?",
      images: ["study-night", "study-park"],
      seconds: 30,
    },
  ],
  tips: [
    "Не описывайте каждую картинку по отдельности — сравнивайте: In the first picture…, whereas in the second…",
    "Отвечайте на вопрос над картинками, а не только перечисляйте, что на них видно.",
    "Используйте модальные глаголы для предположений: They might be…, It could be that…",
    "Заполняйте всю минуту: если мысль закончилась, добавьте сравнение или личный пример.",
  ],
};

export const speakingPart3: SpeakingTask = {
  kind: "speaking",
  slug: "speaking-part-3",
  skill: "speaking",
  paper: "Speaking",
  part: "Part 3–4",
  type: "Collaborative task + Discussion",
  title: "Why learn languages?",
  summary: "Обсуждение по схеме и вопросы для дискуссии",
  instruction:
    "На экзамене Part 3 проходит в паре. Здесь вы тренируетесь в одиночку: рассуждайте вслух о каждом пункте схемы, затем примите решение и ответьте на вопросы Part 4.",
  minutes: 8,
  stages: [
    {
      label: "Part 3",
      text: "Here are some reasons why people learn foreign languages. Talk about how important each of these reasons is.",
      seconds: 120,
      mindmap: {
        center: "Why do people learn foreign languages?",
        prompts: ["to travel", "for their career", "to make friends abroad", "to study in another country", "to enjoy films and music"],
      },
    },
    {
      label: "Part 3",
      text: "Now decide which reason is the most important for young people today.",
      seconds: 60,
      mindmap: {
        center: "Why do people learn foreign languages?",
        prompts: ["to travel", "for their career", "to make friends abroad", "to study in another country", "to enjoy films and music"],
      },
    },
    { label: "Part 4", text: "Do you think everyone should learn at least two foreign languages? Why or why not?", seconds: 40 },
    { label: "Part 4", text: "Is it better to learn a language at school or by living in another country?", seconds: 40 },
    { label: "Part 4", text: "Some people say that technology will soon make learning languages unnecessary. What do you think?", seconds: 40 },
    { label: "Part 4", text: "What is the best age to start learning a foreign language?", seconds: 40 },
  ],
  tips: [
    "В Part 3 не спешите с решением: сначала обсудите несколько пунктов.",
    "Сравнивайте варианты: This is more important than…, On the other hand…",
    "В паре вовлекайте собеседника: What do you think? Do you agree?",
    "В Part 4 обосновывайте мнение и приводите пример из жизни.",
  ],
};
