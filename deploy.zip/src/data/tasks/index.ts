import type { Skill, Task } from "./types";
import { readingPart5, uoePart1, uoePart2, uoePart3, uoePart4 } from "./rue";
import { listeningPart2, speakingPart1, speakingPart2, speakingPart3, writingPart1, writingPart2 } from "./other";
import { readingPart6, readingPart7 } from "./reading";
import { listeningPart1, listeningPart3, listeningPart4 } from "./listening";

export * from "./types";

export const TASKS: Task[] = [
  uoePart1,
  uoePart2,
  uoePart3,
  uoePart4,
  readingPart5,
  readingPart6,
  readingPart7,
  writingPart1,
  writingPart2,
  listeningPart1,
  listeningPart2,
  listeningPart3,
  listeningPart4,
  speakingPart1,
  speakingPart2,
  speakingPart3,
];

export const getTask = (slug: string) => TASKS.find((t) => t.slug === slug);

export const SKILLS: Array<{ key: Skill; title: string; text: string }> = [
  { key: "rue", title: "Reading & Use of English", text: "1 ч 15 мин · 7 частей · 40% оценки" },
  { key: "writing", title: "Writing", text: "1 ч 20 мин · 2 части · 20% оценки" },
  { key: "listening", title: "Listening", text: "≈ 40 мин · 4 части · 20% оценки" },
  { key: "speaking", title: "Speaking", text: "14 мин · 4 части · 20% оценки" },
];

/** Части экзамена, для которых заданий пока нет — показываются в каталоге как «скоро». */
/** Части экзамена, для которых заданий пока нет — показываются в каталоге как «скоро». */
export const UPCOMING: Record<Skill, string[]> = {
  rue: [],
  writing: [],
  listening: [],
  speaking: [],
};

export const taskHref = (slug: string) => `/practice/${slug}`;
