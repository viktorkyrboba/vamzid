/**
 * Отзывы учеников и родителей для главной страницы.
 *
 * Добавляйте только настоящие отзывы — с разрешения автора.
 * Пока массив пустой, блок отзывов на главной не показывается.
 *
 * Пример записи:
 * {
 *   name: "Мария К.",
 *   role: "ученица 11 класса, B2 First — Grade B",
 *   text: "Текст отзыва своими словами автора.",
 *   photo: "/images/reviews/maria.jpg", // необязательно
 * },
 */
export interface Review {
  name: string;
  role: string;
  text: string;
  photo?: string;
}

export const REVIEWS: Review[] = [];
