"use client";

import { useEffect, useState } from "react";
import { HISTORY_EVENT, loadHistory, type Attempt } from "./history";
import { fetchMyAttempts } from "./cloud";
import { useAuth } from "./auth";
import { demoUser } from "@/data/demo";

/**
 * История попыток; null — ещё загружается.
 * Вошёл в аккаунт — история с сервера, иначе — из браузера.
 */
export function useHistory() {
  const { cloud, ready, session } = useAuth();
  const [history, setHistory] = useState<Attempt[] | null>(null);
  const uid = session?.user.id;

  useEffect(() => {
    if (!ready) return;
    let alive = true;
    const read = () => {
      if (cloud && uid) {
        fetchMyAttempts()
          .then((rows) => alive && setHistory(rows))
          .catch(() => alive && setHistory(loadHistory()));
      } else {
        setHistory(loadHistory());
      }
    };
    read();
    window.addEventListener(HISTORY_EVENT, read);
    window.addEventListener("storage", read);
    return () => {
      alive = false;
      window.removeEventListener(HISTORY_EVENT, read);
      window.removeEventListener("storage", read);
    };
  }, [cloud, ready, uid]);
  return history;
}

export interface LocalUser {
  firstName: string;
  lastName?: string;
  email: string;
  examDate?: string; // YYYY-MM-DD
  targetScore?: number;
}

export function loadUser(): LocalUser | null {
  try {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? (JSON.parse(raw) as LocalUser) : null;
  } catch {
    return null;
  }
}

const USER_KEY = "fce.user.v1";
const USER_EVENT = "fce-user-change";

export function saveUser(u: LocalUser) {
  try {
    localStorage.setItem(USER_KEY, JSON.stringify(u));
    window.dispatchEvent(new Event(USER_EVENT));
  } catch {
    /* noop */
  }
}

export function clearUser() {
  try {
    localStorage.removeItem(USER_KEY);
    window.dispatchEvent(new Event(USER_EVENT));
  } catch {
    /* noop */
  }
}

/** Профиль: аккаунт на сервере, локальный профиль или демо-профиль. */
export function useUser() {
  const { profile } = useAuth();
  const demo = {
    firstName: demoUser.firstName,
    lastName: demoUser.lastName,
    initials: demoUser.initials,
    email: "",
    examDate: demoUser.examDate,
    targetScore: demoUser.targetScore,
    demo: true,
    role: "student" as "student" | "teacher",
  };
  const [local, setLocal] = useState(demo);

  useEffect(() => {
    const read = () => {
      const u = loadUser();
      if (!u || !u.firstName) {
        setLocal(demo);
        return;
      }
      const last = u.lastName ?? "";
      setLocal({
        firstName: u.firstName,
        lastName: last,
        initials: (u.firstName[0] + (last[0] ?? "")).toUpperCase(),
        email: u.email,
        examDate: u.examDate || demoUser.examDate,
        targetScore: u.targetScore || demoUser.targetScore,
        demo: false,
        role: "student",
      });
    };
    read();
    window.addEventListener(USER_EVENT, read);
    return () => window.removeEventListener(USER_EVENT, read);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (profile) {
    const first = profile.first_name || (profile.email ?? "").split("@")[0] || "Ученик";
    const last = profile.last_name ?? "";
    return {
      firstName: first,
      lastName: last,
      initials: (first[0] + (last[0] ?? "")).toUpperCase(),
      email: profile.email ?? "",
      examDate: profile.exam_date || demoUser.examDate,
      targetScore: profile.target_score || demoUser.targetScore,
      demo: false,
      role: profile.role,
    };
  }
  return local;
}
