/**
 * Motion tokens — зеркало CSS-переменных из tokens.css для framer-motion.
 */
export const ease = {
  out: [0.22, 1, 0.36, 1] as const,
  inOut: [0.65, 0, 0.35, 1] as const,
  spring: [0.34, 1.4, 0.64, 1] as const,
};

export const duration = {
  fast: 0.14,
  base: 0.24,
  slow: 0.48,
  slower: 0.9,
};

/** Пружина для magnetic-кнопок и параллакса */
export const softSpring = { stiffness: 180, damping: 18, mass: 0.6 };

/** Стандартное появление при скролле */
export const revealVariants = {
  hidden: { opacity: 0, y: 28, filter: "blur(6px)" },
  visible: (delay = 0) => ({
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.8, ease: ease.out, delay },
  }),
};
