/**
 * Работа с данными на сервере (Supabase). Все функции безопасно ничего не делают
 * в локальном режиме, когда ключи не заданы.
 */
import { supabase } from "./supabase";
import type { Attempt } from "./history";

export interface Profile {
  id: string;
  email: string | null;
  first_name: string;
  last_name: string;
  role: "student" | "teacher";
  exam_date: string | null;
  target_score: number | null;
  created_at: string;
}

interface AttemptRow {
  id: string;
  user_id: string;
  slug: string;
  title: string;
  paper: string;
  part: string;
  kind: "quiz" | "writing" | "speaking";
  correct: number | null;
  total: number | null;
  words: number | null;
  answered: number | null;
  self_check: number | null;
  seconds: number;
  essay: string | null;
  prompt: string | null;
  created_at: string;
}

export interface Review {
  id: string;
  attempt_id: string;
  teacher_id: string;
  content: number;
  communicative: number;
  organisation: number;
  language: number;
  comment: string;
  created_at: string;
  updated_at: string;
}

export const CRITERIA = [
  { key: "content", label: "Content", hint: "все пункты задания раскрыты" },
  { key: "communicative", label: "Communicative Achievement", hint: "стиль и формат подходят читателю" },
  { key: "organisation", label: "Organisation", hint: "абзацы, связность, логика" },
  { key: "language", label: "Language", hint: "лексика, грамматика, точность" },
] as const;

export type CriterionKey = (typeof CRITERIA)[number]["key"];

export const reviewTotal = (r: Pick<Review, CriterionKey>) => r.content + r.communicative + r.organisation + r.language;

export function rowToAttempt(r: AttemptRow): Attempt {
  return {
    id: r.id,
    userId: r.user_id,
    slug: r.slug,
    title: r.title,
    paper: r.paper,
    part: r.part,
    kind: r.kind,
    correct: r.correct ?? undefined,
    total: r.total ?? undefined,
    words: r.words ?? undefined,
    answered: r.answered ?? undefined,
    selfCheck: r.self_check ?? undefined,
    seconds: r.seconds,
    text: r.essay ?? undefined,
    prompt: r.prompt ?? undefined,
    date: r.created_at,
  };
}

/* ---------- Ученик ---------- */

export async function currentUserId() {
  if (!supabase) return null;
  const { data } = await supabase.auth.getSession();
  return data.session?.user.id ?? null;
}

export async function fetchProfile(id: string): Promise<Profile | null> {
  if (!supabase) return null;
  const { data, error } = await supabase.from("profiles").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return (data as Profile | null) ?? null;
}

export async function updateProfile(
  id: string,
  patch: Partial<Pick<Profile, "first_name" | "last_name" | "exam_date" | "target_score">>,
) {
  if (!supabase) return;
  const { error } = await supabase.from("profiles").update(patch).eq("id", id);
  if (error) throw error;
}

export async function insertAttempt(a: Attempt) {
  if (!supabase) return false;
  const uid = await currentUserId();
  if (!uid) return false;
  const { error } = await supabase.from("attempts").insert({
    user_id: uid,
    slug: a.slug,
    title: a.title,
    paper: a.paper,
    part: a.part,
    kind: a.kind,
    correct: a.correct ?? null,
    total: a.total ?? null,
    words: a.words ?? null,
    answered: a.answered ?? null,
    self_check: a.selfCheck ?? null,
    seconds: a.seconds,
    essay: a.text ?? null,
    prompt: a.prompt ?? null,
  });
  if (error) throw error;
  return true;
}

export async function fetchMyAttempts(): Promise<Attempt[]> {
  if (!supabase) return [];
  const uid = await currentUserId();
  if (!uid) return [];
  const { data, error } = await supabase
    .from("attempts")
    .select("*")
    .eq("user_id", uid)
    .order("created_at", { ascending: false })
    .limit(500);
  if (error) throw error;
  return (data as AttemptRow[]).map(rowToAttempt);
}

export async function deleteMyAttempts() {
  if (!supabase) return;
  const uid = await currentUserId();
  if (!uid) return;
  const { error } = await supabase.from("attempts").delete().eq("user_id", uid);
  if (error) throw error;
}

export async function fetchMyReviews(): Promise<Array<Review & { attempt: Attempt }>> {
  if (!supabase) return [];
  const uid = await currentUserId();
  if (!uid) return [];
  const { data, error } = await supabase
    .from("essay_reviews")
    .select("*, attempt:attempts!inner(*)")
    .eq("attempt.user_id", uid)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data as Array<Review & { attempt: AttemptRow }>).map((r) => ({ ...r, attempt: rowToAttempt(r.attempt) }));
}

/* ---------- Преподаватель ---------- */

export async function fetchStudents(): Promise<Profile[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.from("profiles").select("*").eq("role", "student").order("created_at", { ascending: false });
  if (error) throw error;
  return data as Profile[];
}

export async function fetchAllAttempts(): Promise<Attempt[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.from("attempts").select("*").order("created_at", { ascending: false }).limit(5000);
  if (error) throw error;
  return (data as AttemptRow[]).map(rowToAttempt);
}

export async function fetchAllReviews(): Promise<Review[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.from("essay_reviews").select("*");
  if (error) throw error;
  return data as Review[];
}

export async function saveReview(r: Pick<Review, "attempt_id" | CriterionKey | "comment">) {
  if (!supabase) return;
  const { error } = await supabase
    .from("essay_reviews")
    .upsert({ ...r, updated_at: new Date().toISOString() }, { onConflict: "attempt_id" });
  if (error) throw error;
}

/* ---------- Ошибки входа на русском ---------- */

export function authErrorText(message: string) {
  const m = message.toLowerCase();
  if (m.includes("invalid login credentials")) return "Неверный email или пароль";
  if (m.includes("email not confirmed")) return "Подтвердите email по ссылке из письма";
  if (m.includes("already registered") || m.includes("already been registered")) return "Этот email уже зарегистрирован — войдите";
  if (m.includes("password should be at least")) return "Пароль слишком короткий";
  if (m.includes("rate limit") || m.includes("too many")) return "Слишком много попыток. Попробуйте через минуту";
  if (m.includes("network") || m.includes("fetch")) return "Нет связи с сервером. Проверьте интернет";
  return "Что-то пошло не так. Попробуйте ещё раз";
}
