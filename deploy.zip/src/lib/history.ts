/**
 * История попыток в localStorage. Временное хранилище до появления бэкенда:
 * живёт в одном браузере и может быть пустым, поэтому все чтения защищены.
 */

import { isMockRun, recordMock } from "./mock";
import { insertAttempt } from "./cloud";

export { isMockRun };

export interface Attempt {
  /** id и владелец — только для попыток с сервера */
  id?: string;
  userId?: string;
  slug: string;
  title: string;
  paper: string;
  part: string;
  kind: "quiz" | "writing" | "speaking";
  correct?: number;
  total?: number;
  words?: number;
  answered?: number;
  /** доля выполненных пунктов самопроверки (Writing), 0–1 */
  selfCheck?: number;
  seconds: number;
  /** текст работы и задание (Writing) */
  text?: string;
  prompt?: string;
  date: string; // ISO
}

const KEY = "fce.history.v1";
const EVENT = "fce-history-change";

export function loadHistory(): Attempt[] {
  try {
    const raw = localStorage.getItem(KEY);
    const parsed = raw ? (JSON.parse(raw) as Attempt[]) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveAttempt(a: Attempt) {
  try {
    const next = [a, ...loadHistory()].slice(0, 200);
    localStorage.setItem(KEY, JSON.stringify(next));
    window.dispatchEvent(new Event(EVENT));
    if (isMockRun()) recordMock(a);
  } catch {
    /* storage недоступен — попытка не сохранится локально */
  }
  // если ученик вошёл в аккаунт — сохраняем и на сервер
  insertAttempt(a)
    .then((saved) => {
      if (saved) window.dispatchEvent(new Event(EVENT));
    })
    .catch(() => {
      /* сервер недоступен — попытка осталась в браузере */
    });
}

export function clearHistory() {
  try {
    localStorage.removeItem(KEY);
    window.dispatchEvent(new Event(EVENT));
  } catch {
    /* noop */
  }
}

export function bestBySlug(history: Attempt[]) {
  const map = new Map<string, Attempt>();
  for (const a of history) {
    if (a.kind !== "quiz" || a.total == null || a.correct == null) {
      if (!map.has(a.slug)) map.set(a.slug, a);
      continue;
    }
    const prev = map.get(a.slug);
    const score = a.correct / a.total;
    const prevScore = prev && prev.total ? (prev.correct ?? 0) / prev.total : -1;
    if (!prev || score > prevScore) map.set(a.slug, a);
  }
  return map;
}

export function percent(a: Attempt) {
  return a.total ? Math.round(((a.correct ?? 0) / a.total) * 100) : null;
}

export const HISTORY_EVENT = EVENT;

export function formatDuration(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString("ru-RU", { day: "numeric", month: "short" });
  } catch {
    return "";
  }
}
