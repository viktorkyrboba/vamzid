import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/**
 * Клиент Supabase. Если ключи не заданы, сайт работает в локальном режиме
 * (всё хранится в браузере) — так проект можно запустить без сервера.
 */
const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

export const cloudEnabled = Boolean(url && key);

export const supabase: SupabaseClient | null =
  cloudEnabled && typeof window !== "undefined"
    ? createClient(url, key, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } })
    : null;
