-- =====================================================================
-- FCE B2 Prep — схема базы данных Supabase
-- Запуск: Supabase → SQL Editor → вставить файл целиком → Run.
-- Скрипт можно запускать повторно: он не удаляет данные.
-- =====================================================================

-- ---------- Профили ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  first_name text not null default '',
  last_name text not null default '',
  role text not null default 'student' check (role in ('student', 'teacher')),
  exam_date date,
  target_score int check (target_score between 140 and 190),
  created_at timestamptz not null default now()
);

-- ---------- Попытки ----------
create table if not exists public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  slug text not null,
  title text not null,
  paper text not null,
  part text not null,
  kind text not null check (kind in ('quiz', 'writing', 'speaking')),
  correct int,
  total int,
  words int,
  answered int,
  self_check real,
  seconds int not null default 0,
  essay text,          -- текст работы (Writing)
  prompt text,         -- задание, на которое написана работа
  created_at timestamptz not null default now()
);
create index if not exists attempts_user_created_idx on public.attempts (user_id, created_at desc);

-- ---------- Проверка эссе ----------
create table if not exists public.essay_reviews (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null unique references public.attempts (id) on delete cascade,
  teacher_id uuid not null default auth.uid() references auth.users (id),
  content int not null check (content between 0 and 5),
  communicative int not null check (communicative between 0 and 5),
  organisation int not null check (organisation between 0 and 5),
  language int not null check (language between 0 and 5),
  comment text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- Роль преподавателя ----------
create or replace function public.is_teacher()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'teacher');
$$;

-- ---------- Профиль создаётся автоматически при регистрации ----------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, first_name, last_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'first_name', ''),
    coalesce(new.raw_user_meta_data ->> 'last_name', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Права доступа (Row Level Security) ----------
alter table public.profiles enable row level security;
alter table public.attempts enable row level security;
alter table public.essay_reviews enable row level security;

-- профили: свой — читать и менять; преподаватель видит всех
drop policy if exists "profiles: read own or teacher" on public.profiles;
create policy "profiles: read own or teacher" on public.profiles
  for select using (id = auth.uid() or public.is_teacher());

drop policy if exists "profiles: update own" on public.profiles;
create policy "profiles: update own" on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

-- роль нельзя поменять самому себе: разрешаем обновлять только эти колонки
revoke update on public.profiles from authenticated, anon;
grant update (first_name, last_name, exam_date, target_score) on public.profiles to authenticated;

-- попытки: свои — читать, добавлять, удалять; преподаватель читает все
drop policy if exists "attempts: read own or teacher" on public.attempts;
create policy "attempts: read own or teacher" on public.attempts
  for select using (user_id = auth.uid() or public.is_teacher());

drop policy if exists "attempts: insert own" on public.attempts;
create policy "attempts: insert own" on public.attempts
  for insert with check (user_id = auth.uid());

drop policy if exists "attempts: delete own" on public.attempts;
create policy "attempts: delete own" on public.attempts
  for delete using (user_id = auth.uid());

-- проверки эссе: ученик видит проверки своих работ, преподаватель — все и может их ставить
drop policy if exists "reviews: read own or teacher" on public.essay_reviews;
create policy "reviews: read own or teacher" on public.essay_reviews
  for select using (
    public.is_teacher()
    or exists (select 1 from public.attempts a where a.id = attempt_id and a.user_id = auth.uid())
  );

drop policy if exists "reviews: teacher insert" on public.essay_reviews;
create policy "reviews: teacher insert" on public.essay_reviews
  for insert with check (public.is_teacher());

drop policy if exists "reviews: teacher update" on public.essay_reviews;
create policy "reviews: teacher update" on public.essay_reviews
  for update using (public.is_teacher()) with check (public.is_teacher());

-- ---------- Назначить преподавателя ----------
-- После того как Елена зарегистрируется на сайте, выполните (подставив её email):
-- update public.profiles set role = 'teacher' where email = 'elena@example.com';
