# FCE B2 Prep

Платформа подготовки к Cambridge B2 First. Стек: Next.js 15 (App Router) · React 19 · Framer Motion · CSS Modules и дизайн-токены · Supabase (аккаунты и база данных, необязательно).

## Запуск

Нужен Node.js 18.18 или новее (лучше 20+).

```bash
npm install
npm run dev
```

После этого откройте http://localhost:3000.

## Структура

```
src/
  app/
    (marketing)/       главная (шапка + подвал)
    (auth)/            вход и регистрация
    (app)/             кабинет, каталог, результаты (сайдбар)
    (focus)/practice/  задания в фокус-режиме
  styles/tokens.css    дизайн-токены (см. DESIGN_SYSTEM.md)
  lib/motion.ts        easing и пружины для framer-motion
  components/
    ui/                Button, SpotlightCard, Reveal, SectionHeading, Logo, CountUp, ProgressRing, EmptyState
    layout/            Navbar, Footer, BackgroundAura
    home/              Hero (+LondonScene), ExamPapers, Method, Teacher, FinalCta
    app/               Sidebar, каталог заданий, результаты
    auth/              формы входа и регистрации
    dashboard/         виджеты кабинета и график
    practice/          движок заданий, Listening-плеер, Writing, Speaking
  data/tasks/          тексты и ключи всех заданий
  lib/history.ts       история попыток
  lib/supabase.ts      клиент Supabase (если заданы ключи)
  lib/cloud.ts         запросы к серверу: попытки, профили, проверки эссе
  lib/auth.tsx         вход, сессия и профиль
supabase/schema.sql    схема базы данных и правила доступа
public/images/         фото преподавателя
```

## Страницы

| Адрес | Что это |
|---|---|
| `/` | Главная: первый экран с иллюстрацией вечернего Лондона, формат экзамена, демо-задание, преподаватель, отзывы, FAQ, CTA |
| `/register`, `/login` | Регистрация и вход |
| `/dashboard` | Личный кабинет: статистика, график, готовность по частям экзамена, следующее задание, последние результаты |
| `/practice` | Каталог всех заданий с фильтром и лучшими результатами |
| `/practice/<slug>` | Задание в фокус-режиме (список ниже) |
| `/mock` | Пробный экзамен: все части подряд, прогресс и ориентировочный уровень |
| `/results` | История всех попыток |
| `/settings` | Профиль, дата экзамена, целевой балл, очистка данных |
| `/teacher` | Кабинет преподавателя: успеваемость учеников и проверка эссе (с Supabase) |
| `/reset-password` | Смена пароля по ссылке из письма (с Supabase) |

### Задания (16)

| Часть | Задание | slug |
|---|---|---|
| Reading & Use of English | Part 1 Multiple-choice cloze | `uoe-part-1` |
| | Part 2 Open cloze | `uoe-part-2` |
| | Part 3 Word formation | `uoe-part-3` |
| | Part 4 Key word transformations | `uoe-part-4` |
| | Part 5 Multiple choice | `reading-part-5` |
| | Part 6 Gapped text | `reading-part-6` |
| | Part 7 Multiple matching | `reading-part-7` |
| Writing | Part 1 Essay | `writing-part-1` |
| | Part 2 Article / Email / Review (на выбор) | `writing-part-2` |
| Listening | Part 1 Short extracts | `listening-part-1` |
| | Part 2 Sentence completion | `listening-part-2` |
| | Part 3 Multiple matching | `listening-part-3` |
| | Part 4 Interview | `listening-part-4` |
| Speaking | Part 1 Interview | `speaking-part-1` |
| | Part 2 Long turn (сравнение картинок) | `speaking-part-2` |
| | Part 3–4 Collaborative task + Discussion | `speaking-part-3` |

Все тексты, записи и вопросы оригинальные, составлены в формате B2 First. Картинки для Speaking Part 2 нарисованы (SVG). Их можно заменить фотографиями в `src/components/practice/SpeakingScenes.tsx`.

Тексты заданий лежат в `src/data/tasks/`. Новое задание добавляется одним объектом в этих файлах, отдельная страница для него не нужна.

### Отзывы

Отзывы на главной берутся из `src/data/reviews.ts`. Пока список пустой, блок не показывается. Добавляйте только настоящие отзывы с разрешения авторов.

## Два режима работы

**Локальный режим (по умолчанию).** Если ключи Supabase не заданы, всё хранится в браузере: профиль, история попыток, черновики эссе. Удобно для демонстрации и разработки, но данные видны только на одном устройстве, а преподаватель их не видит.

**Режим с сервером (Supabase).** Настоящие аккаунты, история на сервере, кабинет преподавателя `/teacher` с таблицей успеваемости и проверкой эссе. Ученик видит оценку и комментарий в кабинете.

### Как подключить Supabase (≈ 10 минут, бесплатный тариф)

1. Зарегистрируйтесь на [supabase.com](https://supabase.com) и создайте проект (регион — Frankfurt, ближе всего к Молдове).
2. Откройте **SQL Editor**, вставьте содержимое файла `supabase/schema.sql` целиком и нажмите **Run**.
3. Откройте **Project Settings → API**. Скопируйте `.env.local.example` в `.env.local` и вставьте **Project URL** и **anon public key**.
4. **Authentication → URL Configuration**:
   - Site URL: `http://localhost:3000` (после публикации — адрес сайта);
   - Redirect URLs: `http://localhost:3000/**` и `https://ваш-домен/**`.
5. Перезапустите `npm run dev` и зарегистрируйтесь на сайте.
6. Чтобы Елена стала преподавателем, после её регистрации выполните в SQL Editor:
   ```sql
   update public.profiles set role = 'teacher' where email = 'её-email@example.com';
   ```
   В меню кабинета у неё появится раздел **«Ученики»**.

По умолчанию Supabase просит подтвердить email по ссылке из письма. Для тестов это можно отключить: **Authentication → Providers → Email → Confirm email**.

### Публикация

Удобнее всего через [Vercel](https://vercel.com): импортируйте папку проекта из GitHub и добавьте две переменные окружения из `.env.local`. После публикации обновите Site URL и Redirect URLs в Supabase (шаг 4).

### Безопасность данных

Доступ ограничен правилами Row Level Security (см. `supabase/schema.sql`): ученик видит только свои попытки и оценки, преподаватель видит всех. Роль преподавателя нельзя назначить себе с сайта, только через базу.

## Управление в заданиях

`A`–`D` или `1`–`4` выбирают ответ, `←` `→` переключают вопросы, `Enter` в поле ввода переходит к следующему пропуску.

## Дальше

- Больше вариантов каждого задания: тексты добавляются в `src/data/tasks/`.
- Настоящие отзывы учеников в `src/data/reviews.ts`.
- Публикация на домене и подключение Supabase по инструкции выше.
