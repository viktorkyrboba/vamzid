"use client";

import type { CSSProperties, ReactNode } from "react";
import { BookOpenText, Headphones, Layers, Mic, PenLine } from "lucide-react";
import { Box3D } from "./Box3D";
import { Stage3D } from "./Stage3D";
import { UnionJack } from "@/components/ui/UnionJack";
import m from "./Models.module.css";

const RED = "#c8102e";
const RED_DARK = "#9e0b23";
const BRASS = "#d9a84e";
const NAVY = "#162034";

/* ===================================================================
   Красная телефонная будка
   =================================================================== */

function BoothSide({ sign = true }: { sign?: boolean }) {
  return (
    <div className={m.boothSide}>
      {sign && <span className={m.boothSign}>TELEPHONE</span>}
      <div className={m.boothGlass}>
        {Array.from({ length: 18 }).map((_, i) => (
          <i key={i} />
        ))}
      </div>
    </div>
  );
}

export function PhoneBox({ scale = 1, className }: { scale?: number; className?: string }) {
  const side = { children: <BoothSide />, bg: RED };
  return (
    <Stage3D width={220 * scale} height={330 * scale} scale={scale} rx={-12} ry={-32} className={className} label="Красная телефонная будка">
      <Box3D w={104} h={10} d={104} y={112} color={RED_DARK} />
      <Box3D w={90} h={214} d={90} color={RED} faces={{ front: side, back: side, left: side, right: side }} />
      <Box3D w={100} h={14} d={100} y={-114} color={RED} />
      <Box3D w={84} h={10} d={84} y={-126} color={RED} />
      <Box3D w={54} h={8} d={54} y={-135} color={RED} />
      <Box3D w={14} h={10} d={14} y={-144} color={BRASS} />
    </Stage3D>
  );
}

/* ===================================================================
   Двухэтажный автобус
   =================================================================== */

function BusSide({ flip = false }: { flip?: boolean }) {
  return (
    <div className={m.busSide} style={flip ? { transform: "scaleX(-1)" } : undefined}>
      <div className={m.busRow}>
        {Array.from({ length: 6 }).map((_, i) => (
          <i key={i} />
        ))}
      </div>
      <div className={m.busStripe}>
        <span style={flip ? { transform: "scaleX(-1)" } : undefined}>FCE · B2 FIRST</span>
      </div>
      <div className={m.busRow}>
        <b className={m.busDoor} />
        {Array.from({ length: 5 }).map((_, i) => (
          <i key={i} />
        ))}
      </div>
      <span className={m.wheel} style={{ left: 26 }} />
      <span className={m.wheel} style={{ right: 30 }} />
    </div>
  );
}

function BusFront() {
  return (
    <div className={m.busFront}>
      <span className={m.busDest}>B2 FIRST</span>
      <i className={m.busWindshieldTop} />
      <i className={m.busWindshield} />
      <span className={m.busLights}>
        <b />
        <b />
      </span>
    </div>
  );
}

export function Bus({ scale = 1, className }: { scale?: number; className?: string }) {
  return (
    <Stage3D width={330 * scale} height={230 * scale} scale={scale} rx={-14} ry={-28} follow={12} className={className} label="Красный двухэтажный автобус">
      <Box3D
        w={250}
        h={128}
        d={82}
        color={RED}
        faces={{
          front: { bg: RED, children: <BusSide /> },
          back: { bg: RED, children: <BusSide flip /> },
          right: { bg: RED, children: <BusFront /> },
          top: { bg: "#b10d28" },
          bottom: { bg: "#1a1a1a" },
        }}
      />
    </Stage3D>
  );
}

/* ===================================================================
   Стопка экзаменационных бланков и карандаш
   =================================================================== */

function PaperTop() {
  return (
    <div className={m.paper}>
      <div className={m.paperHead}>
        <span>Cambridge English</span>
        <UnionJack width={22} />
      </div>
      <strong className={m.paperTitle}>B2 First</strong>
      <span className={m.paperSub}>Reading and Use of English · Paper 1</span>
      <span className={m.paperTime}>Time: 1 hour 15 minutes</span>
      <div className={m.paperLines}>
        {Array.from({ length: 9 }).map((_, i) => (
          <i key={i} style={{ width: `${62 + ((i * 29) % 34)}%` }} />
        ))}
      </div>
      <div className={m.paperBoxes}>
        {Array.from({ length: 6 }).map((_, i) => (
          <b key={i} />
        ))}
      </div>
    </div>
  );
}

const tipClip: CSSProperties = { clipPath: "polygon(0 0, 100% 50%, 0 100%)" };

export function PaperStack({ scale = 1, className }: { scale?: number; className?: string }) {
  const sheet = "#efe7d6";
  return (
    <Stage3D width={330 * scale} height={260 * scale} scale={scale} rx={-52} ry={-24} follow={10} className={className} label="Стопка экзаменационных бланков с карандашом">
      <Box3D w={180} h={4} d={240} y={18} rotate="rotateY(7deg)" color="#ddd3bf" />
      <Box3D w={180} h={4} d={240} y={13} rotate="rotateY(-4deg)" color="#e6dcc8" />
      <Box3D w={180} h={4} d={240} y={8} rotate="rotateY(3deg)" color="#e9e0cd" />
      <Box3D w={180} h={4} d={240} y={3} color={sheet} faces={{ top: { bg: sheet, children: <PaperTop /> } }} />
      {/* карандаш */}
      <Box3D w={170} h={11} d={11} x={40} y={-5} z={70} rotate="rotateY(-38deg)" color="#f2c230" faces={{ top: { bg: "#f7d04f" }, front: { bg: "#e8b622" } }} />
      <Box3D w={22} h={11} d={11} x={-35.6} y={-5} z={10.9} rotate="rotateY(-38deg)" color="#e7cfa3"
        faces={{ front: { bg: "#e7cfa3", style: { clipPath: "polygon(100% 0, 0 50%, 100% 100%)" } }, back: { bg: "#d8bd8c", style: tipClip }, top: { bg: "#f0dcb4", style: { clipPath: "polygon(100% 0, 0 50%, 100% 100%)" } }, bottom: { bg: "#c9ad7d", style: { clipPath: "polygon(100% 0, 0 50%, 100% 100%)" } } }}
        hide={["left"]} />
      <Box3D w={12} h={11.5} d={11.5} x={111.7} y={-5} z={126} rotate="rotateY(-38deg)" color="#b9bcc2" />
      <Box3D w={14} h={11} d={11} x={122} y={-5} z={134} rotate="rotateY(-38deg)" color="#e9898f" />
    </Stage3D>
  );
}

/* ===================================================================
   Куб навыков
   =================================================================== */

function CubeFace({ icon, title, sub }: { icon: ReactNode; title: string; sub: string }) {
  return (
    <div className={m.cubeFace}>
      <span className={m.cubeIcon}>{icon}</span>
      <strong>{title}</strong>
      <small>{sub}</small>
    </div>
  );
}

export function SkillCube({ size = 128, className }: { size?: number; className?: string }) {
  const s = size;
  const f = (node: ReactNode) => ({ bg: NAVY, children: node });
  return (
    <Stage3D width={s * 2} height={s * 2} rx={-22} ry={-34} follow={10} spin={26} className={className} label="Куб с навыками экзамена">
      <Box3D
        w={s}
        h={s}
        d={s}
        color={NAVY}
        faces={{
          front: f(<CubeFace icon={<BookOpenText size={22} />} title="Reading" sub="Parts 5–7" />),
          right: f(<CubeFace icon={<Layers size={22} />} title="Use of English" sub="Parts 1–4" />),
          back: f(<CubeFace icon={<PenLine size={22} />} title="Writing" sub="Parts 1–2" />),
          left: f(<CubeFace icon={<Headphones size={22} />} title="Listening" sub="Parts 1–4" />),
          top: f(<CubeFace icon={<Mic size={22} />} title="Speaking" sub="Parts 1–4" />),
          bottom: f(<div className={m.cubeFace}><UnionJack width={64} /></div>),
        }}
      />
    </Stage3D>
  );
}

/* ===================================================================
   Сертификат с печатью
   =================================================================== */

export function Certificate({ name = "Your name", scale = 1, className }: { name?: string; scale?: number; className?: string }) {
  return (
    <Stage3D width={320 * scale} height={240 * scale} scale={scale} rx={-10} ry={-24} follow={14} className={className} label="Сертификат B2 First">
      <Box3D
        w={250}
        h={176}
        d={5}
        color="#e6dcc6"
        faces={{
          front: {
            bg: "#f4ecdc",
            children: (
              <div className={m.cert}>
                <span className={m.certKicker}>Cambridge English Qualifications</span>
                <strong className={m.certTitle}>B2 First</strong>
                <span className={m.certLine}>This is to certify that</span>
                <span className={m.certName}>{name}</span>
                <span className={m.certLine}>is ready for the exam</span>
              </div>
            ),
          },
        }}
      />
      {/* печать и лента выступают над листом */}
      <Box3D w={22} h={46} d={2} x={72} y={64} z={5} rotate="rotateZ(12deg)" color={RED_DARK} />
      <Box3D w={22} h={46} d={2} x={92} y={62} z={5} rotate="rotateZ(-10deg)" color={RED} />
      <Box3D w={50} h={50} d={4} x={82} y={44} z={8} color={RED} radius="50%" hide={["left", "right", "top", "bottom"]}
        faces={{ front: { bg: RED, children: <span className={m.seal}>B2</span> } }} />
    </Stage3D>
  );
}
