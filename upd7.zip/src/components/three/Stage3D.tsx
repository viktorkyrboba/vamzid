"use client";

import { useEffect, useRef, useState, type ReactNode, type PointerEvent } from "react";
import styles from "./Three.module.css";

interface Props {
  children: ReactNode;
  /** размер области сцены */
  width: number;
  height: number;
  /** базовый наклон модели */
  rx?: number;
  ry?: number;
  /** насколько модель поворачивается за курсором (градусы) */
  follow?: number;
  /** покачивание вверх-вниз */
  float?: boolean;
  /** непрерывное вращение вокруг вертикальной оси (секунд на оборот) */
  spin?: number;
  /** масштаб всей модели */
  scale?: number;
  /** тень под моделью */
  shadow?: boolean;
  className?: string;
  label?: string;
}

/**
 * Сцена для CSS 3D-моделей: перспектива, мягкая тень, покачивание и поворот за курсором.
 * Курсор отслеживается только над самой сценой, вращение ставится на паузу, когда сцена не видна —
 * поэтому модели не нагружают прокрутку.
 */
export function Stage3D({
  children,
  width,
  height,
  rx = -18,
  ry = -30,
  follow = 16,
  float = true,
  spin,
  scale = 1,
  shadow = true,
  className,
  label,
}: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting), { rootMargin: "80px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el || e.pointerType !== "mouse") return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--px", (((e.clientX - r.left) / r.width - 0.5) * 2).toFixed(3));
    el.style.setProperty("--py", (((e.clientY - r.top) / r.height - 0.5) * 2).toFixed(3));
  };
  const onLeave = () => {
    ref.current?.style.setProperty("--px", "0");
    ref.current?.style.setProperty("--py", "0");
  };

  return (
    <div
      ref={ref}
      className={`${styles.stage} ${visible ? "" : styles.paused} ${className ?? ""}`}
      style={{ width, height, ["--rx" as string]: `${rx}deg`, ["--ry" as string]: `${ry}deg`, ["--follow" as string]: `${follow}deg` }}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      role={label ? "img" : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
    >
      {shadow && <div className={styles.shadow} />}
      <div className={`${styles.floater} ${float ? styles.floating : ""}`}>
        <div className={styles.rig}>
          <div
            className={`${styles.spinner} ${spin ? styles.spinning : ""}`}
            style={spin ? { animationDuration: `${spin}s` } : undefined}
          >
            <div className={styles.scaler} style={{ transform: `scale3d(${scale}, ${scale}, ${scale})` }}>
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
