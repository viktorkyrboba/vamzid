import type { CSSProperties, ReactNode } from "react";
import styles from "./Three.module.css";

export interface Face {
  bg?: string;
  children?: ReactNode;
  style?: CSSProperties;
  className?: string;
}

type FaceName = "front" | "back" | "left" | "right" | "top" | "bottom";

interface Props {
  /** ширина (X), высота (Y), глубина (Z) в px */
  w: number;
  h: number;
  d: number;
  /** центр коробки относительно центра сцены */
  x?: number;
  y?: number;
  z?: number;
  /** дополнительный поворот коробки, например "rotateY(12deg)" */
  rotate?: string;
  /** цвет всех граней по умолчанию */
  color?: string;
  faces?: Partial<Record<FaceName, Face>>;
  /** какие грани не рисовать */
  hide?: FaceName[];
  /** скругление лицевой и задней граней */
  radius?: number | string;
}

/**
 * Прямоугольный параллелепипед из шести граней на CSS 3D.
 * Грани получают лёгкое затенение по направлению, чтобы объём читался без освещения.
 */
export function Box3D({ w, h, d, x = 0, y = 0, z = 0, rotate = "", color = "#ccc", faces = {}, hide = [], radius }: Props) {
  const geo: Record<FaceName, { width: number; height: number; left: number; top: number; transform: string }> = {
    front: { width: w, height: h, left: 0, top: 0, transform: `translateZ(${d / 2}px)` },
    back: { width: w, height: h, left: 0, top: 0, transform: `rotateY(180deg) translateZ(${d / 2}px)` },
    right: { width: d, height: h, left: (w - d) / 2, top: 0, transform: `rotateY(90deg) translateZ(${w / 2}px)` },
    left: { width: d, height: h, left: (w - d) / 2, top: 0, transform: `rotateY(-90deg) translateZ(${w / 2}px)` },
    top: { width: w, height: d, left: 0, top: (h - d) / 2, transform: `rotateX(90deg) translateZ(${h / 2}px)` },
    bottom: { width: w, height: d, left: 0, top: (h - d) / 2, transform: `rotateX(-90deg) translateZ(${h / 2}px)` },
  };
  return (
    <div
      className={styles.box}
      style={{ width: w, height: h, marginLeft: -w / 2, marginTop: -h / 2, transform: `translate3d(${x}px, ${y}px, ${z}px) ${rotate}` }}
    >
      {(Object.keys(geo) as FaceName[])
        .filter((n) => !hide.includes(n))
        .map((n) => {
          const f = faces[n] ?? {};
          const g = geo[n];
          const round = radius != null && (n === "front" || n === "back") ? { borderRadius: radius } : null;
          return (
            <div
              key={n}
              className={`${styles.face} ${styles[n]} ${f.className ?? ""}`}
              style={{ ...g, background: f.bg ?? color, ...round, ...f.style }}
            >
              {f.children}
            </div>
          );
        })}
    </div>
  );
}
