"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";
import { useState } from "react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { PhoneBox } from "@/components/three/Models";
import { Reveal } from "@/components/ui/Reveal";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./Faq.module.css";

const FAQ = [
  {
    q: "Что такое B2 First (FCE)?",
    a: "Международный экзамен Cambridge English уровня B2 по шкале CEFR. Раньше он назывался First Certificate in English, отсюда сокращение FCE. Сертификат подтверждает, что вы можете учиться и работать на английском.",
  },
  {
    q: "Из чего состоит экзамен?",
    a: "Из четырёх частей: Reading & Use of English (1 ч 15 мин), Writing (1 ч 20 мин), Listening (около 40 минут) и Speaking (14 минут, в паре с другим кандидатом). На платформе есть тренажёры для каждой части и пробный экзамен целиком.",
  },
  {
    q: "Как оценивается результат?",
    a: "По шкале Cambridge English Scale: 160–172 — Grade C, 173–179 — Grade B, оба уровня B2. 180–190 — Grade A, это уже уровень C1. При результате 140–159 выдаётся сертификат уровня B1.",
  },
  {
    q: "Сертификат засчитывается вместо BAC?",
    a: "В 2015 году Министерство образования Молдовы признало B2 First и более высокие экзамены Cambridge основанием для освобождения от экзамена по английскому на бакалавриате. Действующий порядок лучше уточнить в своём лицее перед сдачей.",
  },
  {
    q: "Есть ли у сертификата срок действия?",
    a: "Сам сертификат бессрочный. Но некоторые университеты и работодатели просят результат не старше двух лет, поэтому проверяйте требования конкретного учреждения.",
  },
  {
    q: "Как устроена подготовка на платформе?",
    a: "Задания повторяют формат экзамена: проверка мгновенная, к каждой ошибке есть объяснение. Listening озвучивается прямо в браузере и прослушивается дважды, как на экзамене. В Speaking ответы записываются, чтобы вы могли услышать себя со стороны.",
  },
  {
    q: "Кто проверяет Writing?",
    a: "Сразу после сдачи доступна самопроверка по четырём критериям Cambridge: объём, структура, связки, стиль. Проверка эссе преподавателем с комментариями появится вместе с личными аккаунтами.",
  },
  {
    q: "Можно ли заниматься с телефона?",
    a: "Да, все страницы адаптированы под телефон. Для Speaking нужен доступ к микрофону, для Listening — звук.",
  },
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="section">
      <div className="container">
        <div className={styles.head}>
          <SectionHeading
            eyebrow="Вопросы и ответы"
            title={
              <>
                Всё, что важно <span className="gradient-text">знать заранее.</span>
              </>
            }
            align="center"
          />
          <PhoneBox scale={0.85} className={styles.model} />
        </div>
        <div className={styles.list}>
          {FAQ.map((item, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={item.q} delay={i * 0.04}>
                <div className={cn(styles.item, isOpen && styles.open)}>
                  <button className={styles.q} onClick={() => setOpen(isOpen ? null : i)} aria-expanded={isOpen}>
                    <span>{item.q}</span>
                    <motion.span className={styles.icon} animate={{ rotate: isOpen ? 45 : 0 }} transition={{ duration: 0.3, ease: ease.out }}>
                      <Plus size={18} />
                    </motion.span>
                  </button>
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.35, ease: ease.out }}
                        style={{ overflow: "hidden" }}
                      >
                        <p className={styles.a}>{item.a}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
