"use client";

import Link from "next/link";
import { Certificate } from "@/components/three/Models";
import { motion } from "framer-motion";
import { Activity, ArrowRight, Trash2 } from "lucide-react";
import { useState } from "react";
import { EmptyState } from "@/components/ui/EmptyState";
import { Button } from "@/components/ui/Button";
import { CountUp } from "@/components/ui/CountUp";
import { SKILLS, getTask, taskHref, type Skill } from "@/data/tasks";
import { clearHistory, formatDate, formatDuration, percent } from "@/lib/history";
import { useHistory, useUser } from "@/lib/useLocalData";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./AppPages.module.css";

export function ResultsView() {
  const history = useHistory();
  const user = useUser();
  const [skill, setSkill] = useState<Skill | "all">("all");
  const [confirm, setConfirm] = useState(false);

  if (history === null) {
    return (
      <div className={styles.page}>
        <div className="skeleton" style={{ width: 240, height: 36 }} />
        <div className={styles.tiles} style={{ marginTop: 32 }}>
          {[0, 1, 2].map((i) => (
            <div key={i} className="skeleton" style={{ height: 110, borderRadius: 20 }} />
          ))}
        </div>
      </div>
    );
  }

  const rows = history.filter((a) => skill === "all" || getTask(a.slug)?.skill === skill);
  const quiz = history.filter((a) => a.kind === "quiz" && a.total);
  const correct = quiz.reduce((s, a) => s + (a.correct ?? 0), 0);
  const total = quiz.reduce((s, a) => s + (a.total ?? 0), 0);
  const acc = total ? Math.round((correct / total) * 100) : 0;
  const minutes = Math.round(history.reduce((s, a) => s + a.seconds, 0) / 60);

  return (
    <div className={styles.page}>
      <header className={styles.head}>
        <div>
          <h1 className={styles.h1}>Результаты</h1>
          <p className={styles.sub}>Все ваши попытки. История хранится в этом браузере.</p>
        </div>
        <Certificate name={user.firstName ? `${user.firstName} ${user.lastName ?? ""}`.trim() : "Your name"} scale={0.7} className={styles.headModel} />
        {history.length > 0 && (
          <button
            className={cn(styles.clear, confirm && styles.clearConfirm)}
            onClick={() => {
              if (confirm) {
                clearHistory();
                setConfirm(false);
              } else {
                setConfirm(true);
                window.setTimeout(() => setConfirm(false), 3000);
              }
            }}
          >
            <Trash2 size={15} /> {confirm ? "Нажмите ещё раз, чтобы удалить" : "Очистить историю"}
          </button>
        )}
      </header>

      {history.length === 0 ? (
        <div className={styles.emptyPanel}>
          <EmptyState
            icon={<Activity size={22} />}
            title="Пока нет результатов"
            text="Пройдите любое задание — здесь появится история попыток, точность и время."
            action={
              <Button href="/practice" size="sm" iconRight={<ArrowRight size={15} />}>
                К заданиям
              </Button>
            }
          />
        </div>
      ) : (
        <>
          <div className={styles.tiles}>
            {[
              { label: "Попыток", value: history.length, suffix: "" },
              { label: "Точность в заданиях с проверкой", value: acc, suffix: "%" },
              { label: "Время практики", value: minutes, suffix: " мин" },
            ].map((t, i) => (
              <motion.div
                key={t.label}
                className={styles.tile}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, ease: ease.out, delay: i * 0.06 }}
              >
                <span className={styles.tileValue}>
                  <CountUp to={t.value} suffix={t.suffix} />
                </span>
                <span className={styles.tileLabel}>{t.label}</span>
              </motion.div>
            ))}
          </div>

          <div className={styles.filters} style={{ marginTop: 32 }}>
            {[{ key: "all" as const, title: "Все" }, ...SKILLS].map((s) => (
              <button
                key={s.key}
                className={cn(styles.filter, skill === s.key && styles.filterOn)}
                onClick={() => setSkill(s.key)}
              >
                {skill === s.key && (
                  <motion.span layoutId="res-filter" className={styles.filterPill} transition={{ type: "spring", stiffness: 420, damping: 34 }} />
                )}
                <span>{s.key === "rue" ? "Reading & UoE" : s.title}</span>
              </button>
            ))}
          </div>

          <div className={styles.tablePanel}>
            {rows.length === 0 ? (
              <p className={styles.noRows}>В этой части экзамена попыток пока нет.</p>
            ) : (
              <table className={styles.table}>
                <thead>
                  <tr>
                    <th>Задание</th>
                    <th>Дата</th>
                    <th>Результат</th>
                    <th>Время</th>
                    <th aria-label="Действия" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((a, i) => {
                    const pct = percent(a);
                    return (
                      <motion.tr
                        key={`${a.date}-${i}`}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.4, delay: Math.min(i, 10) * 0.03 }}
                      >
                        <td>
                          <span className={styles.tdMain}>{a.title}</span>
                          <span className={styles.tdSub}>
                            {a.paper.replace("Reading & ", "")} · {a.part}
                          </span>
                        </td>
                        <td className={styles.tdMuted}>{formatDate(a.date)}</td>
                        <td>
                          {pct != null ? (
                            <span className={styles.scoreCell}>
                              <strong>
                                {a.correct}/{a.total}
                              </strong>
                              <span className={styles.miniTrack}>
                                <span
                                  className={cn(styles.miniFill, pct >= 80 ? styles.fillGood : pct < 55 && styles.fillLow)}
                                  style={{ width: `${pct}%` }}
                                />
                              </span>
                              <span className={styles.tdMuted}>{pct}%</span>
                            </span>
                          ) : a.kind === "writing" ? (
                            <span className={styles.tdMuted}>{a.words} слов · сдано</span>
                          ) : (
                            <span className={styles.tdMuted}>{a.answered} ответов записано</span>
                          )}
                        </td>
                        <td className={styles.tdMuted}>{formatDuration(a.seconds)}</td>
                        <td>
                          <Link href={taskHref(a.slug)} className={styles.again}>
                            Ещё раз
                          </Link>
                        </td>
                      </motion.tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}
    </div>
  );
}
