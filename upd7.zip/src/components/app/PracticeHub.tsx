"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, BookOpenText, Clock, Headphones, Mic, PenLine, Hash } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useState } from "react";
import { PARTS, SKILLS, TASKS, UPCOMING, taskHref, testNo, variantsOf, type Skill, type Task } from "@/data/tasks";
import { bestBySlug, percent } from "@/lib/history";
import { useHistory } from "@/lib/useLocalData";
import { SpotlightCard } from "@/components/ui/SpotlightCard";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { cn } from "@/lib/cn";
import { SkillCube } from "@/components/three/Models";
import { ease } from "@/lib/motion";
import styles from "./AppPages.module.css";

const ICONS: Record<Skill, LucideIcon> = {
  rue: BookOpenText,
  writing: PenLine,
  listening: Headphones,
  speaking: Mic,
};

const GLOW: Record<Skill, "violet" | "blue" | "cyan"> = {
  rue: "violet",
  writing: "blue",
  listening: "cyan",
  speaking: "violet",
};

const FILTERS: Array<{ key: Skill | "all"; label: string }> = [
  { key: "all", label: "Все" },
  { key: "rue", label: "Reading & UoE" },
  { key: "writing", label: "Writing" },
  { key: "listening", label: "Listening" },
  { key: "speaking", label: "Speaking" },
];

function size(t: Task) {
  if (t.kind === "quiz") return `${t.items.length} вопросов`;
  if (t.kind === "speaking") return `${t.stages.length} этапов`;
  return `${t.minWords}–${t.maxWords} слов`;
}

export function PracticeHub() {
  const [filter, setFilter] = useState<Skill | "all">("all");
  const history = useHistory();
  const best = bestBySlug(history ?? []);
  const done = TASKS.filter((t) => best.has(t.slug)).length;

  return (
    <div className={styles.page}>
      <header className={styles.head}>
        <div>
          <h1 className={styles.h1}>Задания</h1>
          <p className={styles.sub}>
            Каждая часть экзамена — 5 разных тестов. Пройдено {history ? done : "…"} из {TASKS.length}.
          </p>
        </div>
        <SkillCube size={88} className={styles.headModel} />
        <div className={styles.filters} role="tablist" aria-label="Фильтр по частям экзамена">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              role="tab"
              aria-selected={filter === f.key}
              className={cn(styles.filter, filter === f.key && styles.filterOn)}
              onClick={() => setFilter(f.key)}
            >
              {filter === f.key && (
                <motion.span layoutId="hub-filter" className={styles.filterPill} transition={{ type: "spring", stiffness: 420, damping: 34 }} />
              )}
              <span>{f.label}</span>
            </button>
          ))}
        </div>
      </header>

      {SKILLS.filter((s) => filter === "all" || filter === s.key).map((skill, si) => {
        const Icon = ICONS[skill.key];
        const tasks = PARTS.filter((t) => t.skill === skill.key);
        return (
          <motion.section
            key={skill.key}
            id={skill.key}
            className={styles.skill}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: ease.out, delay: si * 0.06 }}
          >
            <div className={styles.skillHead}>
              <span className={cn(styles.skillIcon, styles[GLOW[skill.key]])}>
                <Icon size={20} strokeWidth={1.8} />
              </span>
              <div>
                <h2 className={styles.h2}>{skill.title}</h2>
                <p className={styles.skillMeta}>{skill.text}</p>
              </div>
            </div>

            <div className={styles.cards}>
              {tasks.map((t) => {
                const vars = variantsOf(t.slug);
                const doneCount = vars.filter((v) => best.has(v.slug)).length;
                // карточка ведёт к первому непройденному тесту
                const target = vars.find((v) => !best.has(v.slug)) ?? vars[0];
                return (
                  <div key={t.slug} className={styles.cardLink}>
                    <SpotlightCard glow={GLOW[skill.key]} className={styles.taskCard}>
                      <Link href={taskHref(target.slug)} className={styles.cardMain}>
                        <div className={styles.taskTop}>
                          <span className={styles.part}>{t.part}</span>
                          <ArrowUpRight size={18} className={styles.arrow} />
                        </div>
                        <h3 className={styles.taskTitle}>{t.type}</h3>
                        <p className={styles.taskSummary}>{t.summary}</p>
                      </Link>
                      <div className={styles.tests} aria-label="Тесты">
                        {vars.map((v) => {
                          const b = best.get(v.slug);
                          const pct = b ? percent(b) : null;
                          const tone = !b ? "" : pct == null ? styles.testDone : pct >= 75 ? styles.testGood : pct >= 50 ? styles.testMid : styles.testLow;
                          return (
                            <Link
                              key={v.slug}
                              href={taskHref(v.slug)}
                              className={cn(styles.test, tone, v.slug === target.slug && !b && styles.testNext)}
                              title={`Тест ${testNo(v)}: ${v.title}${pct != null ? ` — ${pct}%` : b ? " — выполнено" : ""}`}
                            >
                              {testNo(v)}
                            </Link>
                          );
                        })}
                      </div>
                      <div className={styles.taskFoot}>
                        <span>
                          <Clock size={13} /> {t.minutes} мин
                        </span>
                        <span>
                          <Hash size={13} /> {size(t)}
                        </span>
                        <span className={styles.status}>
                          {doneCount > 0 ? (
                            <>
                              <ProgressRing value={Math.round((doneCount / vars.length) * 100)} size={26} stroke={3} />
                              {doneCount}/{vars.length}
                            </>
                          ) : (
                            <span className={styles.newTag}>{vars.length} тестов</span>
                          )}
                        </span>
                      </div>
                    </SpotlightCard>
                  </div>
                );
              })}
              {UPCOMING[skill.key].map((u) => (
                <div key={u} className={styles.upcoming}>
                  <span className={styles.part}>{u.split(" · ")[0]}</span>
                  <span className={styles.type}>{u.split(" · ")[1]}</span>
                  <span className={styles.soon}>Скоро</span>
                </div>
              ))}
            </div>
          </motion.section>
        );
      })}
    </div>
  );
}
