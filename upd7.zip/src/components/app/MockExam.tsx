"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, BookOpenText, Check, Clock, Headphones, Mic, PenLine, Play, RotateCcw, Timer } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { getTask, taskHref, type Skill } from "@/data/tasks";
import { PaperStack } from "@/components/three/Models";
import { MOCK_EVENT, MOCK_PAPERS, loadMock, paperSlugs, resetMock, startMock, summarize, type MockSession } from "@/lib/mock";
import { formatDate, percent } from "@/lib/history";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { CountUp } from "@/components/ui/CountUp";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import styles from "./MockExam.module.css";

const ICONS: Record<Skill, LucideIcon> = { rue: BookOpenText, writing: PenLine, listening: Headphones, speaking: Mic };

const mockHref = (slug: string) => `${taskHref(slug)}?mock=1`;

export function MockExam() {
  const [session, setSession] = useState<MockSession | null | undefined>(undefined);
  const [confirm, setConfirm] = useState(false);

  useEffect(() => {
    const read = () => setSession(loadMock());
    read();
    window.addEventListener(MOCK_EVENT, read);
    window.addEventListener("storage", read);
    return () => {
      window.removeEventListener(MOCK_EVENT, read);
      window.removeEventListener("storage", read);
    };
  }, []);

  if (session === undefined) {
    return (
      <div className={styles.page}>
        <div className="skeleton" style={{ width: 280, height: 36 }} />
        <div className="skeleton" style={{ height: 320, marginTop: 32, borderRadius: 24 }} />
      </div>
    );
  }

  const variant = session?.test ?? 1;
  const allSlugs = MOCK_PAPERS.flatMap((p) => paperSlugs(p, variant));
  const totalMinutes = MOCK_PAPERS.reduce((n, p) => n + p.minutes, 0);

  /* ---------- вступление ---------- */
  if (!session) {
    return (
      <div className={styles.page}>
        <header className={styles.head}>
          <div>
            <h1 className={styles.h1}>Пробный экзамен</h1>
            <p className={styles.sub}>Все четыре части B2 First в одном прогоне — как на настоящем экзамене.</p>
          </div>
        </header>

        <motion.section
          className={styles.intro}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: ease.out }}
        >
          <div className={styles.introGlow} aria-hidden="true" />
          <div className={styles.introTop}>
            <div>
              <span className={styles.kicker}>Формат экзамена</span>
              <h2 className={styles.introTitle}>
                {allSlugs.length} заданий · ≈ {Math.round(totalMinutes / 60 * 10) / 10} ч
              </h2>
              <p className={styles.introText}>
                Проходите части в любом порядке и с перерывами — прогресс сохраняется. Reading & Use of English и
                Listening проверяются автоматически, по ним считается ориентировочный уровень. Writing и Speaking
                оценивает преподаватель.
              </p>
            </div>
            <PaperStack scale={0.72} className={styles.introModel} />
            <div className={styles.variantPick}>
              <span className={styles.kicker}>Выберите вариант</span>
              <div className={styles.variantRow}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} className={styles.start} onClick={() => startMock(n)}>
                    {n === 1 && <Play size={16} fill="currentColor" />} Вариант {n}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className={styles.papers}>
            {MOCK_PAPERS.map((p) => {
              const Icon = ICONS[p.key];
              return (
                <div key={p.key} className={styles.paperMini}>
                  <span className={styles.paperIcon}>
                    <Icon size={20} strokeWidth={1.8} />
                  </span>
                  <strong>{p.title}</strong>
                  <span>
                    {p.minutes} мин · {p.slugs.length} {p.slugs.length > 4 ? "частей" : "части"} · {p.weight}%
                  </span>
                </div>
              );
            })}
          </div>
        </motion.section>
      </div>
    );
  }

  /* ---------- идёт экзамен ---------- */
  const sum = summarize(session);
  const doneCount = allSlugs.filter((s) => session.done[s]).length;
  const next = allSlugs.find((s) => !session.done[s]);
  const nextTask = next ? getTask(next) : null;

  return (
    <div className={styles.page}>
      <header className={styles.head}>
        <div>
          <h1 className={styles.h1}>Пробный экзамен</h1>
          <p className={styles.sub}>
            Вариант {variant} · начат {formatDate(session.startedAt)} · выполнено {doneCount} из {allSlugs.length}
          </p>
        </div>
        <button
          className={cn(styles.reset, confirm && styles.resetConfirm)}
          onClick={() => {
            if (confirm) {
              resetMock();
              setConfirm(false);
            } else {
              setConfirm(true);
              window.setTimeout(() => setConfirm(false), 3000);
            }
          }}
        >
          <RotateCcw size={15} /> {confirm ? "Нажмите ещё раз, чтобы начать заново" : "Начать заново"}
        </button>
      </header>

      {/* ---------- итог ---------- */}
      {sum.complete && sum.overall != null && sum.level && (
        <motion.section
          className={styles.result}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: ease.out }}
        >
          <ProgressRing
            value={sum.overall}
            size={150}
            stroke={11}
            colors={sum.level.tone === "warn" ? ["#F59E0B", "#d9a84e"] : ["#d9a84e", "#d9a84e"]}
          >
            <span className={styles.bigPct}>
              <CountUp to={sum.overall} suffix="%" />
              <small>верных</small>
            </span>
          </ProgressRing>
          <div>
            <span className={styles.kicker}>Ориентировочный результат</span>
            <h2 className={styles.level}>
              <span className={cn(styles.levelBadge, styles[sum.level.tone])}>{sum.level.label}</span>
              {sum.level.note}
            </h2>
            <p className={styles.resultNote}>
              Рассчитано по Reading & Use of English (40%) и Listening (20%). Официальный балл Cambridge
              считается по своей шкале, это только ориентир. Writing и Speaking оценивает преподаватель.
            </p>
          </div>
        </motion.section>
      )}

      {nextTask && (
        <Link href={mockHref(nextTask.slug)} className={styles.next}>
          <span className={styles.nextIcon}>
            <Play size={16} fill="currentColor" />
          </span>
          <span className={styles.nextText}>
            <small>Следующее задание</small>
            {nextTask.paper.replace("Reading & ", "")} · {nextTask.part} — {nextTask.title}
          </span>
          <ArrowRight size={18} />
        </Link>
      )}

      <div className={styles.paperList}>
        {sum.papers.map((pr, i) => {
          const Icon = ICONS[pr.paper.key];
          return (
            <motion.section
              key={pr.paper.key}
              className={styles.paper}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: ease.out, delay: i * 0.06 }}
            >
              <div className={styles.paperHead}>
                <span className={styles.paperIcon}>
                  <Icon size={20} strokeWidth={1.8} />
                </span>
                <div className={styles.paperTitle}>
                  <h3>{pr.paper.title}</h3>
                  <span>
                    <Clock size={13} /> {pr.paper.minutes} мин · {pr.done} из {pr.total}
                  </span>
                </div>
                <span className={styles.paperScore}>
                  {pr.percent != null
                    ? `${pr.percent}%`
                    : pr.selfCheck != null
                      ? `самопроверка ${pr.selfCheck}%`
                      : pr.paper.scored
                        ? "—"
                        : "оценивает преподаватель"}
                </span>
              </div>
              <div className={styles.track}>
                <motion.span
                  className={styles.fill}
                  initial={{ width: 0 }}
                  animate={{ width: `${(pr.done / pr.total) * 100}%` }}
                  transition={{ duration: 0.9, ease: ease.out }}
                />
              </div>
              <ul className={styles.rows}>
                {paperSlugs(pr.paper, variant).map((slug) => {
                  const t = getTask(slug);
                  if (!t) return null;
                  const a = session.done[slug];
                  const pct = a ? percent(a) : null;
                  return (
                    <li key={slug} className={cn(styles.row, a && styles.rowDone)}>
                      <span className={styles.rowCheck}>{a ? <Check size={13} strokeWidth={3} /> : null}</span>
                      <span className={styles.rowPart}>{t.part}</span>
                      <span className={styles.rowType}>{t.type}</span>
                      <span className={styles.rowResult}>
                        {a
                          ? pct != null
                            ? `${a.correct}/${a.total}`
                            : a.kind === "writing"
                              ? `${a.words} сл.`
                              : "записано"
                          : null}
                      </span>
                      <Link href={mockHref(slug)} className={styles.rowGo}>
                        {a ? "Заново" : "Начать"}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </motion.section>
          );
        })}
      </div>

      <p className={styles.footnote}>
        <Timer size={14} /> Время по частям — рекомендуемое, как на экзамене. Задания можно проходить с перерывами.
      </p>
    </div>
  );
}
