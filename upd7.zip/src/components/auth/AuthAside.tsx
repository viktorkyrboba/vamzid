import Image from "next/image";
import { PhoneBox } from "@/components/three/Models";
import styles from "./Auth.module.css";

/** Правая панель страниц входа: фирменная карточка B2 и цитата преподавателя. */
export function AuthAside() {
  return (
    <aside className={styles.aside} aria-hidden="true">
      <div className={styles.asideGlow} />
      <div className={styles.asideModel}>
        <PhoneBox scale={0.8} />
      </div>

      <div className={styles.card}>
        <div className={styles.cardTop}>
          <span>FCE · B2 FIRST PREP</span>
          <span className={styles.cardChip}>EXAM READY</span>
        </div>
        <span className={styles.cardB2}>B2</span>
        <span className={styles.cardLevel}>Upper-Intermediate</span>
        <div className={styles.cardBar}>
          <span />
        </div>
        <div className={styles.cardSkills}>
          {["Reading", "Writing", "Listening", "Speaking"].map((s) => (
            <span key={s}>{s}</span>
          ))}
        </div>
      </div>

      <figure className={styles.quote}>
        <blockquote>«Цель моей работы — показать, что образование может быть нескучным.»</blockquote>
        <figcaption>
          <Image src="/images/elena-avatar.jpg" alt="" width={40} height={40} className={styles.quoteAvatar} />
          <span>
            <strong>Елена Каранфил</strong>
            <small>Автор методики</small>
          </span>
        </figcaption>
      </figure>
    </aside>
  );
}
