# FCE B2 Prep — передача проекта

Документ для продолжения работы над сайтом в другом инструменте (ChatGPT / Codex / любой разработчик).
Состояние на 26.11.2026.

## Что это

**FCE B2 Prep** — платформа подготовки к экзамену Cambridge B2 First (FCE) на русском языке,
построенная вокруг методики преподавателя **Елены Каранфил** (лицей «Orizont», Чадыр-Лунга).

- Живой сайт: https://fcetraining.vercel.app
- Код: GitHub `kyrboba/fcetraining` (приватный, ветка `main`)
- Хостинг: Vercel, команда `dualisdigital`, проект `fcetraining` — каждый коммит в `main` выкладывается автоматически
- База и вход: Supabase, проект «FCE SITE» (ref `mjnrgzsxyspklwadmqrv`, регион eu-west-1)

## Стек

- Next.js 15 (App Router), React 19, TypeScript
- framer-motion 12 (анимации), lucide-react (иконки), CSS Modules + дизайн-токены в `src/styles/tokens.css`
- Шрифты через `next/font/google`: Playfair Display (заголовки, есть кириллица) + IBM Plex Sans (текст)
- @supabase/supabase-js — облачный режим (аккаунты, попытки, проверка эссе). Без ключей сайт работает в локальном режиме (localStorage)
- 3D-элементы — чистый CSS 3D (без three.js): `src/components/three/*` и `src/components/home/hero/Book3D.tsx`

## Запуск локально

```bash
npm install
cp .env.local.example .env.local   # вписать ключи Supabase (ниже)
npm run dev                         # http://localhost:3000
```

Переменные окружения (они же заданы в Vercel → Settings → Environment Variables):

```
NEXT_PUBLIC_SUPABASE_URL=https://mjnrgzsxyspklwadmqrv.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=<публичный anon-ключ: Supabase → Project Settings → API Keys → Legacy → anon public>
```

Ключ `service_role` никогда не кладите в код или в `NEXT_PUBLIC_*`.

## Структура

```
src/app/
  (marketing)/        главная: Hero, ExamPapers, Method, Teacher, Reviews, Faq, FinalCta
  (auth)/             login, register, reset-password
  (app)/              кабинет (за входом): dashboard, practice (каталог), results, mock, settings, teacher
  (focus)/practice/[slug]/  экран прохождения задания (generateStaticParams по всем заданиям)
  template.tsx        переход между страницами (шторка)
src/components/
  home/               секции главной; hero/LondonScene.tsx — SVG-иллюстрация Лондона, hero/Book3D.tsx — 3D-книга
  three/              CSS 3D: Box3D, Stage3D, Models (телефонная будка, автобус, бланки, куб навыков, сертификат)
  practice/           TaskRunner (тесты), WritingRunner, SpeakingRunner (+ SpeakingScenes*.tsx — SVG-картинки к Part 2), ListeningPlayer (озвучка через Web Speech API, строки «M:»/«F:» — мужской/женский голос)
  app/, dashboard/, auth/, teacher/, layout/, ui/
src/data/tasks/
  types.ts            модель задания (quiz / writing / speaking)
  rue.ts, reading.ts, listening.ts, other.ts   тест 1 каждой части
  variants/*.ts       тесты 2–5 каждой части (slug с суффиксом -t2…-t5)
  index.ts            TASKS (80 заданий), PARTS, variantsOf, nextVariant, testLabel
src/lib/
  history.ts          попытки (localStorage + облако), mock.ts — пробный экзамен (варианты 1–5)
  supabase.ts, cloud.ts, auth.tsx, useLocalData.ts
supabase/schema.sql   таблицы profiles, attempts, essay_reviews + RLS (уже применена в проекте)
```

## Задания

16 частей экзамена × 5 тестов = **80 заданий**:
Use of English Part 1–4, Reading Part 5–7, Writing Part 1–2, Listening Part 1–4, Speaking Part 1–3.
Тест 1 — slug без суффикса (`uoe-part-1`), тесты 2–5 — `uoe-part-1-t2` … `-t5`.
Тексты тестов 2–5 оригинальные, сгенерированы и выборочно проверены; Елене стоит их вычитать.

## Дизайн

Направление «Лондонский вечер»: тёмно-синий фон `#0f1724`, латунный акцент `#d9a84e`, тёплый светлый текст `#ede6d8`,
британские детали (флаг в логотипе, крест флага на первом экране, полоса цветов флага, 3D-будка и автобус).
Фиолетовый и градиенты убраны сознательно — заказчик считает, что они делают сайт похожим на «сайт от ИИ».
Сайт должен выглядеть как вручную свёрстанный. Не возвращать неон, свечения и градиентные надписи.

## Роли

- Ученик — любой зарегистрированный пользователь.
- Преподаватель — выдаётся вручную SQL-запросом в Supabase (SQL Editor):
  ```sql
  update public.profiles set role = 'teacher' where email = 'email@example.com';
  ```
  После повторного входа в меню появляется «Ученики» (`/teacher`): успеваемость и проверка эссе.

## Что не доделано / известные моменты

1. **Supabase → Authentication → URL Configuration**: Site URL пока `http://localhost:3000`.
   Нужно поставить `https://fcetraining.vercel.app` и добавить Redirect URL `https://fcetraining.vercel.app/**`
   (иначе ссылки из писем подтверждения/сброса пароля ведут на localhost).
2. **Подтверждение email** в Supabase включено; встроенная почта Supabase отправляет лишь несколько писем в час.
3. Во временном публичном репозитории `viktorkyrboba/vamzid` осталась служебная ветка `fce-transfer` — её можно удалить.
4. Полная сборка `next build` и регистрация на живом сайте детально не тестировались — проверить вход/регистрацию.

## Правки от Елены (следующие задачи)

1. **Вход для преподавателя.** Она не находит, как войти как преподаватель — сайт просит войти как ученика.
   Нужна заметная кнопка/страница «Вход для преподавателя» и выдача ей роли teacher (её email — уточнить).
2. **Тесты по навыкам, а не по частям.** На каждый навык 5 тестов; «Тест 1» содержит все части навыка подряд
   (например, Listening: Part 1, 2, 3, 4), «Тест 2» — снова все части, и т.д.
   Данные уже есть (5 вариантов каждой части) — нужно собрать их в цельные тесты: тест N навыка = все части с номером варианта N.
3. **Reading и Use of English — вместе.** Один общий блок «Reading & Use of English», в каждом тесте все 7 частей подряд, как на экзамене.
4. **Тренировочные упражнения перед тестами.** Короткие разминки по каждой части до полного теста.
5. **Текст о Елене и её методике** — она пришлёт свои правки.
