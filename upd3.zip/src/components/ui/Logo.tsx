import Link from "next/link";
import styles from "./Logo.module.css";

/** Знак: скруглённый квадрат с «B2» и орбитой — фирменный мотив платформы. */
export function Logo() {
  return (
    <Link href="/" className={styles.logo} aria-label="FCE B2 Prep — на главную">
      <svg className={styles.mark} viewBox="0 0 36 36" fill="none" aria-hidden="true">
        <defs>
          <linearGradient id="logoGrad" x1="0" y1="0" x2="36" y2="36" gradientUnits="userSpaceOnUse">
            <stop stopColor="#6d4fe8" />
            <stop offset="1" stopColor="#6d4fe8" />
          </linearGradient>
        </defs>
        <rect x="1" y="1" width="34" height="34" rx="10" fill="url(#logoGrad)" />
        <rect x="1.5" y="1.5" width="33" height="33" rx="9.5" stroke="white" strokeOpacity="0.25" />
        <ellipse cx="18" cy="18" rx="15" ry="6" transform="rotate(-24 18 18)" stroke="white" strokeOpacity="0.35" strokeWidth="1" />
        <text
          x="18"
          y="23"
          textAnchor="middle"
          fill="white"
          fontSize="14"
          fontWeight="800"
          fontFamily="var(--font-display)"
          letterSpacing="-0.5"
        >
          B2
        </text>
      </svg>
      <span className={styles.word}>
        FCE <span className={styles.muted}>B2 Prep</span>
      </span>
    </Link>
  );
}
