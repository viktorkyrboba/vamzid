"use client";

import Link from "next/link";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ArrowRight, BookOpenText, Headphones, Layers, Mic, PenLine, Play } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { TASKS, type Skill } from "@/data/tasks";
import { bestBySlug } from "@/lib/history";
import { useHistory } from "@/lib/useLocalData";
import { ease } from "@/lib/motion";
import { LondonScene } from "./LondonScene";
import { Book3D } from "./Book3D";
import styles from "./Hero.module.css";

interface SkillLink {
  label: string;
  icon: LucideIcon;
  href: string;
  /** какие задания считаются для полоски прогресса */
  match: (slug: string, skill: Skill) => boolean;
}

const SKILL_LINKS: SkillLink[] = [
  { label: "Listening", icon: Headphones, href: "/practice/listening-part-2", match: (_, s) => s === "listening" },
  { label: "Reading", icon: BookOpenText, href: "/practice/reading-part-5", match: (slug) => slug.startsWith("reading") },
  { label: "Use of English", icon: Layers, href: "/practice/uoe-part-1", match: (slug) => slug.startsWith("uoe") },
  { label: "Writing", icon: PenLine, href: "/practice/writing-part-1", match: (_, s) => s === "writing" },
  { label: "Speaking", icon: Mic, href: "/practice/speaking-part-1", match: (_, s) => s === "speaking" },
];

/** Лавровая ветвь для бейджа. */
function Laurel({ flip = false }: { flip?: boolean }) {
  return (
    <svg
      className={styles.laurel}
      viewBox="0 0 16 28"
      fill="none"
      aria-hidden="true"
      style={flip ? { transform: "scaleX(-1)" } : undefined}
    >
      <path d="M12 27 C 4 22 2 13 6 2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      {[
        [5.2, 5, -40],
        [4.3, 10, -30],
        [4.6, 15, -20],
        [6, 20, -8],
        [8.6, 24, 10],
      ].map(([x, y, r], i) => (
        <g key={i}>
          <ellipse cx={x - 2.2} cy={y} rx="2.6" ry="1.1" transform={`rotate(${r - 25} ${x - 2.2} ${y})`} fill="currentColor" />
          <ellipse cx={x + 2.2} cy={y - 1.2} rx="2.6" ry="1.1" transform={`rotate(${r + 40} ${x + 2.2} ${y - 1.2})`} fill="currentColor" opacity="0.8" />
        </g>
      ))}
    </svg>
  );
}

export function Hero() {
  const reduce = useReducedMotion();
  const history = useHistory();
  const heroRef = useRef<HTMLElement>(null);
  // параллакс при прокрутке: сцена уходит медленнее и чуть приближается, текст растворяется
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const sceneY = useTransform(scrollYProgress, [0, 1], ["0%", "22%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], [0, -90]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);
  const bookY = useTransform(scrollYProgress, [0, 1], [0, -160]);
  const best = bestBySlug(history ?? []);

  const progress = (s: SkillLink) => {
    const tasks = TASKS.filter((t) => s.match(t.slug, t.skill));
    if (!tasks.length) return 0;
    return tasks.filter((t) => best.has(t.slug)).length / tasks.length;
  };

  const fade = (delay: number) => ({
    initial: reduce ? false : { opacity: 0, y: 18 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.9, ease: ease.out, delay },
  });

  return (
    <section ref={heroRef} className={styles.hero}>
      <motion.div className={styles.sceneWrap} style={reduce ? undefined : { y: sceneY }}>
        <motion.div
          className={styles.sceneInner}
          initial={reduce ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.4, ease: ease.out }}
        >
          <LondonScene />
        </motion.div>
        <div className={styles.overlay} />
      </motion.div>

      <motion.div
        className={styles.bookWrap}
        style={reduce ? undefined : { y: bookY }}
        initial={reduce ? false : { opacity: 0, x: 80, rotate: 8 }}
        animate={{ opacity: 1, x: 0, rotate: 0 }}
        transition={{ duration: 1.6, ease: ease.out, delay: 0.5 }}
      >
        <Book3D />
      </motion.div>

      <motion.div
        className={`container ${styles.content}`}
        style={reduce ? undefined : { y: contentY, opacity: contentOpacity }}
      >
        <motion.span className={styles.badge} {...fade(0.2)}>
          <Laurel />
          Cambridge FCE B2
          <Laurel flip />
        </motion.span>

        <h1 className={styles.title}>
          <span className={styles.lineMask}>
            <motion.span
              className={styles.line}
              initial={reduce ? false : { y: "110%" }}
              animate={{ y: "0%" }}
              transition={{ duration: 1.1, ease: ease.out, delay: 0.3 }}
            >
              Подготовка к
            </motion.span>
          </span>
          <span className={styles.lineMask}>
            <motion.span
              className={`${styles.line} ${styles.accent}`}
              initial={reduce ? false : { y: "110%" }}
              animate={{ y: "0%" }}
              transition={{ duration: 1.1, ease: ease.out, delay: 0.42 }}
            >
              FCE B2
            </motion.span>
          </span>
        </h1>

        <motion.p className={styles.lead} {...fade(0.65)}>
          Полный интерактивный курс для уверенной сдачи Cambridge First Certificate (B2)
        </motion.p>

        <motion.div className={styles.ctas} {...fade(0.8)}>
          <Button href="/register" size="lg" magnetic iconRight={<ArrowRight size={18} strokeWidth={2.2} />}>
            Начать подготовку
          </Button>
          <a href="#method" className={styles.how}>
            <span className={styles.playCircle}>
              <Play size={16} fill="currentColor" />
            </span>
            Как это работает?
          </a>
        </motion.div>

        <motion.nav className={styles.skills} aria-label="Части экзамена" {...fade(1)}>
          {SKILL_LINKS.map((s) => {
            const Icon = s.icon;
            const p = progress(s);
            return (
              <Link key={s.label} href={s.href} className={styles.skill}>
                <Icon size={30} strokeWidth={1.5} className={styles.skillIcon} />
                <span className={styles.skillLabel}>{s.label}</span>
                <span className={styles.skillTrack} aria-hidden="true">
                  <span className={styles.skillFill} style={{ width: `${Math.max(p * 100, 0)}%` }} />
                </span>
              </Link>
            );
          })}
        </motion.nav>
      </motion.div>
    </section>
  );
}
