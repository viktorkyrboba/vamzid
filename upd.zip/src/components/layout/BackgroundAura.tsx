import styles from "./BackgroundAura.module.css";

/**
 * Атмосферный фон в цветах вечернего неба. Полностью статичный:
 * никаких размытий и анимаций, чтобы прокрутка шла плавно.
 */
export function BackgroundAura() {
  return <div className={styles.aura} aria-hidden="true" />;
}
