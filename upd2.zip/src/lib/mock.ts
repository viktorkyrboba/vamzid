/**
 * Пробный экзамен: сессия в localStorage, в которую записываются попытки,
 * пройденные по ссылкам с ?mock=1.
 */
import type { Attempt } from "./history";
import type { Skill } from "@/data/tasks/types";

export interface MockPaper {
  key: Skill;
  title: string;
  minutes: number;
  weight: number; // доля итоговой оценки, %
  slugs: string[];
  scored: boolean; // проверяется автоматически
}

export const MOCK_PAPERS: MockPaper[] = [
  {
    key: "rue",
    title: "Reading & Use of English",
    minutes: 75,
    weight: 40,
    scored: true,
    slugs: ["uoe-part-1", "uoe-part-2", "uoe-part-3", "uoe-part-4", "reading-part-5", "reading-part-6", "reading-part-7"],
  },
  { key: "writing", title: "Writing", minutes: 80, weight: 20, scored: false, slugs: ["writing-part-1", "writing-part-2"] },
  {
    key: "listening",
    title: "Listening",
    minutes: 40,
    weight: 20,
    scored: true,
    slugs: ["listening-part-1", "listening-part-2", "listening-part-3", "listening-part-4"],
  },
  { key: "speaking", title: "Speaking", minutes: 14, weight: 20, scored: false, slugs: ["speaking-part-1", "speaking-part-2", "speaking-part-3"] },
];

export interface MockSession {
  startedAt: string;
  /** вариант пробного экзамена (1–5): берутся тесты с этим номером по всем частям */
  test?: number;
  done: Record<string, Attempt>;
}

const KEY = "fce.mock.v1";
export const MOCK_EVENT = "fce-mock-change";

export function loadMock(): MockSession | null {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as MockSession) : null;
  } catch {
    return null;
  }
}

function save(s: MockSession | null) {
  try {
    if (s) localStorage.setItem(KEY, JSON.stringify(s));
    else localStorage.removeItem(KEY);
    window.dispatchEvent(new Event(MOCK_EVENT));
  } catch {
    /* noop */
  }
}

/** Слаги частей для выбранного варианта: «uoe-part-1» → «uoe-part-1-t3». */
export function paperSlugs(p: MockPaper, test = 1) {
  return test === 1 ? p.slugs : p.slugs.map((s) => `${s}-t${test}`);
}

export function startMock(test = 1) {
  save({ startedAt: new Date().toISOString(), test, done: {} });
}

export function resetMock() {
  save(null);
}

export function recordMock(a: Attempt) {
  const s = loadMock();
  if (!s) return;
  s.done[a.slug] = a;
  save(s);
}

export function isMockRun() {
  if (typeof window === "undefined") return false;
  return new URLSearchParams(window.location.search).get("mock") === "1" && !!loadMock();
}

export interface PaperResult {
  paper: MockPaper;
  done: number;
  total: number;
  correct: number;
  questions: number;
  percent: number | null;
  selfCheck: number | null;
}

export function summarize(s: MockSession) {
  const papers: PaperResult[] = MOCK_PAPERS.map((p) => {
    const slugs = paperSlugs(p, s.test ?? 1);
    const attempts = slugs.map((slug) => s.done[slug]).filter(Boolean);
    const correct = attempts.reduce((n, a) => n + (a.correct ?? 0), 0);
    const questions = attempts.reduce((n, a) => n + (a.total ?? 0), 0);
    const checks = attempts.filter((a) => a.selfCheck != null);
    return {
      paper: p,
      done: attempts.length,
      total: slugs.length,
      correct,
      questions,
      percent: p.scored && questions ? Math.round((correct / questions) * 100) : null,
      selfCheck: checks.length ? Math.round((checks.reduce((n, a) => n + (a.selfCheck ?? 0), 0) / checks.length) * 100) : null,
    };
  });

  const scored = papers.filter((p) => p.paper.scored);
  const complete = scored.every((p) => p.done === p.total);
  const weightSum = scored.reduce((n, p) => n + p.paper.weight, 0);
  const overall = complete
    ? Math.round(scored.reduce((n, p) => n + (p.percent ?? 0) * p.paper.weight, 0) / weightSum)
    : null;

  return { papers, complete, overall, level: overall == null ? null : levelFor(overall) };
}

/**
 * Ориентировочное соответствие доли верных ответов уровню.
 * Официальный балл Cambridge рассчитывается иначе — это только ориентир.
 */
export function levelFor(pct: number) {
  if (pct >= 80) return { label: "C1", note: "уровень выше B2 (как Grade A)", tone: "good" as const };
  if (pct >= 75) return { label: "B2", note: "уверенный B2 (как Grade B)", tone: "good" as const };
  if (pct >= 60) return { label: "B2", note: "проходной B2 (как Grade C)", tone: "ok" as const };
  if (pct >= 45) return { label: "B1", note: "пока ниже проходного B2", tone: "warn" as const };
  return { label: "A2–B1", note: "нужна системная подготовка", tone: "warn" as const };
}
