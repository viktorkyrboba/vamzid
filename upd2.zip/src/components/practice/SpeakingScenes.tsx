/**
 * Иллюстрации для Speaking Part 2 (вместо фотографий).
 * Плоский стиль в палитре платформы, чтобы картинки сочетались с интерфейсом.
 */

import type { ReactNode } from "react";
import { SPEAKING_SCENES_EXTRA } from "./SpeakingScenesExtra";

function Frame({ children, label }: { children: ReactNode; label: string }) {
  return (
    <svg viewBox="0 0 400 280" role="img" aria-label={label} style={{ display: "block", width: "100%", height: "auto" }}>
      {children}
    </svg>
  );
}

/** Ночь, комната, ученица занимается одна при свете лампы. */
function StudyNight() {
  return (
    <Frame label="Девушка занимается одна поздно вечером за столом при свете лампы">
      <defs>
        <linearGradient id="sn-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1b2147" />
          <stop offset="1" stopColor="#11152e" />
        </linearGradient>
        <linearGradient id="sn-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0b1030" />
          <stop offset="1" stopColor="#2d2160" />
        </linearGradient>
        <radialGradient id="sn-lamp" cx="0.3" cy="0.55" r="0.55">
          <stop offset="0" stopColor="#ffd590" stopOpacity="0.55" />
          <stop offset="1" stopColor="#ffd590" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="sn-desk" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5a3d33" />
          <stop offset="1" stopColor="#3b2720" />
        </linearGradient>
        <linearGradient id="sn-screen" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#a5b4fc" />
          <stop offset="1" stopColor="#e2b77a" />
        </linearGradient>
      </defs>
      <rect width="400" height="280" fill="url(#sn-wall)" />
      {/* окно */}
      <rect x="236" y="26" width="138" height="118" rx="6" fill="#2a2f5a" />
      <rect x="242" y="32" width="126" height="106" rx="3" fill="url(#sn-sky)" />
      <circle cx="338" cy="58" r="11" fill="#fef3c7" opacity="0.9" />
      {[[248, 108, 18, 30], [268, 96, 14, 42], [284, 112, 22, 26], [308, 100, 16, 38], [326, 116, 20, 22], [348, 104, 18, 34]].map(([x, y, w, h], i) => (
        <rect key={i} x={x} y={y} width={w} height={h} fill="#151937" />
      ))}
      {[[252, 116], [272, 104], [276, 120], [290, 120], [312, 108], [330, 124], [352, 112], [356, 126]].map(([x, y], i) => (
        <rect key={i} x={x} y={y} width="3" height="4" fill="#fcd34d" opacity="0.8" />
      ))}
      <line x1="305" y1="32" x2="305" y2="138" stroke="#2a2f5a" strokeWidth="4" />
      {/* полка */}
      <rect x="30" y="46" width="120" height="6" rx="2" fill="#3b2f5c" />
      {[[36, 18, "#8b5cf6"], [46, 22, "#7b83eb"], [58, 16, "#e2b77a"], [66, 24, "#a78bfa"], [80, 20, "#6366f1"]].map(([x, h, c], i) => (
        <rect key={i} x={x as number} y={46 - (h as number)} width="9" height={h as number} rx="1.5" fill={c as string} opacity="0.85" />
      ))}
      <path d="M118 46 C 112 30 128 26 126 46 Z" fill="#3f7d5c" />
      {/* свет лампы */}
      <rect width="400" height="280" fill="url(#sn-lamp)" />
      {/* стол */}
      <rect x="0" y="196" width="400" height="16" fill="url(#sn-desk)" />
      <rect x="0" y="212" width="400" height="68" fill="#140f24" />
      {/* лампа */}
      <path d="M60 196 L72 196 L70 140 L64 140 Z" fill="#c9ced8" />
      <path d="M44 146 L92 146 L80 118 L56 118 Z" fill="#e6e9f0" />
      <ellipse cx="66" cy="196" rx="18" ry="4" fill="#9aa1b1" />
      {/* книги и кружка */}
      <rect x="282" y="180" width="70" height="8" rx="2" fill="#8b5cf6" />
      <rect x="286" y="172" width="62" height="8" rx="2" fill="#e2b77a" />
      <rect x="280" y="188" width="74" height="8" rx="2" fill="#f59e0b" />
      <rect x="362" y="170" width="20" height="26" rx="4" fill="#f8fafc" />
      <path d="M382 176 q8 0 8 8 q0 8 -8 8" fill="none" stroke="#f8fafc" strokeWidth="3" />
      <path d="M368 164 q-4 -8 2 -14 M376 164 q-4 -8 2 -14" stroke="#cbd5e1" strokeWidth="1.5" fill="none" opacity="0.6" />
      {/* ноутбук */}
      <path d="M150 196 L270 196 L262 188 L158 188 Z" fill="#9aa1b1" />
      <path d="M162 188 L170 120 L262 120 L256 188 Z" fill="#2b2f45" />
      <path d="M168 182 L175 126 L256 126 L250 182 Z" fill="url(#sn-screen)" opacity="0.9" />
      <rect x="186" y="142" width="44" height="4" rx="2" fill="#fff" opacity="0.7" />
      <rect x="186" y="152" width="56" height="3" rx="1.5" fill="#fff" opacity="0.45" />
      <rect x="186" y="160" width="36" height="3" rx="1.5" fill="#fff" opacity="0.45" />
      {/* девушка (вид сзади-сбоку) */}
      <path d="M96 280 C 96 230 112 206 140 202 C 168 206 184 230 184 280 Z" fill="#6d4fd8" />
      <path d="M150 214 C 160 214 170 206 176 198" stroke="#5b3fc4" strokeWidth="10" strokeLinecap="round" fill="none" />
      <circle cx="140" cy="176" r="24" fill="#f1c6a8" />
      <path d="M114 176 C 112 148 168 140 166 172 C 166 184 160 200 156 214 C 148 190 120 200 114 176 Z" fill="#3a2418" />
      <circle cx="146" cy="150" r="9" fill="#3a2418" />
    </Frame>
  );
}

/** День, парк, трое студентов занимаются вместе за столиком. */
function StudyPark() {
  return (
    <Frame label="Трое студентов занимаются вместе за столиком в парке днём">
      <defs>
        <linearGradient id="sp-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#c5c9f7" />
          <stop offset="1" stopColor="#e0e7ff" />
        </linearGradient>
        <linearGradient id="sp-grass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4ade80" />
          <stop offset="1" stopColor="#15803d" />
        </linearGradient>
      </defs>
      <rect width="400" height="280" fill="url(#sp-sky)" />
      <circle cx="340" cy="46" r="22" fill="#fde68a" />
      <circle cx="340" cy="46" r="34" fill="#fde68a" opacity="0.25" />
      <ellipse cx="90" cy="54" rx="40" ry="10" fill="#fff" opacity="0.8" />
      <ellipse cx="240" cy="34" rx="30" ry="8" fill="#fff" opacity="0.7" />
      {/* деревья */}
      {[[40, 150, 46], [120, 140, 38], [330, 150, 50], [390, 140, 34]].map(([x, y, r], i) => (
        <g key={i}>
          <rect x={x - 4} y={y} width="8" height="60" fill="#78524a" />
          <circle cx={x} cy={y - 6} r={r} fill={i % 2 ? "#22c55e" : "#16a34a"} />
          <circle cx={x - r * 0.4} cy={y - r * 0.5} r={r * 0.55} fill="#4ade80" opacity="0.6" />
        </g>
      ))}
      <rect x="0" y="196" width="400" height="84" fill="url(#sp-grass)" />
      {/* зонт */}
      <rect x="198" y="86" width="5" height="120" fill="#e5e7eb" />
      <path d="M120 100 Q 200 50 282 100 Z" fill="#8b5cf6" />
      <path d="M160 100 Q 200 62 242 100" fill="#a78bfa" />
      {/* стол */}
      <rect x="110" y="196" width="180" height="10" rx="3" fill="#f8fafc" />
      <rect x="128" y="206" width="6" height="50" fill="#cbd5e1" />
      <rect x="266" y="206" width="6" height="50" fill="#cbd5e1" />
      {/* люди */}
      {[
        { x: 120, shirt: "#7b83eb", hair: "#1f2937", skin: "#f1c6a8" },
        { x: 200, shirt: "#f59e0b", hair: "#7c2d12", skin: "#c68b62" },
        { x: 280, shirt: "#ec4899", hair: "#111827", skin: "#e8b796" },
      ].map((p, i) => (
        <g key={i}>
          <path d={`M${p.x - 30} 200 C ${p.x - 30} 168 ${p.x - 18} 152 ${p.x} 150 C ${p.x + 18} 152 ${p.x + 30} 168 ${p.x + 30} 200 Z`} fill={p.shirt} />
          <circle cx={p.x} cy={132} r={18} fill={p.skin} />
          <path d={`M${p.x - 19} 130 C ${p.x - 20} 108 ${p.x + 20} 108 ${p.x + 19} 128 C ${p.x + 8} 120 ${p.x - 8} 118 ${p.x - 19} 130 Z`} fill={p.hair} />
          <circle cx={p.x - 6} cy={134} r={1.6} fill="#1f2937" />
          <circle cx={p.x + 6} cy={134} r={1.6} fill="#1f2937" />
          <path d={`M${p.x - 6} 142 Q ${p.x} 147 ${p.x + 6} 142`} stroke="#7c2d12" strokeWidth="1.6" fill="none" strokeLinecap="round" />
        </g>
      ))}
      {/* книги, ноутбук, кофе */}
      <rect x="128" y="186" width="40" height="10" rx="2" fill="#e2b77a" />
      <path d="M180 196 L222 196 L218 190 L184 190 Z" fill="#9aa1b1" />
      <path d="M186 190 L190 164 L216 164 L214 190 Z" fill="#334155" />
      <rect x="236" y="188" width="34" height="8" rx="2" fill="#8b5cf6" />
      <rect x="240" y="181" width="26" height="7" rx="2" fill="#f8fafc" />
      <rect x="152" y="178" width="10" height="12" rx="2" fill="#fff" />
      <rect x="276" y="178" width="10" height="12" rx="2" fill="#fff" />
    </Frame>
  );
}

export const SPEAKING_SCENES: Record<string, () => ReactNode> = {
  "study-night": StudyNight,
  "study-park": StudyPark,
  ...SPEAKING_SCENES_EXTRA,
};
