"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, ChevronDown, LayoutGrid, RotateCcw, X, ListChecks, Timer } from "lucide-react";
import { Fragment, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { CountUp } from "@/components/ui/CountUp";
import type { InputItem, Item, QuizTask } from "@/data/tasks/types";
import { saveAttempt, formatDuration, isMockRun } from "@/lib/history";
import { cn } from "@/lib/cn";
import { ease } from "@/lib/motion";
import { ListeningPlayer } from "./ListeningPlayer";
import { FocusShell } from "./FocusShell";
import { testLabel, nextVariant } from "@/data/tasks";
import styles from "./TaskRunner.module.css";

type Answer = number | string | null;
type Answers = Record<number, Answer>;

const LETTERS = "ABCDEFGH".split("");

const normalize = (s: string) =>
  s
    .toLowerCase()
    .replace(/[’‘`]/g, "'")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/[.,!?;:]+$/g, "")
    .trim();

function isAnswered(a: Answer) {
  return typeof a === "number" || (typeof a === "string" && a.trim().length > 0);
}

function isCorrect(item: Item, a: Answer) {
  if (item.kind === "choice") return a === item.answer;
  return typeof a === "string" && item.accepted.some((acc) => normalize(acc) === normalize(a));
}

function answerText(item: Item, a: Answer) {
  if (!isAnswered(a)) return null;
  return item.kind === "choice" ? item.options[a as number] : (a as string).trim();
}

const correctText = (item: Item) => (item.kind === "choice" ? item.options[item.answer] : item.accepted[0]);

function inputHint(task: QuizTask, item: InputItem) {
  if (task.layout === "transform") return "От 2 до 5 слов, включая ключевое слово";
  if (task.layout === "listening" || task.layout === "extracts") return "Слово или короткая фраза из записи";
  if (item.keyword) return "Одно слово, образованное от основы";
  return "Одно слово";
}

/** Абзацы текста cloze с пропусками. */
function renderCloze(segments: Array<string | number>, renderGap: (n: number) => ReactNode) {
  const paragraphs: ReactNode[][] = [[]];
  segments.forEach((seg, i) => {
    if (typeof seg === "number") {
      paragraphs[paragraphs.length - 1].push(<Fragment key={`g${i}`}>{renderGap(seg)}</Fragment>);
      return;
    }
    seg.split("\n\n").forEach((part, j) => {
      if (j > 0) paragraphs.push([]);
      if (part) paragraphs[paragraphs.length - 1].push(<Fragment key={`t${i}-${j}`}>{part}</Fragment>);
    });
  });
  return paragraphs.map((p, i) => <p key={i}>{p}</p>);
}

/** Предложение с «___» → текст + пропуск. */
function withGap(prompt: string, gap: ReactNode) {
  const [before, after] = prompt.split("___");
  return (
    <>
      {before}
      {gap}
      {after}
    </>
  );
}

export function TaskRunner({ task }: { task: QuizTask }) {
  const ITEMS = task.items;
  const TOTAL = ITEMS.length;
  const empty = useCallback((): Answers => Object.fromEntries(ITEMS.map((q) => [q.n, null])), [ITEMS]);

  const [phase, setPhase] = useState<"work" | "result">("work");
  const [answers, setAnswers] = useState<Answers>(empty);
  const [current, setCurrent] = useState(ITEMS[0].n);
  const [seconds, setSeconds] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const idx = ITEMS.findIndex((q) => q.n === current);
  const item = ITEMS[idx];
  const answeredCount = ITEMS.filter((q) => isAnswered(answers[q.n])).length;
  const isPassage = task.layout === "passage";
  const isListening = task.layout === "listening" || task.layout === "extracts";
  /** в панели показываем текст вопроса, если он не виден рядом с пропуском */
  const showPrompt = isPassage || (isListening && item.kind === "choice");
  const longOptions = item.kind === "choice" && item.options.some((o) => o.length > 22);
  const qWord = isPassage || isListening ? "Вопрос" : "Пропуск";

  useEffect(() => {
    if (phase !== "work") return;
    const id = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [phase]);

  // фокус на поле ввода при смене пропуска (только на устройствах с мышью — без внезапной клавиатуры на телефоне)
  useEffect(() => {
    if (item.kind === "input" && window.matchMedia("(hover: hover)").matches) {
      inputRef.current?.focus({ preventScroll: true });
    }
  }, [current, item.kind]);

  const go = useCallback(
    (delta: number) => {
      const i = Math.min(TOTAL - 1, Math.max(0, idx + delta));
      setCurrent(ITEMS[i].n);
    },
    [ITEMS, TOTAL, idx],
  );

  const choose = useCallback(
    (opt: number) => {
      const next = { ...answers, [current]: opt };
      setAnswers(next);
      const target =
        ITEMS.find((q) => q.n > current && !isAnswered(next[q.n])) ?? ITEMS.find((q) => !isAnswered(next[q.n]));
      if (target) window.setTimeout(() => setCurrent(target.n), 380);
    },
    [ITEMS, answers, current],
  );

  const finish = useCallback(() => {
    const correct = ITEMS.filter((q) => isCorrect(q, answers[q.n])).length;
    saveAttempt({
      slug: task.slug,
      title: task.title,
      paper: task.paper,
      part: task.part,
      kind: "quiz",
      correct,
      total: TOTAL,
      seconds,
      date: new Date().toISOString(),
    });
    setPhase("result");
    window.speechSynthesis?.cancel();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [ITEMS, TOTAL, answers, seconds, task]);

  const restart = () => {
    setAnswers(empty());
    setCurrent(ITEMS[0].n);
    setSeconds(0);
    setPhase("work");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  useEffect(() => {
    if (phase !== "work") return;
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
      const k = e.key.toLowerCase();
      if (item.kind === "choice") {
        const i = /^[1-8]$/.test(k) ? Number(k) - 1 : "abcdefgh".indexOf(k.length === 1 ? k : "_");
        if (i >= 0 && i < item.options.length) {
          e.preventDefault();
          choose(i);
          return;
        }
      }
      if (k === "arrowright") go(1);
      if (k === "arrowleft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, choose, go, item]);

  /* ---------- пропуск в тексте ---------- */
  const gap = (n: number) => {
    const q = ITEMS.find((x) => x.n === n)!;
    const full = answerText(q, answers[n]);
    const text = full && task.gapStyle === "letter" ? LETTERS[answers[n] as number] : full;
    return (
      <button
        className={cn(styles.gap, text && styles.gapFilled, current === n && styles.gapCurrent)}
        onClick={() => setCurrent(n)}
        aria-label={`Пропуск ${n}${text ? `: ${text}` : ""}`}
      >
        <sup>{n}</sup>
        <span>{text ?? " ".repeat(6)}</span>
        {q.kind === "input" && q.keyword && task.layout === "cloze" && (
          <span className={styles.gapStem}>{q.keyword}</span>
        )}
      </button>
    );
  };

  return (
    <FocusShell
      title={`${task.paper.replace("Reading & ", "")} · ${task.part} · ${testLabel(task)}`}
      progress={phase === "result" ? 1 : answeredCount / TOTAL}
      timer={formatDuration(seconds)}
    >
      <AnimatePresence mode="wait">
        {phase === "work" ? (
          <motion.div
            key="work"
            className={cn(styles.workLayout, (isPassage || longOptions || task.layout === "extracts") && styles.workPassage)}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.5, ease: ease.out }}
          >
            <article className={styles.article}>
              <span className={styles.kicker}>
                {task.part} · {task.type}
              </span>
              <h1 className={styles.title}>{task.title}</h1>
              <p className={styles.instruction}>{task.instruction}</p>
              {task.example && (
                <p className={styles.exampleNote}>
                  Пример: <span className={styles.exampleChip}>{task.example.label}</span>
                  <strong>{task.example.answer}</strong>
                </p>
              )}

              {task.layout === "cloze" && task.segments && (
                <div className={styles.text}>
                  {renderCloze(task.segments, (n) =>
                    n === 0 ? (
                      <span className={styles.gapExample}>
                        <sup>0</sup>
                        {task.example?.answer}
                      </span>
                    ) : (
                      gap(n)
                    ),
                  )}
                </div>
              )}

              {isPassage && task.passage && (
                <div className={cn(styles.text, styles.passage)}>
                  {task.passage.split(/\n\n+/).map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
              )}

              {isPassage && task.sections && (
                <div className={styles.sections}>
                  {task.sections.map((sec) => (
                    <section key={sec.label} className={styles.sectionCard}>
                      <h3 className={styles.sectionHead}>
                        <span className={styles.sectionLabel}>{sec.label}</span>
                        {sec.title}
                      </h3>
                      <p>{sec.text}</p>
                    </section>
                  ))}
                </div>
              )}

              {task.layout === "transform" && (
                <ol className={styles.transformList}>
                  {ITEMS.map((q) =>
                    q.kind === "input" ? (
                      <li
                        key={q.n}
                        className={cn(styles.transformCard, current === q.n && styles.transformCurrent)}
                        onClick={() => setCurrent(q.n)}
                      >
                        <span className={styles.transformN}>{q.n}</span>
                        <div>
                          <p className={styles.transformLead}>{q.lead}</p>
                          <span className={styles.keyword}>{q.keyword}</span>
                          <p className={styles.transformPrompt}>{q.prompt && withGap(q.prompt, gap(q.n))}</p>
                        </div>
                      </li>
                    ) : null,
                  )}
                </ol>
              )}

              {task.layout === "listening" && task.script && (
                <>
                  <ListeningPlayer script={task.script} label={`Запись · ${task.part}`} />
                  <ol className={styles.sentenceList}>
                    {ITEMS.map((q) => (
                      <li
                        key={q.n}
                        className={cn(current === q.n && styles.sentenceCurrent, q.kind === "choice" && styles.choiceRow)}
                        onClick={() => setCurrent(q.n)}
                      >
                        {q.kind === "input" ? (
                          q.prompt && withGap(q.prompt, gap(q.n))
                        ) : (
                          <>
                            <span className={styles.rowPrompt}>{q.prompt}</span>
                            <span className={cn(styles.rowAnswer, isAnswered(answers[q.n]) && styles.rowAnswerOn)}>
                              {isAnswered(answers[q.n]) ? LETTERS[answers[q.n] as number] : "—"}
                            </span>
                          </>
                        )}
                      </li>
                    ))}
                  </ol>
                </>
              )}

              {task.layout === "extracts" && (
                <ol className={styles.extracts}>
                  {ITEMS.map((q) =>
                    q.kind === "choice" ? (
                      <li
                        key={q.n}
                        className={cn(styles.extract, current === q.n && styles.extractCurrent)}
                        onClick={() => setCurrent(q.n)}
                      >
                        <div className={styles.extractHead}>
                          <span className={styles.extractN}>{q.n}</span>
                          <div>
                            <p className={styles.extractContext}>{q.context}</p>
                            <p className={styles.extractQ}>{q.prompt}</p>
                          </div>
                          <span className={cn(styles.rowAnswer, isAnswered(answers[q.n]) && styles.rowAnswerOn)}>
                            {isAnswered(answers[q.n]) ? LETTERS[answers[q.n] as number] : "—"}
                          </span>
                        </div>
                        {q.script && <ListeningPlayer script={q.script} label={`Фрагмент ${q.n}`} compact />}
                      </li>
                    ) : null,
                  )}
                </ol>
              )}
            </article>

            {/* ---------- Панель ответа ---------- */}
            <aside className={cn(styles.panel, (isPassage || longOptions || task.layout === "extracts") && styles.panelStatic)}>
              <div className={styles.panelHead}>
                <span className={styles.qLabel}>
                  {qWord} <strong>{current}</strong> из {TOTAL}
                </span>
                {item.kind === "choice" && (
                  <span className={styles.kbd}>
                    <kbd>A</kbd>–<kbd>{LETTERS[item.options.length - 1]}</kbd> или <kbd>1</kbd>–<kbd>{item.options.length}</kbd>
                  </span>
                )}
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={current}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.22, ease: ease.out }}
                >
                  {item.kind === "choice" && item.context && showPrompt && <p className={styles.qContext}>{item.context}</p>}
                  {item.prompt && showPrompt && <p className={styles.qPrompt}>{item.prompt}</p>}

                  {item.kind === "choice" ? (
                    <div className={cn(styles.options, longOptions && styles.optionsLong)}>
                      {item.options.map((opt, i) => (
                        <motion.button
                          key={opt}
                          className={cn(styles.option, answers[current] === i && styles.optionOn)}
                          onClick={() => choose(i)}
                          whileTap={{ scale: 0.98 }}
                        >
                          <span className={styles.letter}>{LETTERS[i]}</span>
                          <span className={styles.optText}>{opt}</span>
                          {answers[current] === i && (
                            <motion.span
                              className={styles.optCheck}
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ type: "spring", stiffness: 500, damping: 24 }}
                            >
                              <Check size={14} strokeWidth={3} />
                            </motion.span>
                          )}
                        </motion.button>
                      ))}
                    </div>
                  ) : (
                    <div className={styles.inputBlock}>
                      {item.keyword && (
                        <span className={styles.inputKeyword}>
                          {task.layout === "transform" ? "Ключевое слово" : "Основа"} · <strong>{item.keyword}</strong>
                        </span>
                      )}
                      {item.prompt && !isPassage && (
                        <p className={styles.inputContext}>{item.prompt.replace("___", "……")}</p>
                      )}
                      <input
                        ref={inputRef}
                        className={styles.input}
                        value={(answers[current] as string | null) ?? ""}
                        onChange={(e) => setAnswers((a) => ({ ...a, [current]: e.target.value }))}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            if (idx < TOTAL - 1) go(1);
                            else (e.target as HTMLInputElement).blur();
                          }
                        }}
                        placeholder="Ваш ответ"
                        autoComplete="off"
                        autoCapitalize="off"
                        autoCorrect="off"
                        spellCheck={false}
                        enterKeyHint={idx < TOTAL - 1 ? "next" : "done"}
                        aria-label={`Ответ на пропуск ${current}`}
                      />
                      <span className={styles.inputHint}>
                        {inputHint(task, item)} · <kbd>Enter</kbd> — дальше
                      </span>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>

              <div className={styles.navRow}>
                <button className={styles.navBtn} onClick={() => go(-1)} disabled={idx === 0} aria-label="Назад">
                  <ArrowLeft size={16} />
                </button>
                <div className={styles.dots} role="tablist" aria-label="Вопросы">
                  {ITEMS.map((q) => (
                    <button
                      key={q.n}
                      role="tab"
                      aria-selected={current === q.n}
                      aria-label={`Вопрос ${q.n}`}
                      className={cn(
                        styles.dot,
                        isAnswered(answers[q.n]) && styles.dotDone,
                        current === q.n && styles.dotCurrent,
                      )}
                      onClick={() => setCurrent(q.n)}
                    >
                      {q.n}
                    </button>
                  ))}
                </div>
                <button
                  className={styles.navBtn}
                  onClick={() => go(1)}
                  disabled={idx === TOTAL - 1}
                  aria-label="Дальше"
                >
                  <ArrowRight size={16} />
                </button>
              </div>

              <button className={cn(styles.finish, answeredCount === TOTAL && styles.finishReady)} onClick={finish}>
                Проверить ответы
                <span className={styles.finishCount}>
                  {answeredCount}/{TOTAL}
                </span>
              </button>
              {answeredCount < TOTAL && answeredCount > 0 && (
                <p className={styles.finishHint}>Пустые пропуски будут засчитаны как ошибки.</p>
              )}
            </aside>
          </motion.div>
        ) : (
          <Results key="result" task={task} answers={answers} seconds={seconds} onRestart={restart} />
        )}
      </AnimatePresence>
    </FocusShell>
  );
}

/* ================================================================== */
/* Results                                                             */
/* ================================================================== */

function Results({
  task,
  answers,
  seconds,
  onRestart,
}: {
  task: QuizTask;
  answers: Answers;
  seconds: number;
  onRestart: () => void;
}) {
  const ITEMS = task.items;
  const TOTAL = ITEMS.length;
  const correct = ITEMS.filter((q) => isCorrect(q, answers[q.n])).length;
  const pct = Math.round((correct / TOTAL) * 100);
  const verdict = pct >= 75 ? "Отличный результат" : pct >= 50 ? "Хорошая основа" : "Есть над чем поработать";
  const note =
    pct >= 75
      ? "Уверенный уровень для этой части экзамена. Закрепите его и переходите к следующему типу заданий."
      : pct >= 50
        ? "Большая часть ответов верна. Разберите ошибки ниже — они подскажут, что повторить."
        : "Не страшно: разбор ниже объясняет логику каждого ответа. Повторите задание через день.";

  const [open, setOpen] = useState<Record<number, boolean>>(() =>
    Object.fromEntries(ITEMS.map((q) => [q.n, !isCorrect(q, answers[q.n])])),
  );
  const [showScript, setShowScript] = useState(false);
  const [mock, setMock] = useState(false);
  useEffect(() => setMock(isMockRun()), []);

  const ringColors = useMemo<[string, string]>(
    () => (pct >= 75 ? ["#34D399", "#e2b77a"] : pct >= 50 ? ["#8B5CF6", "#e2b77a"] : ["#F59E0B", "#8B5CF6"]),
    [pct],
  );

  return (
    <motion.div
      className={styles.results}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: ease.out }}
    >
      <section className={styles.summary}>
        <div className={styles.summaryGlow} aria-hidden="true" />
        <ProgressRing value={pct} size={172} stroke={12} colors={ringColors} delay={0.2}>
          <span className={styles.bigScore}>
            <CountUp to={correct} duration={1.2} />
            <small>из {TOTAL}</small>
          </span>
        </ProgressRing>
        <div className={styles.summaryCopy}>
          <span className={styles.kicker}>
            {task.paper.replace("Reading & ", "")} · {task.part} · {testLabel(task)}
          </span>
          <h1 className={styles.verdict}>{verdict}</h1>
          <p className={styles.note}>{note}</p>
          <div className={styles.summaryStats}>
            <span>
              <strong className={styles.good}>{correct}</strong> верно
            </span>
            <span>
              <strong className={styles.bad}>{TOTAL - correct}</strong> ошибок
            </span>
            <span>
              <strong>{formatDuration(seconds)}</strong> время
            </span>
            <span>
              <strong>{pct}%</strong> точность
            </span>
          </div>
          <div className={styles.summaryActions}>
            {mock && (
              <Link href="/mock" className={styles.primaryBtn}>
                <Timer size={16} /> К пробному экзамену
              </Link>
            )}
            {!mock && nextVariant(task) && (
              <Link href={`/practice/${nextVariant(task)!.slug}`} className={styles.primaryBtn}>
                <ArrowRight size={16} /> {testLabel(nextVariant(task)!)}
              </Link>
            )}
            <button className={mock || nextVariant(task) ? styles.secondaryBtn : styles.primaryBtn} onClick={onRestart}>
              <RotateCcw size={16} /> Пройти ещё раз
            </button>
            <Link href="/practice" className={styles.secondaryBtn}>
              <ListChecks size={16} /> Все задания
            </Link>
            <Link href="/dashboard" className={styles.secondaryBtn}>
              <LayoutGrid size={16} /> Кабинет
            </Link>
          </div>
        </div>
      </section>

      {task.layout === "cloze" && task.segments && (
        <section>
          <h2 className={styles.sectionTitle}>Текст с ответами</h2>
          <div className={cn(styles.text, styles.textReview)}>
            {renderCloze(task.segments, (n) => {
              if (n === 0) return <span className={styles.gapExample}>{task.example?.answer}</span>;
              const q = ITEMS.find((x) => x.n === n)!;
              const ok = isCorrect(q, answers[n]);
              const user = answerText(q, answers[n]);
              return (
                <span className={cn(styles.mark, ok ? styles.markOk : styles.markBad)}>
                  <sup>{n}</sup>
                  {task.gapStyle === "letter" ? (
                    <>
                      {!ok && user && <s>{LETTERS[answers[n] as number]}</s>}
                      <b>{LETTERS[(q as { answer: number }).answer]}</b> {correctText(q)}
                    </>
                  ) : (
                    <>
                      {!ok && user && <s>{user}</s>}
                      {ok && user ? user : correctText(q)}
                    </>
                  )}
                </span>
              );
            })}
          </div>
        </section>
      )}

      {task.layout === "listening" && task.script && (
        <section>
          <button className={styles.scriptToggle} onClick={() => setShowScript((v) => !v)} aria-expanded={showScript}>
            <span className={styles.sectionTitle} style={{ margin: 0 }}>
              Расшифровка записи
            </span>
            <motion.span animate={{ rotate: showScript ? 180 : 0 }}>
              <ChevronDown size={18} />
            </motion.span>
          </button>
          <AnimatePresence initial={false}>
            {showScript && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.4, ease: ease.out }}
                style={{ overflow: "hidden" }}
              >
                <div className={cn(styles.text, styles.textReview, styles.scriptBox)}>
                  {task.script.split(/\n\n+/).map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      )}

      <section>
        <h2 className={styles.sectionTitle}>Разбор</h2>
        <ul className={styles.reviewList}>
          {ITEMS.map((q, i) => {
            const ok = isCorrect(q, answers[q.n]);
            const user = answerText(q, answers[q.n]);
            const isOpen = open[q.n];
            return (
              <motion.li
                key={q.n}
                className={cn(styles.reviewItem, ok ? styles.riOk : styles.riBad)}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45, ease: ease.out, delay: 0.3 + i * 0.05 }}
              >
                <button
                  className={styles.riHead}
                  onClick={() => setOpen((o) => ({ ...o, [q.n]: !o[q.n] }))}
                  aria-expanded={isOpen}
                >
                  <span className={styles.riIcon}>
                    {ok ? <Check size={14} strokeWidth={3} /> : <X size={14} strokeWidth={3} />}
                  </span>
                  <span className={styles.riNum}>{q.n}</span>
                  <span className={styles.riAnswer}>
                    {ok ? (
                      <strong>{user}</strong>
                    ) : (
                      <>
                        {user ? <s>{user}</s> : <em>нет ответа</em>}
                        <ArrowRight size={13} />
                        <strong>{correctText(q)}</strong>
                      </>
                    )}
                  </span>
                  <motion.span
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                    className={styles.riChevron}
                  >
                    <ChevronDown size={16} />
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.35, ease: ease.out }}
                      className={styles.riBodyWrap}
                    >
                      <div className={styles.riBody}>
                        {q.kind === "input" && q.lead && <p className={styles.riContext}>{q.lead}</p>}
                        {q.kind === "choice" && q.context && <p className={styles.riMeta}>{q.context}</p>}
                        {q.prompt && (
                          <p className={styles.riContext}>
                            {q.kind === "input" ? q.prompt.replace("___", `[${correctText(q)}]`) : q.prompt}
                          </p>
                        )}
                        {q.kind === "choice" && (
                          <div className={styles.riOptions}>
                            {q.options.map((o, oi) => (
                              <span
                                key={o}
                                className={cn(
                                  styles.riOpt,
                                  oi === q.answer && styles.riOptRight,
                                  oi === answers[q.n] && oi !== q.answer && styles.riOptWrong,
                                )}
                              >
                                {LETTERS[oi]} · {o}
                              </span>
                            ))}
                          </div>
                        )}
                        <p>{q.explanation}</p>
                        {q.kind === "choice" && q.script && (
                          <details className={styles.riScript}>
                            <summary>Расшифровка фрагмента</summary>
                            {q.script.split(/\n\n+/).map((line, li) => (
                              <p key={li}>{line}</p>
                            ))}
                          </details>
                        )}
                        {q.kind === "input" && q.accepted.length > 1 && (
                          <p className={styles.riAccepted}>Засчитывается: {q.accepted.join(" / ")}</p>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.li>
            );
          })}
        </ul>
      </section>
    </motion.div>
  );
}
