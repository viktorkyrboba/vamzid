/**
 * Дополнительные иллюстрации для Speaking Part 2 (тесты 2-5).
 * Тот же плоский стиль и палитра, что в SpeakingScenes.tsx.
 */

import type { ReactNode } from "react";

function Frame({ children, label }: { children: ReactNode; label: string }) {
  return (
    <svg viewBox="0 0 400 280" role="img" aria-label={label} style={{ display: "block", width: "100%", height: "auto" }}>
      {children}
    </svg>
  );
}

type Pt = [number, number];

/** Человек по грудь: голова, волосы, лицо, торс. */
function Bust({
  x, y, shirt, hair, skin, r = 17, body = 28, h = 46, long = false, hat, glasses = false, mouth = "smile", headphones = false,
}: {
  x: number; y: number; shirt: string; hair: string; skin: string; r?: number; body?: number; h?: number;
  long?: boolean; hat?: string; glasses?: boolean; mouth?: "smile" | "open" | "flat"; headphones?: boolean;
}) {
  const yt = y + r - 2;
  return (
    <g>
      {long && <rect x={x - r - 2} y={y - 6} width={2 * r + 4} height={r * 2 + 12} rx="9" fill={hair} />}
      <path
        d={`M${x - body} ${yt + h} C ${x - body} ${yt + 14} ${x - body * 0.6} ${yt} ${x} ${yt} C ${x + body * 0.6} ${yt} ${x + body} ${yt + 14} ${x + body} ${yt + h} Z`}
        fill={shirt}
      />
      <rect x={x - 4.5} y={yt - 7} width="9" height="10" rx="3" fill={skin} />
      <circle cx={x} cy={y} r={r} fill={skin} />
      <path
        d={`M${x - r - 1} ${y - 2} C ${x - r - 2} ${y - r - 7} ${x + r + 2} ${y - r - 7} ${x + r + 1} ${y - 4} C ${x + r / 2} ${y - r * 0.9} ${x - r / 2} ${y - r} ${x - r - 1} ${y - 2} Z`}
        fill={hair}
      />
      {hat && (
        <g>
          <path d={`M${x - 10} ${y - r + 3} L${x} ${y - r - 26} L${x + 10} ${y - r + 3} Z`} fill={hat} />
          <circle cx={x} cy={y - r - 27} r="3.2" fill="#fde68a" />
          <path d={`M${x - 6} ${y - r - 6} L${x + 5} ${y - r - 14}`} stroke="#fff" strokeWidth="2" opacity="0.7" />
        </g>
      )}
      {headphones && (
        <g>
          <path d={`M${x - r - 1} ${y + 2} C ${x - r - 3} ${y - r - 12} ${x + r + 3} ${y - r - 12} ${x + r + 1} ${y + 2}`} stroke="#1f2937" strokeWidth="3.5" fill="none" />
          <rect x={x - r - 5} y={y - 4} width="8" height="13" rx="3" fill="#1f2937" />
          <rect x={x + r - 3} y={y - 4} width="8" height="13" rx="3" fill="#1f2937" />
        </g>
      )}
      <circle cx={x - r * 0.35} cy={y + 2} r="1.7" fill="#1f2937" />
      <circle cx={x + r * 0.35} cy={y + 2} r="1.7" fill="#1f2937" />
      {glasses && (
        <g stroke="#1f2937" strokeWidth="1.3" fill="none">
          <circle cx={x - r * 0.35} cy={y + 2} r="4.6" />
          <circle cx={x + r * 0.35} cy={y + 2} r="4.6" />
          <line x1={x - r * 0.35 + 4.6} y1={y + 2} x2={x + r * 0.35 - 4.6} y2={y + 2} />
        </g>
      )}
      {mouth === "smile" && <path d={`M${x - 6} ${y + 9} Q ${x} ${y + 15} ${x + 6} ${y + 9}`} stroke="#7c2d12" strokeWidth="1.7" fill="none" strokeLinecap="round" />}
      {mouth === "open" && <path d={`M${x - 6} ${y + 8} Q ${x} ${y + 19} ${x + 6} ${y + 8} Z`} fill="#7c2d12" />}
      {mouth === "flat" && <path d={`M${x - 4} ${y + 10} L${x + 4} ${y + 10}`} stroke="#7c2d12" strokeWidth="1.7" strokeLinecap="round" />}
    </g>
  );
}

/** Человек в полный рост из «палочек» (бёдра в (0,0), единицы ~ пиксели). */
function Figure({
  x, y, s = 1, flip = false, shirt, shorts, skin, hair, shoe = "#f8fafc", lean = 0, arms, legs, ponytail = false, headband,
}: {
  x: number; y: number; s?: number; flip?: boolean; shirt: string; shorts: string; skin: string; hair: string; shoe?: string;
  lean?: number; arms: [Pt, Pt][]; legs: [Pt, Pt][]; ponytail?: boolean; headband?: string;
}) {
  const sh: Pt = [lean, -27];
  const head: Pt = [lean * 1.25, -40];
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      {legs.map(([k, f], i) => (
        <g key={`l${i}`}>
          <polyline points={`0,0 ${k[0]},${k[1]}`} stroke={shorts} strokeWidth="9" strokeLinecap="round" fill="none" />
          <polyline points={`${k[0]},${k[1]} ${f[0]},${f[1]}`} stroke={skin} strokeWidth="6" strokeLinecap="round" fill="none" />
          <ellipse cx={f[0] + 3} cy={f[1] + 2} rx="6" ry="3.4" fill={shoe} />
        </g>
      ))}
      <line x1="0" y1="0" x2={sh[0]} y2={sh[1]} stroke={shirt} strokeWidth="14" strokeLinecap="round" />
      <line x1="0" y1="-3" x2="0" y2="3" stroke={shorts} strokeWidth="13" strokeLinecap="round" />
      {arms.map(([e, hd], i) => (
        <g key={`a${i}`}>
          <polyline points={`${sh[0]},${sh[1] + 2} ${e[0]},${e[1]}`} stroke={shirt} strokeWidth="6" strokeLinecap="round" fill="none" />
          <polyline points={`${e[0]},${e[1]} ${hd[0]},${hd[1]}`} stroke={skin} strokeWidth="4.6" strokeLinecap="round" fill="none" />
          <circle cx={hd[0]} cy={hd[1]} r="3" fill={skin} />
        </g>
      ))}
      <rect x={head[0] - 2.5} y={head[1] + 6} width="5" height="8" fill={skin} />
      {ponytail && <path d={`M${head[0] - 7} ${head[1] - 4} C ${head[0] - 20} ${head[1] - 2} ${head[0] - 20} ${head[1] + 12} ${head[0] - 15} ${head[1] + 16}`} stroke={hair} strokeWidth="5" fill="none" strokeLinecap="round" />}
      <circle cx={head[0]} cy={head[1]} r="9.5" fill={skin} />
      <path d={`M${head[0] - 10} ${head[1] - 1} A10 10 0 0 1 ${head[0] + 10} ${head[1] - 1} C ${head[0] + 4} ${head[1] - 6} ${head[0] - 4} ${head[1] - 6} ${head[0] - 10} ${head[1] - 1} Z`} fill={hair} />
      {headband && <rect x={head[0] - 10} y={head[1] - 6} width="20" height="3.4" fill={headband} />}
      <circle cx={head[0] + 4} cy={head[1] + 1} r="1.2" fill="#1f2937" />
    </g>
  );
}

/* ------------------------------------------------------------------ */
/* Тест 2: празднование                                               */
/* ------------------------------------------------------------------ */

/** Вечер, дома, день рождения за столом с тортом. */
function CelebrateHome() {
  const flags = Array.from({ length: 9 }, (_, i) => {
    const t = (i + 0.5) / 9;
    return { x: 400 * t, y: 38 + 100 * t * (1 - t), c: ["#f59e0b", "#a78bfa", "#ec4899", "#fde68a", "#7b83eb"][i % 5] };
  });
  return (
    <Frame label="Семья и друзья празднуют день рождения дома за столом с тортом">
      <defs>
        <linearGradient id="ch-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3d2f73" />
          <stop offset="1" stopColor="#7a4a74" />
        </linearGradient>
        <radialGradient id="ch-glow" cx="0.5" cy="0.55" r="0.5">
          <stop offset="0" stopColor="#ffd590" stopOpacity="0.5" />
          <stop offset="1" stopColor="#ffd590" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="ch-floor" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3b2720" />
          <stop offset="1" stopColor="#1d1426" />
        </linearGradient>
      </defs>
      <rect width="400" height="280" fill="url(#ch-wall)" />
      <rect y="228" width="400" height="52" fill="url(#ch-floor)" />
      <rect width="400" height="280" fill="url(#ch-glow)" />
      {/* гирлянда */}
      <path d="M0 38 Q 200 138 400 38" stroke="#e2b77a" strokeWidth="1.6" fill="none" />
      {flags.map((f, i) => (
        <path key={i} d={`M${f.x - 10} ${f.y - 1} L${f.x + 10} ${f.y - 1} L${f.x} ${f.y + 22} Z`} fill={f.c} />
      ))}
      {/* воздушные шары */}
      {[[26, 98, "#ec4899"], [52, 74, "#fcd34d"], [378, 96, "#8b5cf6"], [350, 70, "#22c55e"]].map(([x, y, c], i) => (
        <g key={i}>
          <path d={`M${x} ${(y as number) + 22} Q ${(x as number) + (i < 2 ? 8 : -8)} 170 ${i < 2 ? 40 : 360} 206`} stroke="#e5e7eb" strokeWidth="1" fill="none" opacity="0.8" />
          <ellipse cx={x as number} cy={y as number} rx="15" ry="19" fill={c as string} />
          <ellipse cx={(x as number) - 5} cy={(y as number) - 7} rx="3.5" ry="6" fill="#fff" opacity="0.45" />
        </g>
      ))}
      {/* люди */}
      <Bust x={78} y={128} shirt="#7b83eb" hair="#3a2418" skin="#f1c6a8" long hat="#f59e0b" mouth="open" h={62} />
      <Bust x={142} y={132} shirt="#ec4899" hair="#111827" skin="#c68b62" hat="#a78bfa" h={62} mouth="open" />
      <Bust x={200} y={134} r={14} body={22} shirt="#fcd34d" hair="#7c2d12" skin="#e8b796" hat="#ec4899" h={60} mouth="open" />
      <Bust x={262} y={130} shirt="#22c55e" hair="#1f2937" skin="#f1c6a8" glasses hat="#7b83eb" h={62} />
      <Bust x={326} y={128} shirt="#8b5cf6" hair="#7c2d12" skin="#8d5a3b" long hat="#fcd34d" mouth="open" h={62} />
      {/* поднятые руки */}
      <path d="M52 152 L32 118" stroke="#7b83eb" strokeWidth="10" strokeLinecap="round" />
      <circle cx="30" cy="112" r="6" fill="#f1c6a8" />
      <path d="M352 152 L372 118" stroke="#8b5cf6" strokeWidth="10" strokeLinecap="round" />
      <circle cx="374" cy="112" r="6" fill="#8d5a3b" />
      {/* стол */}
      <rect x="22" y="198" width="356" height="10" rx="3" fill="#f8fafc" />
      <path d="M30 208 L370 208 L376 250 L24 250 Z" fill="#a78bfa" />
      <path d="M30 208 L370 208 L372 218 L28 218 Z" fill="#8b5cf6" opacity="0.7" />
      {/* торт */}
      <ellipse cx="200" cy="198" rx="34" ry="5" fill="#e5e7eb" />
      <rect x="176" y="178" width="48" height="19" rx="3" fill="#fde68a" />
      <rect x="182" y="166" width="36" height="13" rx="3" fill="#f9a8d4" />
      <path d="M182 168 q4 8 8 0 q4 8 8 0 q4 8 8 0 q4 8 8 0 q4 8 6 0" fill="#fff" />
      {[190, 200, 210].map((x, i) => (
        <g key={i}>
          <rect x={x - 1.5} y="154" width="3" height="13" fill={["#7b83eb", "#fff", "#ec4899"][i]} />
          <path d={`M${x} 143 q4 6 0 10 q-4 -4 0 -10 Z`} fill="#fcd34d" />
        </g>
      ))}
      {/* стаканы, подарки */}
      {[100, 130, 270, 300].map((x, i) => (
        <rect key={i} x={x} y="184" width="9" height="14" rx="2" fill="#fff" opacity="0.85" />
      ))}
      <rect x="46" y="232" width="34" height="28" rx="2" fill="#ec4899" />
      <rect x="60" y="232" width="6" height="28" fill="#fde68a" />
      <rect x="320" y="238" width="30" height="22" rx="2" fill="#7b83eb" />
      <rect x="332" y="238" width="6" height="22" fill="#fde68a" />
      {/* конфетти */}
      {[[110, 92, "#fcd34d"], [170, 70, "#ec4899"], [236, 82, "#a78bfa"], [290, 66, "#fcd34d"], [130, 60, "#a78bfa"], [214, 104, "#ec4899"], [92, 104, "#22c55e"], [310, 100, "#fcd34d"]].map(([x, y, c], i) => (
        <rect key={i} x={x as number} y={y as number} width="5" height="3" rx="1" fill={c as string} transform={`rotate(${i * 37} ${x} ${y})`} />
      ))}
    </Frame>
  );
}

/** Ночью, уличный фестиваль с фейерверком и фонариками. */
function CelebrateStreet() {
  const burst = (cx: number, cy: number, r: number, c: string, n = 14) =>
    Array.from({ length: n }, (_, i) => {
      const a = (i / n) * Math.PI * 2;
      const x1 = cx + Math.cos(a) * r * 0.35;
      const y1 = cy + Math.sin(a) * r * 0.35;
      const x2 = cx + Math.cos(a) * r;
      const y2 = cy + Math.sin(a) * r;
      return (
        <g key={`${cx}-${i}`}>
          <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={c} strokeWidth="2.2" strokeLinecap="round" />
          <circle cx={cx + Math.cos(a) * r * 1.12} cy={cy + Math.sin(a) * r * 1.12} r="2" fill={c} />
        </g>
      );
    });
  return (
    <Frame label="Люди танцуют и празднуют на уличном фестивале ночью под фейерверком">
      <defs>
        <linearGradient id="cs-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0b1030" />
          <stop offset="0.7" stopColor="#2d2160" />
          <stop offset="1" stopColor="#7a4a74" />
        </linearGradient>
        <radialGradient id="cs-bulb" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffe2a0" stopOpacity="0.9" />
          <stop offset="1" stopColor="#ffe2a0" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="400" height="280" fill="url(#cs-sky)" />
      {[[40, 30], [120, 18], [250, 26], [330, 14], [380, 52], [20, 70]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="1.3" fill="#fef3c7" opacity="0.8" />
      ))}
      {/* фейерверки */}
      {burst(110, 78, 34, "#fcd34d")}
      {burst(290, 60, 42, "#f472b6", 16)}
      {burst(205, 104, 22, "#a5b4fc", 12)}
      {/* дома */}
      {[[0, 130, 60], [56, 108, 54], [106, 140, 44], [246, 120, 56], [298, 100, 50], [344, 128, 56]].map(([x, y, w], i) => (
        <g key={i}>
          <rect x={x} y={y} width={w} height={230 - y} fill="#151937" />
          {[0, 1, 2].map((r) =>
            [0, 1].map((c) => (
              <rect key={`${r}${c}`} x={x + 8 + c * ((w as number) / 2 - 2)} y={y + 12 + r * 22} width="9" height="12" fill="#fcd34d" opacity={(i + r + c) % 3 === 0 ? 0.25 : 0.8} />
            )),
          )}
        </g>
      ))}
      {/* фонарики */}
      <path d="M0 56 Q 100 96 200 74 T 400 70" stroke="#e2b77a" strokeWidth="1.5" fill="none" />
      {[[34, 72], [76, 81], [118, 86], [162, 82], [204, 74], [250, 76], [296, 82], [344, 76], [386, 70]].map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={(y as number) + 7} r="14" fill="url(#cs-bulb)" />
          <ellipse cx={x} cy={(y as number) + 7} rx="6" ry="7.5" fill={["#f59e0b", "#ec4899", "#fcd34d"][i % 3]} />
        </g>
      ))}
      {/* улица */}
      <rect y="228" width="400" height="52" fill="#1d1426" />
      {/* толпа */}
      {[
        { x: 40, y: 196, shirt: "#ec4899", hair: "#3a2418", skin: "#f1c6a8", long: true },
        { x: 112, y: 206, shirt: "#fcd34d", hair: "#111827", skin: "#8d5a3b", long: false },
        { x: 200, y: 192, shirt: "#8b5cf6", hair: "#7c2d12", skin: "#e8b796", long: true },
        { x: 288, y: 206, shirt: "#22c55e", hair: "#1f2937", skin: "#c68b62", long: false },
        { x: 362, y: 196, shirt: "#7b83eb", hair: "#3a2418", skin: "#f1c6a8", long: true },
      ].map((p, i) => (
        <g key={i}>
          <path d={`M${p.x - 24} ${p.y + 16} L${p.x - 40 + (i % 2) * 6} ${p.y - 30}`} stroke={p.shirt} strokeWidth="9" strokeLinecap="round" />
          <circle cx={p.x - 40 + (i % 2) * 6} cy={p.y - 34} r="5.5" fill={p.skin} />
          <path d={`M${p.x + 24} ${p.y + 16} L${p.x + 40 - (i % 2) * 6} ${p.y - 26}`} stroke={p.shirt} strokeWidth="9" strokeLinecap="round" />
          <circle cx={p.x + 40 - (i % 2) * 6} cy={p.y - 30} r="5.5" fill={p.skin} />
          <Bust x={p.x} y={p.y} shirt={p.shirt} hair={p.hair} skin={p.skin} long={p.long} mouth="open" h={80} />
        </g>
      ))}
      {/* бенгальские огни */}
      {[[28, 160], [166, 146]].map(([x, y], i) => (
        <g key={i} stroke="#fde68a" strokeWidth="1.6" strokeLinecap="round">
          {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
            <line key={a} x1={x} y1={y} x2={(x as number) + Math.cos((a * Math.PI) / 180) * 9} y2={(y as number) + Math.sin((a * Math.PI) / 180) * 9} />
          ))}
        </g>
      ))}
      {/* конфетти */}
      {[[70, 150, "#fcd34d"], [150, 170, "#ec4899"], [250, 150, "#a78bfa"], [330, 158, "#fcd34d"], [200, 140, "#22c55e"], [100, 120, "#ec4899"]].map(([x, y, c], i) => (
        <rect key={i} x={x as number} y={y as number} width="5" height="3" rx="1" fill={c as string} transform={`rotate(${i * 41} ${x} ${y})`} />
      ))}
    </Frame>
  );
}

/* ------------------------------------------------------------------ */
/* Тест 3: спорт                                                      */
/* ------------------------------------------------------------------ */

/** День, футбольный матч двух команд. */
function SportTeam() {
  return (
    <Frame label="Две команды играют в футбол на поле со зрителями и воротами">
      <defs>
        <linearGradient id="st-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#c5c9f7" />
          <stop offset="1" stopColor="#e0e7ff" />
        </linearGradient>
        <linearGradient id="st-grass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#22a455" />
          <stop offset="1" stopColor="#15803d" />
        </linearGradient>
      </defs>
      <rect width="400" height="280" fill="url(#st-sky)" />
      <circle cx="60" cy="40" r="20" fill="#fde68a" />
      <ellipse cx="200" cy="40" rx="38" ry="9" fill="#fff" opacity="0.8" />
      {/* трибуна */}
      <rect y="92" width="400" height="48" fill="#6b6fa8" />
      <rect y="92" width="400" height="6" fill="#4b4f86" />
      {Array.from({ length: 40 }, (_, i) => (
        <circle key={i} cx={6 + i * 10} cy={110 + (i % 3) * 9} r="3.6" fill={["#f59e0b", "#ec4899", "#fde68a", "#a78bfa", "#fff"][i % 5]} />
      ))}
      <rect y="140" width="400" height="140" fill="url(#st-grass)" />
      {[0, 1, 2, 3, 4].map((i) => (
        <rect key={i} x={i * 90 - 20} y="140" width="45" height="140" fill="#fff" opacity="0.06" />
      ))}
      <ellipse cx="190" cy="250" rx="150" ry="22" fill="none" stroke="#fff" strokeWidth="2" opacity="0.5" />
      {/* ворота */}
      <g>
        <rect x="330" y="148" width="62" height="52" fill="#fff" opacity="0.12" />
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <line key={i} x1={338 + i * 10} y1="148" x2={338 + i * 10} y2="200" stroke="#fff" strokeWidth="0.8" opacity="0.6" />
        ))}
        {[0, 1, 2, 3].map((i) => (
          <line key={i} x1="330" y1={158 + i * 12} x2="392" y2={158 + i * 12} stroke="#fff" strokeWidth="0.8" opacity="0.6" />
        ))}
        <path d="M330 202 L330 148 L392 148 L392 202" stroke="#fff" strokeWidth="4" fill="none" />
      </g>
      {/* вратарь */}
      <Figure x={360} y={178} s={0.8} flip shirt="#fcd34d" shorts="#1f2937" skin="#c68b62" hair="#111827" shoe="#1f2937" arms={[[[ -14, -42], [-18, -58]], [[14, -42], [18, -58]]]} legs={[[[-10, 14], [-14, 30]], [[10, 14], [14, 30]]]} />
      {/* дальние игроки */}
      <Figure x={90} y={190} s={0.8} shirt="#ef4444" shorts="#fff" skin="#f1c6a8" hair="#3a2418" lean={4} arms={[[[-8, -20], [-16, -14]], [[10, -24], [16, -32]]]} legs={[[[12, 12], [4, 28]], [[-8, 14], [-20, 24]]]} />
      <Figure x={290} y={186} s={0.8} flip shirt="#3b82f6" shorts="#fff" skin="#e8b796" hair="#7c2d12" lean={4} arms={[[[-8, -20], [-16, -14]], [[10, -24], [16, -32]]]} legs={[[[12, 12], [4, 28]], [[-8, 14], [-20, 24]]]} />
      {/* игроки ближнего плана */}
      <Figure x={150} y={204} shirt="#ef4444" shorts="#fff" skin="#c68b62" hair="#111827" lean={5} arms={[[[-12, -22], [-22, -14]], [[12, -24], [20, -34]]]} legs={[[[22, 12], [42, 22]], [[-8, 16], [-18, 32]]]} />
      <Figure x={246} y={204} flip shirt="#3b82f6" shorts="#fff" skin="#f1c6a8" hair="#3a2418" lean={4} arms={[[[-12, -22], [-22, -30]], [[12, -24], [22, -22]]]} legs={[[[16, 10], [10, 30]], [[-12, 16], [-28, 24]]]} />
      {/* мяч */}
      <circle cx="208" cy="232" r="7.5" fill="#fff" />
      <path d="M208 226 l4 3 -1.5 5 h-5 l-1.5 -5 Z" fill="#1f2937" />
      <ellipse cx="208" cy="240" rx="8" ry="2" fill="#0b3d20" opacity="0.4" />
      {/* угловой флажок */}
      <rect x="20" y="206" width="2.5" height="30" fill="#e5e7eb" />
      <path d="M22 206 L36 211 L22 216 Z" fill="#f59e0b" />
    </Frame>
  );
}

/** Закат, девушка бежит одна у озера. */
function SportSolo() {
  return (
    <Frame label="Девушка бегает одна на закате по дорожке вдоль озера">
      <defs>
        <linearGradient id="ss-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2d2160" />
          <stop offset="0.55" stopColor="#c0587a" />
          <stop offset="1" stopColor="#f59e0b" />
        </linearGradient>
        <linearGradient id="ss-lake" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e08a5b" />
          <stop offset="1" stopColor="#3b2f6b" />
        </linearGradient>
        <linearGradient id="ss-path" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a5a55" />
          <stop offset="1" stopColor="#3b2720" />
        </linearGradient>
      </defs>
      <rect width="400" height="280" fill="url(#ss-sky)" />
      <circle cx="270" cy="128" r="46" fill="#fde68a" opacity="0.28" />
      <circle cx="270" cy="128" r="28" fill="#fde68a" />
      <path d="M0 140 L50 104 L100 130 L160 90 L230 134 L300 100 L360 126 L400 108 L400 150 L0 150 Z" fill="#3b2f6b" />
      <path d="M0 150 L70 128 L140 148 L220 126 L320 150 L400 132 L400 160 L0 160 Z" fill="#2a2352" />
      <rect y="150" width="400" height="60" fill="url(#ss-lake)" />
      <rect x="236" y="152" width="68" height="4" rx="2" fill="#fde68a" opacity="0.7" />
      <rect x="248" y="162" width="46" height="3" rx="1.5" fill="#fde68a" opacity="0.5" />
      <rect x="258" y="171" width="28" height="3" rx="1.5" fill="#fde68a" opacity="0.4" />
      {[[60, 170], [120, 186], [330, 180]].map(([x, y], i) => (
        <rect key={i} x={x} y={y} width="26" height="2.5" rx="1.2" fill="#fff" opacity="0.25" />
      ))}
      {/* птицы */}
      <path d="M90 60 q6 -6 12 0 q6 -6 12 0 M140 82 q5 -5 10 0 q5 -5 10 0" stroke="#2a2352" strokeWidth="1.6" fill="none" />
      {/* деревья */}
      {[[30, 180, 30], [370, 176, 34]].map(([x, y, r], i) => (
        <g key={i}>
          <rect x={(x as number) - 4} y={y as number} width="8" height="50" fill="#3b2720" />
          <circle cx={x as number} cy={y as number} r={r as number} fill="#2a4d3a" />
          <circle cx={(x as number) - 8} cy={(y as number) - 10} r={(r as number) * 0.55} fill="#3f7d5c" opacity="0.7" />
        </g>
      ))}
      {/* дорожка */}
      <path d="M0 280 L0 230 Q 200 190 400 222 L400 280 Z" fill="url(#ss-path)" />
      <path d="M0 232 Q 200 192 400 224" stroke="#e2b77a" strokeWidth="2" fill="none" opacity="0.6" />
      <ellipse cx="190" cy="262" rx="46" ry="6" fill="#140f24" opacity="0.45" />
      {/* бегунья */}
      <Figure
        x={190} y={186} s={1.75} lean={5} shirt="#ec4899" shorts="#2d2160" skin="#f1c6a8" hair="#3a2418" ponytail headband="#fcd34d"
        arms={[[[14, -18], [24, -30]], [[-8, -26], [-20, -16]]]}
        legs={[[[22, 8], [14, 30]], [[-6, 16], [-32, 20]]]}
      />
      {/* наушники и бутылка */}
      <g transform="translate(190 186) scale(1.75)">
        <path d="M2 -48 C 4 -56 18 -56 20 -46" stroke="#1f2937" strokeWidth="1.6" fill="none" />
        <rect x="19" y="-47" width="3" height="6" rx="1.4" fill="#1f2937" />
        <rect x="21" y="-40" width="4" height="9" rx="1.6" fill="#7b83eb" />
      </g>
    </Frame>
  );
}

/* ------------------------------------------------------------------ */
/* Тест 4: путешествие                                                */
/* ------------------------------------------------------------------ */

/** Вечер, пассажиры в вагоне поезда. */
function TravelTrain() {
  return (
    <Frame label="Пассажиры едут в поезде и смотрят в окно вагона на закат">
      <defs>
        <linearGradient id="tt-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2b2f5a" />
          <stop offset="1" stopColor="#1b2147" />
        </linearGradient>
        <linearGradient id="tt-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7b83eb" />
          <stop offset="0.6" stopColor="#f0a0a0" />
          <stop offset="1" stopColor="#fcd34d" />
        </linearGradient>
      </defs>
      <rect width="400" height="280" fill="url(#tt-wall)" />
      <rect y="232" width="400" height="48" fill="#140f24" />
      {/* багажная полка */}
      <rect x="0" y="18" width="400" height="7" fill="#3b2f5c" />
      <rect x="30" y="2" width="64" height="16" rx="5" fill="#8b5cf6" />
      <rect x="196" y="4" width="46" height="14" rx="4" fill="#e2b77a" />
      <rect x="300" y="0" width="60" height="18" rx="5" fill="#f59e0b" />
      {/* окно */}
      <rect x="30" y="36" width="340" height="124" rx="8" fill="#3b3f73" />
      <rect x="38" y="44" width="324" height="108" rx="4" fill="url(#tt-sky)" />
      <circle cx="320" cy="124" r="18" fill="#fff6d6" opacity="0.9" />
      <path d="M38 152 L38 118 L90 96 L150 124 L220 90 L290 128 L362 104 L362 152 Z" fill="#6b4d9a" />
      <path d="M38 152 L38 134 Q 120 120 200 136 T 362 130 L362 152 Z" fill="#3f7d5c" />
      {[84, 188, 292].map((x) => (
        <g key={x}>
          <rect x={x} y="70" width="3" height="82" fill="#2a2352" />
          <rect x={x - 10} y="76" width="23" height="3" fill="#2a2352" />
        </g>
      ))}
      <path d="M38 142 Q 200 134 362 144" stroke="#2a2352" strokeWidth="1.4" fill="none" />
      {[[60, 100], [120, 116], [240, 80], [330, 98]].map(([x, y], i) => (
        <rect key={i} x={x} y={y} width="30" height="2.4" rx="1.2" fill="#fff" opacity="0.55" />
      ))}
      <line x1="204" y1="44" x2="204" y2="152" stroke="#3b3f73" strokeWidth="6" />
      {/* спинки сидений */}
      <rect x="92" y="150" width="76" height="82" rx="14" fill="#6d4fd8" />
      <rect x="232" y="150" width="76" height="82" rx="14" fill="#6d4fd8" />
      {/* пассажиры */}
      <Bust x={130} y={128} shirt="#f59e0b" hair="#3a2418" skin="#f1c6a8" long mouth="smile" h={46} />
      <Bust x={270} y={128} shirt="#22c55e" hair="#111827" skin="#c68b62" headphones mouth="flat" h={46} />
      {/* книга и телефон */}
      <path d="M112 196 L130 186 L148 196 L148 212 L130 204 L112 212 Z" fill="#fff" />
      <path d="M130 186 L130 204" stroke="#cbd5e1" strokeWidth="1.5" />
      <path d="M120 198 L128 193 M120 204 L128 199 M134 193 L142 198 M134 199 L142 204" stroke="#94a3b8" strokeWidth="1.2" />
      <rect x="258" y="190" width="20" height="30" rx="3" fill="#111827" transform="rotate(-8 268 205)" />
      <rect x="260" y="193" width="16" height="22" rx="2" fill="#7b83eb" transform="rotate(-8 268 205)" />
      {/* столик */}
      <rect x="40" y="206" width="320" height="10" rx="3" fill="#5a3d33" />
      <rect x="196" y="216" width="8" height="30" fill="#3b2720" />
      <rect x="194" y="188" width="14" height="18" rx="3" fill="#fff" />
      <path d="M208 192 q7 0 7 7 q0 7 -7 7" fill="none" stroke="#fff" strokeWidth="2.5" />
      <path d="M198 182 q-3 -6 2 -10 M204 182 q-3 -6 2 -10" stroke="#cbd5e1" strokeWidth="1.4" fill="none" opacity="0.7" />
      {/* чемодан */}
      <rect x="326" y="196" width="40" height="52" rx="6" fill="#e2b77a" />
      <rect x="334" y="186" width="24" height="10" rx="3" fill="none" stroke="#9aa1b1" strokeWidth="3" />
      <rect x="326" y="214" width="40" height="4" fill="#b8884a" />
    </Frame>
  );
}

/** День, велосипедист в горах. */
function TravelBike() {
  return (
    <Frame label="Путешественник едет на велосипеде по горной дороге с рюкзаком">
      <defs>
        <linearGradient id="tb-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#a5b4fc" />
          <stop offset="1" stopColor="#e0e7ff" />
        </linearGradient>
        <linearGradient id="tb-hill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4ade80" />
          <stop offset="1" stopColor="#15803d" />
        </linearGradient>
      </defs>
      <rect width="400" height="280" fill="url(#tb-sky)" />
      <circle cx="342" cy="44" r="20" fill="#fde68a" />
      <ellipse cx="90" cy="50" rx="40" ry="9" fill="#fff" opacity="0.85" />
      <ellipse cx="220" cy="32" rx="28" ry="7" fill="#fff" opacity="0.7" />
      <path d="M0 150 L70 62 L120 120 L180 40 L260 134 L320 84 L400 150 Z" fill="#8f94d8" />
      <path d="M70 62 L52 86 L66 82 L74 92 L82 80 L92 88 Z" fill="#fff" />
      <path d="M180 40 L158 74 L172 68 L182 80 L192 66 L204 76 Z" fill="#fff" />
      <path d="M0 160 Q 90 120 180 152 T 400 140 L400 280 L0 280 Z" fill="url(#tb-hill)" />
      {[[40, 150, 14], [350, 144, 16], [372, 156, 11]].map(([x, y, r], i) => (
        <g key={i}>
          <rect x={(x as number) - 2} y={y as number} width="4" height="16" fill="#78524a" />
          <circle cx={x as number} cy={(y as number) - 2} r={r as number} fill="#166534" />
        </g>
      ))}
      {/* дорога */}
      <path d="M0 232 L400 224 L400 280 L0 280 Z" fill="#4b4f6e" />
      <path d="M0 232 L400 224" stroke="#e5e7eb" strokeWidth="2" />
      <path d="M0 262 L400 256" stroke="#e2b77a" strokeWidth="3" strokeDasharray="22 16" />
      {/* указатель */}
      <rect x="36" y="186" width="4" height="44" fill="#78524a" />
      <path d="M40 190 L84 190 L92 198 L84 206 L40 206 Z" fill="#fcd34d" />
      <rect x="46" y="196" width="30" height="2.5" fill="#78524a" />
      {/* велосипед */}
      <g>
        <circle cx="150" cy="224" r="27" fill="none" stroke="#1f2937" strokeWidth="4" />
        <circle cx="252" cy="224" r="27" fill="none" stroke="#1f2937" strokeWidth="4" />
        {[0, 45, 90, 135].map((a) => (
          <g key={a} stroke="#cbd5e1" strokeWidth="0.8">
            <line x1={150 + Math.cos((a * Math.PI) / 180) * 26} y1={224 + Math.sin((a * Math.PI) / 180) * 26} x2={150 - Math.cos((a * Math.PI) / 180) * 26} y2={224 - Math.sin((a * Math.PI) / 180) * 26} />
            <line x1={252 + Math.cos((a * Math.PI) / 180) * 26} y1={224 + Math.sin((a * Math.PI) / 180) * 26} x2={252 - Math.cos((a * Math.PI) / 180) * 26} y2={224 - Math.sin((a * Math.PI) / 180) * 26} />
          </g>
        ))}
        <g stroke="#7b83eb" strokeWidth="4.5" strokeLinecap="round" fill="none">
          <path d="M150 224 L192 226 L182 192 Z" />
          <path d="M182 192 L238 192 L192 226 M238 192 L252 224 M238 192 L236 182" />
        </g>
        <path d="M228 182 L246 180" stroke="#1f2937" strokeWidth="4" strokeLinecap="round" />
        <path d="M172 188 L192 188" stroke="#1f2937" strokeWidth="5" strokeLinecap="round" />
        <circle cx="192" cy="226" r="5" fill="#9aa1b1" />
        <rect x="204" y="198" width="6" height="14" rx="3" fill="#38bdf8" />
        {/* багаж */}
        <rect x="118" y="196" width="30" height="24" rx="5" fill="#f59e0b" />
        <rect x="124" y="200" width="18" height="6" rx="2" fill="#fcd34d" />
      </g>
      {/* велосипедист */}
      <path d="M184 186 L208 198 L196 222" stroke="#2d2160" strokeWidth="10" strokeLinecap="round" fill="none" />
      <path d="M196 222 L200 232" stroke="#f1c6a8" strokeWidth="5" strokeLinecap="round" />
      <ellipse cx="202" cy="234" rx="7" ry="3" fill="#f8fafc" />
      <path d="M184 186 L186 214 L188 224" stroke="#2d2160" strokeWidth="9" strokeLinecap="round" fill="none" opacity="0.65" />
      <path d="M186 184 L216 152" stroke="#ec4899" strokeWidth="17" strokeLinecap="round" />
      <rect x="188" y="148" width="24" height="30" rx="8" fill="#8b5cf6" transform="rotate(-8 200 163)" />
      <path d="M210 162 L238 182" stroke="#f1c6a8" strokeWidth="5" strokeLinecap="round" />
      <circle cx="239" cy="183" r="3.5" fill="#f1c6a8" />
      <circle cx="226" cy="142" r="10" fill="#f1c6a8" />
      <path d="M215 142 A11 11 0 0 1 238 140 L240 143 L216 144 Z" fill="#fcd34d" />
      <circle cx="231" cy="143" r="1.3" fill="#1f2937" />
      <path d="M229 149 Q 232 151 235 148" stroke="#7c2d12" strokeWidth="1.3" fill="none" />
    </Frame>
  );
}

/* ------------------------------------------------------------------ */
/* Тест 5: работа в разных местах                                     */
/* ------------------------------------------------------------------ */

/** Современный офис, коллеги за соседними столами. */
function WorkOffice() {
  return (
    <Frame label="Коллеги работают за компьютерами в современном открытом офисе">
      <defs>
        <linearGradient id="wo-win" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2d2160" />
          <stop offset="1" stopColor="#f0a070" />
        </linearGradient>
        <linearGradient id="wo-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2b2f5a" />
          <stop offset="1" stopColor="#1b2147" />
        </linearGradient>
        <radialGradient id="wo-lamp" cx="0.5" cy="0" r="0.8">
          <stop offset="0" stopColor="#ffd590" stopOpacity="0.55" />
          <stop offset="1" stopColor="#ffd590" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="400" height="280" fill="url(#wo-wall)" />
      {/* окно с городом */}
      <rect x="150" y="26" width="240" height="118" rx="4" fill="url(#wo-win)" />
      {[[158, 90, 24], [186, 66, 20], [210, 96, 28], [242, 74, 22], [268, 100, 26], [298, 60, 22], [324, 86, 26], [354, 70, 30]].map(([x, y, w], i) => (
        <g key={i}>
          <rect x={x} y={y} width={w} height={144 - y} fill="#151937" />
          <rect x={(x as number) + 5} y={(y as number) + 8} width="4" height="5" fill="#fcd34d" opacity="0.8" />
          <rect x={(x as number) + 5} y={(y as number) + 22} width="4" height="5" fill="#fcd34d" opacity={i % 2 ? 0.8 : 0.3} />
        </g>
      ))}
      {[210, 270, 330].map((x) => (
        <line key={x} x1={x} y1="26" x2={x} y2="144" stroke="#2a2f5a" strokeWidth="4" />
      ))}
      {/* доска */}
      <rect x="14" y="40" width="112" height="84" rx="4" fill="#f1f5f9" />
      <rect x="14" y="40" width="112" height="84" rx="4" fill="none" stroke="#9aa1b1" strokeWidth="3" />
      {[[24, 50, "#fcd34d"], [48, 50, "#f9a8d4"], [72, 50, "#a5b4fc"], [96, 50, "#fcd34d"], [24, 72, "#a5b4fc"], [56, 78, "#f9a8d4"]].map(([x, y, c], i) => (
        <rect key={i} x={x as number} y={y as number} width="20" height="18" fill={c as string} transform={`rotate(${(i % 3) - 1} ${x} ${y})`} />
      ))}
      <path d="M24 108 L60 100 L84 110 L112 96" stroke="#6366f1" strokeWidth="2.4" fill="none" />
      <circle cx="60" cy="100" r="2.6" fill="#6366f1" />
      <circle cx="112" cy="96" r="2.6" fill="#6366f1" />
      {/* потолочные лампы */}
      {[70, 200, 330].map((x) => (
        <g key={x}>
          <rect x="0" y="0" width="400" height="0" />
          <ellipse cx={x} cy="0" rx="70" ry="40" fill="url(#wo-lamp)" />
          <rect x={x - 22} y="0" width="44" height="6" rx="2" fill="#e6e9f0" />
        </g>
      ))}
      {/* пол */}
      <rect y="226" width="400" height="54" fill="#140f24" />
      {/* люди за столами */}
      <Bust x={74} y={134} shirt="#7b83eb" hair="#3a2418" skin="#f1c6a8" long h={50} />
      <Bust x={200} y={136} shirt="#ec4899" hair="#111827" skin="#c68b62" headphones glasses={false} h={50} mouth="flat" />
      <Bust x={326} y={134} shirt="#f59e0b" hair="#7c2d12" skin="#e8b796" glasses h={50} />
      {/* столы и мониторы */}
      {[74, 200, 326].map((x, i) => (
        <g key={x}>
          <rect x={x - 56} y="198" width="112" height="9" rx="3" fill="#e6e9f0" />
          <rect x={x - 52} y="207" width="104" height="28" fill="#3b2f5c" />
          <rect x={x - 26} y="154" width="52" height="38" rx="3" fill="#2b2f45" />
          <rect x={x - 22} y="158" width="44" height="30" rx="2" fill="#4b4f6e" />
          <circle cx={x} cy="173" r="4" fill="#9aa1b1" />
          <rect x={x - 4} y="192" width="8" height="6" fill="#9aa1b1" />
          <rect x={x - 20} y="195" width="40" height="3" rx="1.5" fill="#cbd5e1" />
          <rect x={x + 34} y="186" width="11" height="12" rx="2" fill={["#fff", "#fcd34d", "#a78bfa"][i]} />
        </g>
      ))}
      {/* растение */}
      <rect x="132" y="200" width="22" height="26" rx="3" fill="#e2b77a" />
      <path d="M143 200 C 130 180 134 166 140 158 M143 200 C 152 176 160 172 164 164 M143 200 C 143 184 146 170 146 156" stroke="#3f7d5c" strokeWidth="6" strokeLinecap="round" fill="none" />
    </Frame>
  );
}

/** Вечер, фрилансер с ноутбуком в кафе. */
function WorkCafe() {
  return (
    <Frame label="Мужчина работает на ноутбуке за столиком в уютном кафе">
      <defs>
        <linearGradient id="wc-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a3470" />
          <stop offset="1" stopColor="#5e3b52" />
        </linearGradient>
        <linearGradient id="wc-street" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7b83eb" />
          <stop offset="1" stopColor="#f0a070" />
        </linearGradient>
        <radialGradient id="wc-lamp" cx="0.5" cy="0.3" r="0.6">
          <stop offset="0" stopColor="#ffd590" stopOpacity="0.7" />
          <stop offset="1" stopColor="#ffd590" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="400" height="280" fill="url(#wc-wall)" />
      {/* окно */}
      <rect x="14" y="36" width="130" height="130" rx="6" fill="#3b2f5c" />
      <rect x="20" y="42" width="118" height="118" rx="3" fill="url(#wc-street)" />
      {[[24, 104, 24, 56], [50, 90, 28, 70], [80, 110, 22, 50], [104, 96, 30, 64]].map(([x, y, w, h], i) => (
        <g key={i}>
          <rect x={x} y={y} width={w} height={h} fill="#2a2352" />
          <rect x={(x as number) + 6} y={(y as number) + 10} width="5" height="6" fill="#fcd34d" opacity="0.85" />
        </g>
      ))}
      <rect x="20" y="146" width="118" height="14" fill="#3b2720" />
      <line x1="79" y1="42" x2="79" y2="160" stroke="#3b2f5c" strokeWidth="5" />
      <text x="26" y="62" fontSize="11" fontWeight="700" fill="#fff" fontFamily="sans-serif" opacity="0.9" transform="scale(1)">CAFE</text>
      {/* меню-доска */}
      <rect x="168" y="40" width="82" height="58" rx="3" fill="#1f2937" stroke="#a5754a" strokeWidth="4" />
      {[54, 66, 78].map((y, i) => (
        <g key={y}>
          <rect x="178" y={y} width={32 - i * 4} height="3.2" rx="1.6" fill="#f8fafc" opacity="0.85" />
          <rect x="222" y={y} width="16" height="3.2" rx="1.6" fill="#fcd34d" opacity="0.85" />
        </g>
      ))}
      <path d="M180 90 q4 -6 8 0 q4 6 8 0" stroke="#f9a8d4" strokeWidth="2" fill="none" />
      {/* лампы */}
      {[190, 300].map((x) => (
        <g key={x}>
          <ellipse cx={x} cy="58" rx="60" ry="70" fill="url(#wc-lamp)" opacity={x === 190 ? 0 : 1} />
        </g>
      ))}
      {[300, 350].map((x, i) => (
        <g key={x}>
          <ellipse cx={x} cy="150" rx="55" ry="60" fill="url(#wc-lamp)" />
          <line x1={x} y1="0" x2={x} y2={30 + i * 6} stroke="#e2b77a" strokeWidth="1.5" />
          <path d={`M${x - 14} ${46 + i * 6} Q ${x} ${22 + i * 6} ${x + 14} ${46 + i * 6} Z`} fill="#fcd34d" />
        </g>
      ))}
      {/* стойка и бариста */}
      <Bust x={300} y={108} r={15} body={25} shirt="#22c55e" hair="#3a2418" skin="#c68b62" h={70} />
      <path d="M284 96 L316 96 L316 104 L284 104 Z" fill="#fff" opacity="0" />
      <rect x="258" y="158" width="142" height="12" fill="#e2b77a" />
      <rect x="258" y="170" width="142" height="66" fill="#3b2720" />
      <rect x="352" y="130" width="34" height="28" rx="3" fill="#9aa1b1" />
      <rect x="358" y="120" width="22" height="10" rx="2" fill="#cbd5e1" />
      <rect x="262" y="146" width="14" height="12" rx="2" fill="#fff" />
      <rect x="282" y="146" width="14" height="12" rx="2" fill="#fff" />
      {/* пол */}
      <rect y="236" width="400" height="44" fill="#1d1426" />
      {/* клиент */}
      <Bust x={178} y={152} r={18} body={30} shirt="#fcd34d" hair="#3a2418" skin="#f1c6a8" glasses h={70} mouth="flat" />
      <path d="M160 168 q18 -14 36 0" fill="none" stroke="#1f2937" strokeWidth="0" />
      {/* стол */}
      <rect x="60" y="214" width="250" height="10" rx="4" fill="#a5754a" />
      <rect x="180" y="224" width="9" height="40" fill="#78524a" />
      <rect x="150" y="262" width="70" height="6" rx="3" fill="#78524a" />
      {/* ноутбук (крышка к нам) */}
      <path d="M130 214 L228 214 L224 204 L134 204 Z" fill="#9aa1b1" />
      <path d="M130 204 L136 174 L224 174 L228 204 Z" fill="#cbd5e1" />
      <circle cx="180" cy="190" r="6" fill="#e2b77a" />
      <rect x="150" y="182" width="12" height="7" rx="2" fill="#8b5cf6" />
      {/* кружка, круассан, блокнот, цветок */}
      <rect x="248" y="194" width="22" height="20" rx="4" fill="#f8fafc" />
      <path d="M270 199 q9 0 9 8 q0 8 -9 8" fill="none" stroke="#f8fafc" strokeWidth="3" />
      <path d="M254 188 q-4 -8 2 -14 M262 188 q-4 -8 2 -14" stroke="#cbd5e1" strokeWidth="1.5" fill="none" opacity="0.7" />
      <ellipse cx="96" cy="212" rx="26" ry="4" fill="#f8fafc" />
      <path d="M80 208 Q 96 190 112 208 Q 96 214 80 208 Z" fill="#e2a24d" />
      <rect x="276" y="206" width="22" height="8" rx="1.5" fill="#7b83eb" />
      <rect x="64" y="196" width="8" height="18" rx="2" fill="#e2b77a" />
      <path d="M68 196 q-8 -10 0 -18 q8 8 0 18 Z" fill="#ec4899" />
    </Frame>
  );
}

export const SPEAKING_SCENES_EXTRA: Record<string, () => ReactNode> = {
  "celebrate-home": CelebrateHome,
  "celebrate-street": CelebrateStreet,
  "sport-team": SportTeam,
  "sport-solo": SportSolo,
  "travel-train": TravelTrain,
  "travel-bike": TravelBike,
  "work-office": WorkOffice,
  "work-cafe": WorkCafe,
};
