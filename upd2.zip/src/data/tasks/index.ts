import type { Skill, Task } from "./types";
import { readingPart5, uoePart1, uoePart2, uoePart3, uoePart4 } from "./rue";
import { listeningPart2, speakingPart1, speakingPart2, speakingPart3, writingPart1, writingPart2 } from "./other";
import { readingPart6, readingPart7 } from "./reading";
import { listeningPart1, listeningPart3, listeningPart4 } from "./listening";

import { uoePart1Tests, uoePart2Tests } from "./variants/uoe12";
import { uoePart3Tests, uoePart4Tests } from "./variants/uoe34";
import { readingPart5Tests } from "./variants/reading5";
import { readingPart6Tests } from "./variants/reading6";
import { readingPart7Tests } from "./variants/reading7";
import { listeningPart1Tests, listeningPart2Tests } from "./variants/listening12";
import { listeningPart3Tests, listeningPart4Tests } from "./variants/listening34";
import { speakingPart2Tests } from "./variants/speaking2";
import { speakingPart1Tests, speakingPart3Tests, writingPart1Tests, writingPart2Tests } from "./variants/writingSpeaking";

export * from "./types";

export const TASKS: Task[] = [
  uoePart1,
  uoePart2,
  uoePart3,
  uoePart4,
  readingPart5,
  readingPart6,
  readingPart7,
  writingPart1,
  writingPart2,
  listeningPart1,
  listeningPart2,
  listeningPart3,
  listeningPart4,
  speakingPart1,
  speakingPart2,
  speakingPart3,
  // варианты 2–5 каждой части
  ...uoePart1Tests,
  ...uoePart2Tests,
  ...uoePart3Tests,
  ...uoePart4Tests,
  ...readingPart5Tests,
  ...readingPart6Tests,
  ...readingPart7Tests,
  ...writingPart1Tests,
  ...writingPart2Tests,
  ...listeningPart1Tests,
  ...listeningPart2Tests,
  ...listeningPart3Tests,
  ...listeningPart4Tests,
  ...speakingPart1Tests,
  ...speakingPart2Tests,
  ...speakingPart3Tests,
];

export const getTask = (slug: string) => TASKS.find((t) => t.slug === slug);

/** Сколько вариантов есть у каждой части экзамена. */
export const TESTS_PER_PART = 5;

/** slug части без номера варианта: «uoe-part-1-t3» → «uoe-part-1». */
export const baseSlug = (slug: string) => slug.replace(/-t\d+$/, "");

/** Номер варианта задания (у первого варианта поля test нет). */
export const testNo = (t: Task) => t.test ?? 1;

/** Первые варианты — по одному на каждую часть экзамена, в порядке экзамена. */
export const PARTS: Task[] = TASKS.filter((t) => testNo(t) === 1);

/** Все варианты одной части, отсортированные по номеру. */
export const variantsOf = (slug: string) =>
  TASKS.filter((t) => baseSlug(t.slug) === baseSlug(slug)).sort((a, b) => testNo(a) - testNo(b));

/** Следующий вариант той же части (или null, если это последний). */
export const nextVariant = (t: Task) => variantsOf(t.slug).find((v) => testNo(v) === testNo(t) + 1) ?? null;

/** «Reading & Use of English · Part 5 · Тест 3» без лишнего. */
export const testLabel = (t: Task) => `Тест ${testNo(t)}`;

export const SKILLS: Array<{ key: Skill; title: string; text: string }> = [
  { key: "rue", title: "Reading & Use of English", text: "1 ч 15 мин · 7 частей · 40% оценки" },
  { key: "writing", title: "Writing", text: "1 ч 20 мин · 2 части · 20% оценки" },
  { key: "listening", title: "Listening", text: "≈ 40 мин · 4 части · 20% оценки" },
  { key: "speaking", title: "Speaking", text: "14 мин · 4 части · 20% оценки" },
];

/** Части экзамена, для которых заданий пока нет — показываются в каталоге как «скоро». */
/** Части экзамена, для которых заданий пока нет — показываются в каталоге как «скоро». */
export const UPCOMING: Record<Skill, string[]> = {
  rue: [],
  writing: [],
  listening: [],
  speaking: [],
};

export const taskHref = (slug: string) => `/practice/${slug}`;
