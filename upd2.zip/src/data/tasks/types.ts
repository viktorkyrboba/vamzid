/**
 * Модель заданий платформы.
 * quiz — задания с автопроверкой (choice / input), writing — тексты, speaking — запись ответов.
 */

export type Skill = "rue" | "writing" | "listening" | "speaking";

export interface ChoiceItem {
  kind: "choice";
  n: number;
  /** текст вопроса */
  prompt?: string;
  /** пояснение к ситуации (Listening Part 1: «You hear a woman…») */
  context?: string;
  /** отдельная запись к вопросу (Listening Part 1) */
  script?: string;
  options: string[];
  answer: number;
  explanation: string;
}

export interface InputItem {
  kind: "input";
  n: number;
  /** предложение с пропуском: «___» обозначает место ответа */
  prompt?: string;
  /** первое предложение (Key word transformation) */
  lead?: string;
  /** ключевое слово (Part 4) или слово-основа (Part 3) */
  keyword?: string;
  /** все допустимые варианты ответа */
  accepted: string[];
  explanation: string;
}

export type Item = ChoiceItem | InputItem;

interface BaseTask {
  slug: string;
  skill: Skill;
  paper: string;
  part: string;
  type: string;
  /** номер варианта (1–5); у первого варианта slug без суффикса, у остальных — «-t2»…«-t5» */
  test?: number;
  title: string;
  summary: string;
  instruction: string;
  minutes: number;
}

export interface QuizTask extends BaseTask {
  kind: "quiz";
  /**
   * cloze — текст с пропусками; passage — текст и вопросы; transform — Part 4;
   * listening — одна запись и вопросы; extracts — отдельная запись к каждому вопросу.
   */
  layout: "cloze" | "passage" | "transform" | "listening" | "extracts";
  /** cloze: текст, числа — номера пропусков (0 — пример) */
  segments?: Array<string | number>;
  /** в пропуске показывается буква варианта, а не текст (Gapped text) */
  gapStyle?: "letter";
  /** passage: текст для чтения, абзацы разделены пустой строкой */
  passage?: string;
  /** passage: несколько текстов A–D (Multiple matching) */
  sections?: Array<{ label: string; title: string; text: string }>;
  /** listening: сценарий; строки «M:» / «F:» читаются мужским / женским голосом */
  script?: string;
  example?: { label: string; answer: string };
  items: Item[];
}

export type WritingGenre = "essay" | "article" | "email" | "review" | "report";

export interface WritingVariant {
  id: string;
  genre: WritingGenre;
  label: string;
  context: string;
  question: string;
  notes?: string[];
}

export interface WritingTask extends BaseTask {
  kind: "writing";
  variants: WritingVariant[];
  minWords: number;
  maxWords: number;
}

export interface SpeakingStage {
  text: string;
  seconds: number;
  /** подпись этапа, например «Part 4» */
  label?: string;
  /** схема для совместного задания (Part 3) */
  mindmap?: { center: string; prompts: string[] };
  /** иллюстрации для сравнения (Part 2), ключи из SPEAKING_SCENES */
  images?: string[];
  /** короткий вопрос над картинками, как на экзаменационном листе */
  question?: string;
}

export interface SpeakingTask extends BaseTask {
  kind: "speaking";
  stages: SpeakingStage[];
  tips: string[];
}

export type Task = QuizTask | WritingTask | SpeakingTask;
