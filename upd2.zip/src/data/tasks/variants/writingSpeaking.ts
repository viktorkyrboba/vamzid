import type { SpeakingTask, WritingTask } from "../types";

/* ==========================================================================
   Writing Part 1–2, Speaking Part 1 и 3–4 — варианты 2–5
   ========================================================================== */

const w1 = (
  test: number,
  title: string,
  context: string,
  question: string,
  notes: string[],
): WritingTask => ({
  kind: "writing",
  slug: `writing-part-1-t${test}`,
  test,
  skill: "writing",
  paper: "Writing",
  part: "Part 1",
  type: "Essay",
  title,
  summary: "Эссе 140–190 слов по трём пунктам",
  instruction: "Напишите эссе на 140–190 слов. Раскройте оба пункта из заметок и добавьте собственную идею.",
  minutes: 40,
  minWords: 140,
  maxWords: 190,
  variants: [{ id: `t${test}-essay`, genre: "essay", label: "Essay", context, question, notes }],
});

export const writingPart1Tests: WritingTask[] = [
  w1(
    2,
    "Working from home",
    "In your English class you have been talking about work and modern life. Now your English teacher has asked you to write an essay.",
    "Do you think more people should work from home?",
    ["flexible time", "contact with colleagues", "your own idea"],
  ),
  w1(
    3,
    "Zoos and wildlife",
    "In your English class you have been talking about animals and the natural world. Now your English teacher has asked you to write an essay.",
    "Are zoos still necessary in the modern world?",
    ["protecting rare species", "animals' living conditions", "your own idea"],
  ),
  w1(
    4,
    "Public transport in cities",
    "In your English class you have been talking about city life. Now your English teacher has asked you to write an essay.",
    "Should city councils make public transport free for everyone?",
    ["traffic and pollution", "cost to the city", "your own idea"],
  ),
  w1(
    5,
    "Volunteering for young people",
    "In your English class you have been talking about community and society. Now your English teacher has asked you to write an essay.",
    "Should all teenagers be required to do volunteer work?",
    ["useful experience", "free time for studying", "your own idea"],
  ),
];

const w2 = (test: number, title: string, article: string, email: [string, string], review: string): WritingTask => ({
  kind: "writing",
  slug: `writing-part-2-t${test}`,
  test,
  skill: "writing",
  paper: "Writing",
  part: "Part 2",
  type: "Article / Email / Review",
  title,
  summary: "Один текст на выбор: статья, письмо или рецензия",
  instruction: "Выберите одно из трёх заданий и напишите текст на 140–190 слов в подходящем стиле.",
  minutes: 40,
  minWords: 140,
  maxWords: 190,
  variants: [
    {
      id: `t${test}-article`,
      genre: "article",
      label: "Article",
      context: "You have seen this announcement in an English-language magazine for teenagers.",
      question: article,
    },
    {
      id: `t${test}-email`,
      genre: "email",
      label: "Email",
      context: email[0],
      question: email[1],
    },
    {
      id: `t${test}-review`,
      genre: "review",
      label: "Review",
      context: "You see this notice on an English-language website for students.",
      question: review,
    },
  ],
});

export const writingPart2Tests: WritingTask[] = [
  w2(
    2,
    "Choose your task: sport, school trip, restaurant",
    "Articles wanted! A sport or activity I love. Write about a sport or activity that you enjoy doing. How did you start? What do you like about it? Would you advise other teenagers to try it? The best articles will be published next month.",
    [
      "You have received this email from your English-speaking friend, Sam.",
      "Our class is organising a school trip abroad next spring and we can't decide where to go. You know your region well. Which place would you suggest we visit? What could we see and do there? And how much money should we take? Write soon, Sam",
    ],
    "Reviews wanted: local restaurants. Have you eaten at a restaurant or cafe in your town recently? Tell us about the food and the service, say what you liked and didn't like, and explain whether you would recommend it to other students.",
  ),
  w2(
    3,
    "Choose your task: inspiring person, party, book",
    "Articles wanted! A person who has inspired me. Tell us about someone who has had an important influence on your life. Who is this person? What have they done? Why do they inspire you? The best articles will be published next month.",
    [
      "You have received this email from your English-speaking friend, Jo.",
      "It's our friend Mia's birthday next month and I'd like to organise a surprise party for her. Where do you think we should have it? What kind of food and music should we have? And how can we keep it a secret? Write soon, Jo",
    ],
    "Reviews wanted: books worth reading. Have you read a book recently that you really enjoyed or didn't enjoy? Tell us what the book is about, what you thought of it, and whether you would recommend it to other students.",
  ),
  w2(
    4,
    "Choose your task: festival, internship, museum",
    "Articles wanted! A festival or celebration in my country. Describe a festival or celebration that people in your country enjoy. What happens during it? Why is it popular? Would you advise visitors to go? The best articles will be published next month.",
    [
      "You have received this email from your English-speaking friend, Chris.",
      "I'm thinking of spending my summer holidays working in a different country to improve my languages. You've done something similar, haven't you? What was it like? What should I do to prepare? And what is the best way to find a job? Write soon, Chris",
    ],
    "Reviews wanted: museums and exhibitions. Have you visited a museum or exhibition that you found interesting? Tell us what you saw there, what you liked and didn't like about the visit, and whether you would recommend it to other students.",
  ),
  w2(
    5,
    "Choose your task: hobby, study tips, TV series",
    "Articles wanted! A hobby everyone should try. Tell us about a hobby that you think more people should take up. What does it involve? What are the benefits? Is it easy to start? The best articles will be published next month.",
    [
      "You have received this email from your English-speaking friend, Maya.",
      "I've just started at a new school and I'm finding it hard to organise my study time. You always seem so well organised! What advice can you give me? How do you stay focused? And how do you find time to relax? Write soon, Maya",
    ],
    "Reviews wanted: TV series. Have you watched a TV series that you really liked or disliked? Tell us what it is about, what you thought of the story and the actors, and whether you would recommend it to other students.",
  ),
];

const s1 = (test: number, title: string, questions: string[]): SpeakingTask => ({
  kind: "speaking",
  slug: `speaking-part-1-t${test}`,
  test,
  skill: "speaking",
  paper: "Speaking",
  part: "Part 1",
  type: "Interview",
  title,
  summary: "Короткие ответы на вопросы о себе, с записью голоса",
  instruction:
    "Экзаменатор задаёт вопросы о вас. Отвечайте по 20–30 секунд: развёрнуто, с примером или причиной. Ответы записываются, чтобы вы могли их прослушать.",
  minutes: 4,
  stages: questions.map((text) => ({ text, seconds: 30 })),
  tips: [
    [
      "Начинайте ответ сразу, без долгих пауз: I'd say…, To be honest…",
      "Давайте причину: because…, the reason is that…",
      "Говорите о прошлом, настоящем и будущем — так видно владение временами.",
      "Не заучивайте ответы наизусть: экзаменатор слышит это сразу.",
    ],
    [
      "Мнение + причина + пример — три предложения вместо одного.",
      "Используйте связки: Also, Besides that, What's more…",
      "Если не поняли вопрос, вежливо переспросите: Sorry, could you repeat that?",
      "Улыбайтесь и говорите естественно — это не допрос, а разговор.",
    ],
    [
      "Отвечайте на заданный вопрос, а не на похожий, который вы хорошо знаете.",
      "Добавляйте детали: кто, где, когда, с кем.",
      "Используйте разнообразную лексику: вместо good — great, enjoyable, useful.",
      "Забыли слово? Опишите его: It's a thing that you use to…",
    ],
    [
      "Следите за временем: 20–30 секунд — это 3–4 предложения.",
      "Приводите личный пример: Last summer I…, For instance, my brother…",
      "Выражайте предпочтения: I'd rather…, I'm keen on…, I can't stand…",
      "Говорите чётко и не слишком быстро; после записи прослушайте себя.",
    ],
  ][test - 2],
});

export const speakingPart1Tests: SpeakingTask[] = [
  s1(2, "Daily life and routines", [
    "Can you tell us a little about your typical day?",
    "Do you prefer studying in the morning or in the evening? Why?",
    "What do you enjoy doing at the weekend?",
    "Tell us about a meal you like to cook or eat with your family.",
    "How do you usually get to school or work?",
    "What is your favourite season of the year, and why?",
  ]),
  s1(3, "Travel and holidays", [
    "Where did you spend your last holiday?",
    "Do you prefer holidays by the sea or in the mountains? Why?",
    "Tell us about a place in your country that you would recommend to visitors.",
    "What do you usually take with you when you travel?",
    "Would you like to live in another country one day? Why or why not?",
    "Do you like travelling with your family or with friends?",
  ]),
  s1(4, "Technology and entertainment", [
    "How often do you use the internet, and what do you use it for?",
    "What kind of films or TV series do you enjoy watching?",
    "Tell us about a piece of technology that you couldn't live without.",
    "Do you prefer reading books or watching videos? Why?",
    "What music do you like listening to?",
    "How do you stay in touch with friends who live far away?",
  ]),
  s1(5, "Health, sport and friends", [
    "Do you do any sport or physical activity? Tell us about it.",
    "What do you do to stay healthy?",
    "Tell us about your best friend. How did you meet?",
    "What did you do last weekend?",
    "Do you enjoy shopping? What do you like to buy?",
    "What would you like to be doing five years from now?",
  ]),
];

const s3 = (
  test: number,
  title: string,
  intro: string,
  center: string,
  prompts: string[],
  decision: string,
  part4: string[],
): SpeakingTask => ({
  kind: "speaking",
  slug: `speaking-part-3-t${test}`,
  test,
  skill: "speaking",
  paper: "Speaking",
  part: "Part 3–4",
  type: "Collaborative task + Discussion",
  title,
  summary: "Обсуждение по схеме и вопросы для дискуссии",
  instruction:
    "На экзамене Part 3 проходит в паре. Здесь вы тренируетесь в одиночку: рассуждайте вслух о каждом пункте схемы, затем примите решение и ответьте на вопросы Part 4.",
  minutes: 8,
  stages: [
    { label: "Part 3", text: intro, seconds: 120, mindmap: { center, prompts } },
    { label: "Part 3", text: decision, seconds: 60, mindmap: { center, prompts } },
    ...part4.map((text) => ({ label: "Part 4", text, seconds: 40 })),
  ],
  tips: [
    [
      "В Part 3 не торопитесь с выбором: обсудите минимум три пункта.",
      "Выражайте мнение и сравнивайте: I think… is more useful than…",
      "Приглашайте партнёра к диалогу: How about you? Would you agree?",
      "В Part 4 давайте развёрнутый ответ с причиной и примером.",
    ],
    [
      "Говорите обо всех пунктах схемы, но не обязательно в порядке списка.",
      "Соглашайтесь и спорьте вежливо: That's a good point, but…",
      "Используйте уступки: Although…, Even though…, Having said that…",
      "В Part 4 не бойтесь высказать неожиданное мнение — главное, обосновать его.",
    ],
    [
      "Начните с короткой реакции на пункт, потом объясните, почему он важен.",
      "Если партнёр молчит, задайте вопрос: What's your opinion on this one?",
      "Для решения используйте: So, shall we say that…? Let's go for…",
      "В Part 4 говорите в общем: Many people think…, In my experience…",
    ],
    [
      "Не просто перечисляйте, а объясняйте: This matters because…",
      "Пользуйтесь гипотезами: If people did this, they would…",
      "Завершая Part 3, чётко назовите выбор и одну причину.",
      "В Part 4 при затруднении скажите: That's a difficult question, but I'd say…",
    ],
  ][test - 2],
});

export const speakingPart3Tests: SpeakingTask[] = [
  s3(
    2,
    "Looking after the environment",
    "Here are some things that people can do to protect the environment. Talk about how effective each of these is.",
    "How can people protect the environment?",
    ["recycling rubbish", "cycling instead of driving", "saving energy at home", "planting trees", "buying fewer things"],
    "Now decide which one would make the biggest difference to your town.",
    [
      "Do you think individuals or governments can do more to protect the environment?",
      "Why do some people not care about the environment?",
      "Should companies be punished if they damage nature?",
      "What can schools do to teach young people about environmental problems?",
    ],
  ),
  s3(
    3,
    "What makes a job satisfying?",
    "Here are some things that people might look for in a job. Talk about how important each of these is.",
    "What makes a job satisfying?",
    ["a high salary", "friendly colleagues", "flexible working hours", "chances to travel", "helping other people"],
    "Now decide which one is the most important for people of your age.",
    [
      "Is it a good idea to stay in the same job for many years?",
      "Do you think people work too much nowadays?",
      "Is it better to work for a big company or to start your own business?",
      "How will jobs change in the next twenty years?",
    ],
  ),
  s3(
    4,
    "Ways of learning",
    "Here are some different ways in which people can learn new things. Talk about how useful each of these is.",
    "How can people learn new things?",
    ["school trips", "online courses", "reading books", "learning from friends", "work experience"],
    "Now decide which way is the most useful for teenagers.",
    [
      "Do you think students learn better in small groups or alone?",
      "Is it important to learn skills that are not taught at school?",
      "How has the internet changed the way we learn?",
      "Should adults continue learning new things throughout their lives?",
    ],
  ),
  s3(
    5,
    "Staying healthy in free time",
    "Here are some ways in which people can spend their free time in a healthy way. Talk about how good each of these is.",
    "How can people spend their free time in a healthy way?",
    ["playing team sports", "cooking at home", "spending time in nature", "getting enough sleep", "meeting friends"],
    "Now decide which one would be best for people who are very busy.",
    [
      "Why do some people find it hard to exercise regularly?",
      "Do you think young people today are less healthy than their parents were?",
      "Should schools give students more time for sport?",
      "How important is it to have free time in a busy life?",
    ],
  ),
];
