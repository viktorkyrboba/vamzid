import type { QuizTask } from "../types";

const opts = (names: string[]) => names.map((n, i) => `${"ABCD"[i]} · ${n}`);

const T2_OPTIONS = opts(["Marta", "Kenji", "Sophie", "Omar"]);
const T3_OPTIONS = opts(["Hannah", "Luca", "Grace", "Raj"]);
const T4_OPTIONS = opts(["Clara", "Ben", "Nadia", "Yusuf"]);
const T5_OPTIONS = opts(["Freya", "Dmitri", "Aisha", "Jack"]);

const common = {
  kind: "quiz" as const,
  skill: "rue" as const,
  paper: "Reading & Use of English",
  part: "Part 7",
  type: "Multiple matching",
  minutes: 15,
  layout: "passage" as const,
};

export const readingPart7Tests: QuizTask[] = [
  {
    ...common,
    slug: "reading-part-7-t2",
    test: 2,
    title: "Travelling alone",
    summary: "Поиск конкретной информации в нескольких текстах",
    instruction: "Четыре человека рассказывают о поездке в одиночку. Для каждого вопроса выберите человека (A–D). Людей можно выбирать несколько раз.",
    sections: [
      {
        label: "A",
        title: "Marta",
        text: "I booked a month-long trip to Chile after a difficult year at work, mostly because everyone told me not to go alone. The first week was miserable, and I came close to changing my ticket and flying home. Then I joined a group of walkers on a mountain trail and realised how quickly a shared challenge turns strangers into a team. I'd planned every day in advance, yet the best moments were unplanned: when my bus broke down, a farmer invited me to lunch with his family. I wrote a journal every evening and have since turned it into a blog, which has a surprising number of regular readers. Next year I'm hoping to try the same thing in Japan.",
      },
      {
        label: "B",
        title: "Kenji",
        text: "I spent six weeks cycling through Eastern Europe on a very tight budget, sleeping in a tent most nights. People assume that travelling alone means being lonely, but I found the opposite: it was almost too easy to chat to strangers, and I was invited to two village weddings. The real difficulty was the weather. A week of rain in Romania left me soaked and fed up. In the second week I lost my phone, and to my surprise I didn't miss it at all; I read more books than I had in the previous five years. Even so, I'm not sure I'd go alone again. The next journey I'd like to share with a friend who is as keen on cycling as I am.",
      },
      {
        label: "C",
        title: "Sophie",
        text: "Last spring I spent ten days in Portugal on my own, my first holiday without my family in thirty years. I was anxious about eating by myself in restaurants, and for the first couple of evenings I felt everyone was looking at me, but a friendly waiter gave me a seat at the counter and I soon realised nobody cared. I'm quite a careful person, so I'd read about every museum before leaving, yet I enjoyed simply wandering with no destination. The trip cost much less than I'd budgeted, because I was paying for one person's meals and one room. My daughters were worried, so I sent them a photo every evening, which they seemed to enjoy more than I did.",
      },
      {
        label: "D",
        title: "Omar",
        text: "I was nineteen when I took a year out to work my way around Australia. I took jobs in a fruit-packing plant and a surf shop, which covered my accommodation, so I barely touched my savings. My parents were very supportive, but I was sure I'd made a mistake when I arrived in Sydney knowing nobody and sleeping in a hostel room with eleven strangers. Within a fortnight I'd met people from all over the world, and I'm still in regular contact with several of them. Those conversations in so many different languages are the reason I'm now studying linguistics at university. Without that year, I'd probably have chosen a business degree like my brother, and I'd have been bored within a term.",
      },
    ],
    items: [
      { kind: "choice", n: 1, prompt: "Which person was self-conscious about dining alone at first?", options: T2_OPTIONS, answer: 2, explanation: "Sophie тревожилась из-за еды в одиночку и первые вечера думала, что все смотрят на неё («I felt everyone was looking at me»)." },
      { kind: "choice", n: 2, prompt: "Which person almost abandoned the trip early?", options: T2_OPTIONS, answer: 0, explanation: "Marta: «I came close to changing my ticket and flying home». Омар тоже сомневался, но домой не собирался." },
      { kind: "choice", n: 3, prompt: "Which person paid for the trip by taking temporary jobs?", options: T2_OPTIONS, answer: 3, explanation: "Omar работал на упаковке фруктов и в магазине сёрфинга, и это покрывало жильё." },
      { kind: "choice", n: 4, prompt: "Which person found that doing without a gadget was a benefit?", options: T2_OPTIONS, answer: 1, explanation: "Kenji потерял телефон, не скучал по нему и прочитал больше книг, чем за пять лет." },
      { kind: "choice", n: 5, prompt: "Which person found the holiday cheaper than expected?", options: T2_OPTIONS, answer: 2, explanation: "Sophie: «cost much less than I'd budgeted». Omar тоже почти не тратил сбережения, но не говорит о сравнении с ожиданиями." },
      { kind: "choice", n: 6, prompt: "Which person is still in touch with people met during the trip?", options: T2_OPTIONS, answer: 3, explanation: "Omar: «I'm still in regular contact with several of them»." },
      { kind: "choice", n: 7, prompt: "Which person has written about the experience for an audience?", options: T2_OPTIONS, answer: 0, explanation: "Marta превратила дневник в блог с большим числом постоянных читателей." },
      { kind: "choice", n: 8, prompt: "Which person would prefer to have company on the next trip?", options: T2_OPTIONS, answer: 1, explanation: "Kenji: следующую поездку он хотел бы разделить с другом. Marta, наоборот, планирует снова ехать." },
      { kind: "choice", n: 9, prompt: "Which person contacted relatives regularly to calm their worries?", options: T2_OPTIONS, answer: 2, explanation: "Sophie каждый вечер отправляла дочерям фото, потому что те беспокоились." },
      { kind: "choice", n: 10, prompt: "Which person chose what to study because of the trip?", options: T2_OPTIONS, answer: 3, explanation: "Omar изучает лингвистику из-за разговоров на разных языках во время поездки." },
    ],
  },
  {
    ...common,
    slug: "reading-part-7-t3",
    test: 3,
    title: "Learning a musical instrument",
    summary: "Поиск конкретной информации в нескольких текстах",
    instruction: "Четыре человека рассказывают о том, как они учились играть на музыкальном инструменте. Для каждого вопроса выберите человека (A–D). Людей можно выбирать несколько раз.",
    sections: [
      {
        label: "A",
        title: "Hannah",
        text: "I started the violin at eight and gave it up at fifteen, mainly because my teacher was so strict that I dreaded every lesson. For twenty-five years I didn't touch an instrument. Then, last year, a colleague mentioned a community orchestra that welcomed returning players, and I borrowed a violin to see what would happen. My fingers remembered far more than I expected, though my tone was dreadful at first. We rehearse every Thursday evening in a church hall, and it has become the best part of my week. After a long day of meetings, nothing clears my head like twenty minutes of scales. I've even started having lessons again, this time with a teacher who is kind and patient, which makes all the difference.",
      },
      {
        label: "B",
        title: "Luca",
        text: "I've never had a single lesson. When I was fourteen I found an old guitar in my uncle's garage and learnt my first chords from online videos, practising in my bedroom until my fingers were sore. Friends laughed when I said I wanted to be a musician, but I didn't care. Because I can't read music, I've always had to rely on my ears, and I think that made me more creative: I now compose my own songs and have recorded a dozen of them on my laptop. A new guitar costs a fortune, so the one I play now is second-hand, bought from a shop that was closing down, and I've never regretted it. One day I'd like to play at a small festival, but for now I'm happy with an audience of two cats.",
      },
      {
        label: "C",
        title: "Grace",
        text: "When I retired at sixty-eight, my doctor suggested I find an activity that would keep my mind busy, and I chose the piano, something I'd always wanted to try. My teacher is barely twenty-five, which amused me at first, but she's wonderful at explaining things. I practise for half an hour every morning, although my fingers are stiffer than they used to be. The hardest part has been the end-of-term recital. I know the pieces perfectly well at home, yet when I sat down in front of forty people my hands were shaking so badly that I had to start again. Everybody clapped anyway. My grandchildren now ask me to play at family parties, which I wouldn't have dreamt of a year ago.",
      },
      {
        label: "D",
        title: "Raj",
        text: "I joined a school band at thirteen because the drummer had left and nobody else would take over. We played together for five years and were really quite good, but when we all went to different universities the band simply fell apart. I didn't stop, though. I'd had lessons at school, and these days I play in the orchestra pit of a local theatre, which pays enough to cover my rent alongside my other job. A decent drum kit is hugely expensive, so I save up for each new piece of equipment. The most important thing playing in a group has taught me is to listen, because if you only concentrate on your own part, everything sounds wrong.",
      },
    ],
    items: [
      { kind: "choice", n: 1, prompt: "Which person stopped playing as a teenager because of a demanding teacher?", options: T3_OPTIONS, answer: 0, explanation: "Hannah бросила скрипку в пятнадцать, потому что учительница была слишком строгой." },
      { kind: "choice", n: 2, prompt: "Which person learnt without ever having a teacher?", options: T3_OPTIONS, answer: 1, explanation: "Luca: «I've never had a single lesson»; он учился по видео. У Raj уроки в школе были." },
      { kind: "choice", n: 3, prompt: "Which person took up an instrument on medical advice?", options: T3_OPTIONS, answer: 2, explanation: "Grace выбрала пианино, потому что врач посоветовал занятие для ума." },
      { kind: "choice", n: 4, prompt: "Which person's group ended when its members moved away?", options: T3_OPTIONS, answer: 3, explanation: "Raj: группа распалась, когда все уехали в разные университеты." },
      { kind: "choice", n: 5, prompt: "Which person says playing helps them relax after work?", options: T3_OPTIONS, answer: 0, explanation: "Hannah: после долгого дня «nothing clears my head like twenty minutes of scales»." },
      { kind: "choice", n: 6, prompt: "Which person earns money from performing?", options: T3_OPTIONS, answer: 3, explanation: "Raj играет в оркестровой яме театра, и этого хватает на аренду." },
      { kind: "choice", n: 7, prompt: "Which person is creating original music?", options: T3_OPTIONS, answer: 1, explanation: "Luca сочиняет собственные песни и записал дюжину." },
      { kind: "choice", n: 8, prompt: "Which person felt anxious when performing in public?", options: T3_OPTIONS, answer: 2, explanation: "Grace: на концерте у неё так тряслись руки, что пришлось начать заново." },
      { kind: "choice", n: 9, prompt: "Which person bought an instrument that someone else had owned before?", options: T3_OPTIONS, answer: 1, explanation: "У Luca гитара «second-hand». Hannah лишь одолжила скрипку, а Raj копит на дорогие новые вещи." },
      { kind: "choice", n: 10, prompt: "Which person is taught by someone much younger?", options: T3_OPTIONS, answer: 2, explanation: "Учительнице Grace «barely twenty-five»." },
    ],
  },
  {
    ...common,
    slug: "reading-part-7-t4",
    test: 4,
    title: "Working from home",
    summary: "Поиск конкретной информации в нескольких текстах",
    instruction: "Четыре человека рассказывают о работе из дома. Для каждого вопроса выберите человека (A–D). Людей можно выбирать несколько раз.",
    sections: [
      {
        label: "A",
        title: "Clara",
        text: "I've been a freelance illustrator for six years, and working from home suited me from the start, though I had to learn a few lessons. In the early months I kept noticing dirty plates and piles of washing, and an hour that should have been spent drawing would simply disappear. So I had a small studio built at the bottom of the garden, and now when I close its door at six I really do feel I've left work behind. Another benefit is financial: I no longer spend a fortune on train tickets and sandwiches in the city. I'm most creative in the morning, so I start at seven and finish early. The only real downside is that my cat insists on sitting on the keyboard.",
      },
      {
        label: "B",
        title: "Ben",
        text: "As an accountant, I'd always assumed that working from home would be ideal, but the reality surprised me. In the office I'd had lunch with the same group of colleagues for years, and I hadn't realised how much I depended on their jokes and gossip until the chats stopped. At home, the silence was oppressive. The other problem was that my working day never seemed to end. With my laptop on the kitchen table, it was far too easy to answer one more email at ten at night, and I was regularly putting in more hours than before. Now I rent a desk in a shared office two days a week, and that has helped me enormously.",
      },
      {
        label: "C",
        title: "Nadia",
        text: "I develop software for a medical company, and when my twins were born my manager offered me the chance to work from home. The flexibility has been wonderful: I do the school run in the morning, start work at nine and make up the time in the evening once the children are asleep. It isn't always easy, because a toddler on your lap during a video call isn't ideal, but my colleagues have been very understanding. What surprised me was that my manager told me last month that my team's output has risen since I moved home, so I'm now being asked to lead a new project. The company even paid for a proper chair and a second screen.",
      },
      {
        label: "D",
        title: "Yusuf",
        text: "I manage a team of twelve engineers, all of whom now work remotely. At first I found that very hard, because I was used to seeing at a glance who was busy. I've had to learn to trust people and judge them by results rather than by how many hours they spend at their desks, and our daily fifteen-minute video call has replaced the corridor chats. Last year we moved to a village in the hills, which had always been my dream, and I couldn't have done that if I'd stayed in an office. The one real drawback is the broadband, which drops out every time it rains, so I sometimes have to drive into town to attend important meetings.",
      },
    ],
    items: [
      { kind: "choice", n: 1, prompt: "Which person built a dedicated workplace on their own property?", options: T4_OPTIONS, answer: 0, explanation: "Clara построила студию в конце сада. Ben арендует стол в общем офисе, то есть не у себя дома." },
      { kind: "choice", n: 2, prompt: "Which person is now working longer hours than before?", options: T4_OPTIONS, answer: 1, explanation: "Ben: «regularly putting in more hours than before». Nadia переносит часы на вечер, но общее время не растёт." },
      { kind: "choice", n: 3, prompt: "Which person has sometimes had problems with an internet connection?", options: T4_OPTIONS, answer: 3, explanation: "У Yusuf пропадает интернет в дождь." },
      { kind: "choice", n: 4, prompt: "Which person arranges their work around childcare?", options: T4_OPTIONS, answer: 2, explanation: "Nadia отвозит детей в школу и доделывает работу вечером, когда они спят." },
      { kind: "choice", n: 5, prompt: "Which person missed casual conversations with co-workers?", options: T4_OPTIONS, answer: 1, explanation: "Ben не осознавал, как зависел от шуток и сплетен коллег, пока общение не прекратилось." },
      { kind: "choice", n: 6, prompt: "Which person had to change their way of supervising other people?", options: T4_OPTIONS, answer: 3, explanation: "Yusuf научился доверять сотрудникам и оценивать по результатам, а не по часам за столом." },
      { kind: "choice", n: 7, prompt: "Which person now spends less money on getting to work?", options: T4_OPTIONS, answer: 0, explanation: "Clara больше не тратится на билеты на поезд и обеды в городе." },
      { kind: "choice", n: 8, prompt: "Which person has been told that their productivity has improved?", options: T4_OPTIONS, answer: 2, explanation: "Менеджер Nadia сказал, что результаты её команды выросли." },
      { kind: "choice", n: 9, prompt: "Which person was able to move to the countryside thanks to the job?", options: T4_OPTIONS, answer: 3, explanation: "Yusuf переехал в деревню в холмах и не смог бы этого сделать, работая в офисе." },
      { kind: "choice", n: 10, prompt: "Which person was distracted by household tasks at first?", options: T4_OPTIONS, answer: 0, explanation: "Clara: сначала часы уходили на грязную посуду и стирку." },
    ],
  },
  {
    ...common,
    slug: "reading-part-7-t5",
    test: 5,
    title: "Volunteering with wildlife",
    summary: "Поиск конкретной информации в нескольких текстах",
    instruction: "Четыре человека рассказывают о волонтёрской работе с дикими животными. Для каждого вопроса выберите человека (A–D). Людей можно выбирать несколько раз.",
    sections: [
      {
        label: "A",
        title: "Freya",
        text: "I spent three weeks on a beach in Costa Rica helping to protect sea turtles. Every night, in teams of four, we walked the shoreline looking for females coming up to lay their eggs, and then we moved the nests to a safe enclosure. I was exhausted, because I rarely got more than four hours' sleep, and I had to pay a fee of nearly a thousand pounds towards the accommodation. But the moment when a hundred tiny hatchlings made their way down to the sea was beyond anything I'd imagined. I'd been wavering over what to study at university, and I came home certain I wanted to do marine biology. I've just started my first term.",
      },
      {
        label: "B",
        title: "Dmitri",
        text: "There's a hedgehog rescue centre near my home in Kent, and I volunteer there one weekend a month, which is all my job allows. The work is messy: cleaning cages, weighing the animals, feeding the youngest every three hours. But I love it. I learnt that many of the injuries come from garden machinery and slug pellets, so I've been talking to my neighbours about leaving a corner of their gardens wild, and several of them have actually done it. The hardest moment was when a hedgehog I'd looked after for a week died overnight. I hadn't expected to feel so upset about an animal I barely knew, and I didn't go back for a fortnight.",
      },
      {
        label: "C",
        title: "Aisha",
        text: "I went to an elephant sanctuary in northern Thailand for a fortnight. I'll admit I'd thought riding elephants was harmless fun, and I'd even been looking forward to it. It was only when I spoke to the staff that I understood how much the animals suffer. Our jobs were preparing food, cleaning the enclosures and walking the elephants to the river for their bath, and it was hard physical work in the heat. The trip turned out to be much more expensive than the website had suggested, because flights and extra fees were added, but I don't resent that. Since I got back I send a small amount to the sanctuary every month, which feels like the least I can do.",
      },
      {
        label: "D",
        title: "Jack",
        text: "For a month last summer I lived on a remote island off the Scottish coast, counting seabirds with two scientists. Our hut had no electricity and no hot water, and the nearest shop was a two-hour boat journey away, so we got used to simple food and cold washes. Most days began with climbing the cliffs at dawn to count puffins and record how many chicks had survived. I was told that our figures would be included in a national survey that helps experts understand how climate change is affecting the birds, which made even the wet and windy days seem worthwhile. I'd definitely go back, although next time I'd take warmer socks.",
      },
    ],
    items: [
      { kind: "choice", n: 1, prompt: "Which person got very little sleep during the project?", options: T5_OPTIONS, answer: 0, explanation: "Freya спала не больше четырёх часов в сутки из-за ночных обходов." },
      { kind: "choice", n: 2, prompt: "Which person discovered that an earlier belief of theirs was mistaken?", options: T5_OPTIONS, answer: 2, explanation: "Aisha считала катание на слонах безобидным, пока персонал не объяснил, как животные страдают." },
      { kind: "choice", n: 3, prompt: "Which person has persuaded other people to change what they do?", options: T5_OPTIONS, answer: 1, explanation: "Dmitri уговорил соседей оставить дикий уголок в саду, и несколько человек так и сделали." },
      { kind: "choice", n: 4, prompt: "Which person lived without basic modern comforts?", options: T5_OPTIONS, answer: 3, explanation: "У Jack в хижине не было электричества и горячей воды." },
      { kind: "choice", n: 5, prompt: "Which person gathered information that experts will use?", options: T5_OPTIONS, answer: 3, explanation: "Данные Jack войдут в национальное исследование о влиянии климата на птиц." },
      { kind: "choice", n: 6, prompt: "Which person's choice of degree was influenced by the experience?", options: T5_OPTIONS, answer: 0, explanation: "Freya вернулась уверенной, что хочет изучать морскую биологию." },
      { kind: "choice", n: 7, prompt: "Which person was upset when an animal died?", options: T5_OPTIONS, answer: 1, explanation: "Dmitri тяжело переживал смерть ежа, за которым ухаживал неделю." },
      { kind: "choice", n: 8, prompt: "Which person found the trip costlier than they had been led to expect?", options: T5_OPTIONS, answer: 2, explanation: "Aisha: поездка вышла намного дороже, чем обещал сайт. Freya платила взнос, но не говорит о сюрпризе." },
      { kind: "choice", n: 9, prompt: "Which person can only help occasionally because of work commitments?", options: T5_OPTIONS, answer: 1, explanation: "Dmitri волонтёрит раз в месяц на выходных, «which is all my job allows»." },
      { kind: "choice", n: 10, prompt: "Which person now gives regular financial support to the organisation?", options: T5_OPTIONS, answer: 2, explanation: "Aisha каждый месяц отправляет небольшую сумму в приют." },
    ],
  },
];
