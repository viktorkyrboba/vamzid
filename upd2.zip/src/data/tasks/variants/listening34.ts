import type { QuizTask } from "../types";

const P3_BASE = {
  kind: "quiz" as const,
  skill: "listening" as const,
  paper: "Listening",
  part: "Part 3",
  type: "Multiple matching",
  minutes: 8,
  layout: "listening" as const,
};

const P4_BASE = {
  kind: "quiz" as const,
  skill: "listening" as const,
  paper: "Listening",
  part: "Part 4",
  type: "Interview",
  minutes: 10,
  layout: "listening" as const,
};

const P3_T2_OPTIONS = [
  "I realised that I prefer working in a team.",
  "I learnt that making mistakes is not a disaster.",
  "I found out what kind of work I did not want to do.",
  "I understood how important it is to ask for help.",
  "I became better at organising my time.",
  "I discovered that my skills could be used in other areas.",
  "I realised I should have chosen a different university course.",
  "I learnt to accept criticism.",
];

const P3_T3_OPTIONS = [
  "I was surprised how much I enjoyed competing.",
  "I realised that progress takes longer than I expected.",
  "I made friends I would not have met otherwise.",
  "I felt healthier and fitter than before.",
  "I found a way to relax after stressful days.",
  "I discovered I was braver than I thought.",
  "I spent more money than I had planned.",
  "I wish I had started when I was younger.",
];

const P3_T4_OPTIONS = [
  "I had underestimated how expensive it would be.",
  "I missed the countryside I grew up in.",
  "I found the local people very welcoming.",
  "I was surprised how long it took to feel at home.",
  "I became more independent.",
  "I enjoyed having so many things to do.",
  "I found it hard to get used to the noise.",
  "I decided to move back after a short time.",
];

const P3_T5_OPTIONS = [
  "I gained skills that helped me to find a job.",
  "I realised how much I had taken for granted.",
  "I was disappointed by how the organisation was run.",
  "I made a friend for life.",
  "I found the work harder than I had expected.",
  "I discovered an interest I did not know I had.",
  "I was embarrassed by my lack of experience.",
  "I felt that my contribution made a real difference.",
];

export const listeningPart3Tests: QuizTask[] = [
  {
    ...P3_BASE,
    slug: "listening-part-3-t2",
    test: 2,
    title: "My first job",
    summary: "Пять говорящих: чему их научила первая работа",
    instruction: "Пять человек рассказывают, чему их научила первая работа. Выберите из списка A–H, что говорит каждый. Три варианта лишние.",
    script: `Speaker one.

F: My first job was in a busy online shop, packing orders. At university I'd always finished my essays the night before, but there you simply can't do that, because the lorry arrives at four o'clock whatever happens. So I started dividing my day into blocks and sticking to a timetable. My manager was quite strict, but I never minded that. I still use the same system today.

Speaker two.

M: I took a job at a bank because my parents thought it was a sensible choice. The salary was good and my colleagues were friendly, so I can't complain about that. But after six months I knew for certain that sitting at a desk all day was not for me. It sounds negative, but it was actually very useful, because it made the next decision so much easier. I'm training to be a carpenter now.

Speaker three.

F: In my first week in a restaurant kitchen, I was too proud to admit I didn't know how to use the big mixing machine. I wasted a huge amount of food before the chef found out, and he was furious. What he said stayed with me, though: nobody expects you to know everything on the first day. Now, whenever I'm not sure about something, I just ask. It saves everybody a lot of time.

Speaker four.

M: I'm a maths student, and I took a job at a holiday camp because I needed the money. I expected my degree to be completely useless there. But when I started organising puzzle games for the children, I was surprised how well logical thinking worked in that situation too. I made some good friends there, but what really stayed with me was that surprise. I'm even thinking about becoming a teacher now.

Speaker five.

F: On my very first day in a café, I dropped a tray of drinks in front of about thirty customers. I was sure I'd be sent home. My manager just laughed and handed me a cloth. Over the next months I made far worse mistakes, but the café never closed and nobody died. These days I find it much easier to try new things without worrying so much about getting them wrong.`,
    items: [
      { kind: "choice", n: 1, prompt: "Speaker 1", options: P3_T2_OPTIONS, answer: 4, explanation: "Раньше она делала всё в последний момент, а теперь «dividing my day into blocks and sticking to a timetable». Строгий начальник — отвлекающая деталь, критика не обсуждается." },
      { kind: "choice", n: 2, prompt: "Speaker 2", options: P3_T2_OPTIONS, answer: 2, explanation: "Через полгода он понял, что работа за столом не для него: «it made the next decision so much easier». Хорошая зарплата и коллеги — не главное." },
      { kind: "choice", n: 3, prompt: "Speaker 3", options: P3_T2_OPTIONS, answer: 3, explanation: "«Whenever I'm not sure about something, I just ask». Недовольство шефа упомянуто, но урок не в критике, а в том, чтобы спрашивать." },
      { kind: "choice", n: 4, prompt: "Speaker 4", options: P3_T2_OPTIONS, answer: 5, explanation: "Он удивился, что логическое мышление пригодилось и в лагере: «logical thinking worked in that situation too». Друзья там — второстепенная деталь, не про командную работу." },
      { kind: "choice", n: 5, prompt: "Speaker 5", options: P3_T2_OPTIONS, answer: 1, explanation: "После уроненного подноса и худших ошибок «the café never closed»: теперь легче пробовать новое, не боясь ошибиться." },
    ],
  },
  {
    ...P3_BASE,
    slug: "listening-part-3-t3",
    test: 3,
    title: "Taking up a new hobby",
    summary: "Пять говорящих: что дало им новое увлечение во взрослом возрасте",
    instruction: "Пять человек рассказывают о том, что дало им новое увлечение, которым они занялись во взрослом возрасте. Выберите из списка A–H, что говорит каждый. Три варианта лишние.",
    script: `Speaker one.

F: I thought climbing would be a cheap hobby, because, after all, it's only a wall and your own two hands. Then I needed special shoes, a harness, a rope, a monthly fee for the climbing centre, and now I'm travelling to the mountains every other weekend. Everybody at the centre is very friendly, but I mostly keep to myself. I honestly don't regret it, but my bank account certainly feels it.

Speaker two.

M: I work in an office where my head is full of emails and meetings all day. Two evenings a week I go to a pottery class, and while my hands are in the clay, I simply cannot think about work. Two hours disappear and I walk home feeling completely calm. I'm not very good, mind you. My bowls come out rather crooked, but that doesn't bother me at all.

Speaker three.

F: I started learning the piano at forty. My teacher says I'm doing well, and I really do enjoy it. But when I watch ten-year-olds playing pieces I still struggle with, I can't help thinking about how far I'd be by now if my parents had sent me to lessons when I was their age. It's a silly thought, I know, but it comes back every time.

Speaker four.

M: I'd always been afraid of deep water. A colleague talked me into trying open-water swimming in the sea, and the first time I nearly turned back at the shore. But I didn't, and when I got out I felt like I'd won a prize. Since then I've said yes to things I'd have refused before, like giving a presentation to the whole company. To be honest, I'm not any fitter than I was.

Speaker five.

M: I started running thinking that in a month I'd be able to do ten kilometres. Two months later I could barely do three without stopping, and I nearly gave up. Then my coach explained that real improvement takes years, not weeks. Now I'm much more patient with myself. My club keeps encouraging me to enter races, but I'm not interested in that.`,
    items: [
      { kind: "choice", n: 1, prompt: "Speaker 1", options: P3_T3_OPTIONS, answer: 6, explanation: "Обувь, страховка, абонемент, поездки: «my bank account certainly feels it». Дружелюбные люди есть, но она держится особняком — вариант C не подходит." },
      { kind: "choice", n: 2, prompt: "Speaker 2", options: P3_T3_OPTIONS, answer: 4, explanation: "На занятиях по гончарному делу он не может думать о работе и уходит домой спокойным. То, что миски кривые, его не волнует." },
      { kind: "choice", n: 3, prompt: "Speaker 3", options: P3_T3_OPTIONS, answer: 7, explanation: "Она думает, как далеко продвинулась бы, если бы родители отдали её на уроки в детстве: «if my parents had sent me to lessons»." },
      { kind: "choice", n: 4, prompt: "Speaker 4", options: P3_T3_OPTIONS, answer: 5, explanation: "Он боялся глубокой воды, но заплыл, и теперь соглашается на то, от чего раньше отказывался. Вариант D не подходит: «I'm not any fitter»." },
      { kind: "choice", n: 5, prompt: "Speaker 5", options: P3_T3_OPTIONS, answer: 1, explanation: "Ожидал результата за месяц, а тренер объяснил, что прогресс занимает годы. Участие в забегах его не интересует, поэтому вариант A не подходит." },
    ],
  },
  {
    ...P3_BASE,
    slug: "listening-part-3-t4",
    test: 4,
    title: "Moving to a big city",
    summary: "Пять говорящих: что они поняли, переехав в большой город",
    instruction: "Пять человек рассказывают о своём переезде в большой город. Выберите из списка A–H, что говорит каждый. Три варианта лишние.",
    script: `Speaker one.

M: I grew up in a tiny village where the loudest thing at night was an owl. My first night in the city, I couldn't sleep at all: sirens, traffic, people shouting in the street, a neighbour's television through the wall. I bought earplugs, but even now, after two years, I still wake up at three in the morning sometimes. The rent is high, but my salary covers it, so I can't complain about that.

Speaker two.

F: Where I come from, we have a beach and I used to swim every single morning before school. Here it's all concrete and glass. My job is fine, and I've got a decent flat. But on some weekends I take a train for two hours just to stand by the sea for a while. I think I'll always miss that part of my old life.

Speaker three.

M: Everybody told me I'd feel at home within a few weeks. I didn't. For months, I got lost on the metro, I didn't know which shops were good, and I felt like a tourist in my own street. It was only in the second year, when the café owner started asking if I wanted my usual, that I thought: okay, maybe I live here now.

Speaker four.

F: I expected people in a big city to be cold and in a hurry. But on my second day, a neighbour brought me a cake, and the man in the corner shop remembered my name after one visit. Flats are pricey, of course, but I knew that before I came. I've been very lucky with the people I've met.

Speaker five.

F: At home, my parents did everything: cooking, paying bills, even booking my dentist appointments. Here I had to learn it all, and the first month was a disaster. I once watched five videos to fix a leaking tap. My mother keeps asking when I'm coming back, but I'm not planning to. I'm quite proud of how much I can handle on my own now.`,
    items: [
      { kind: "choice", n: 1, prompt: "Speaker 1", options: P3_T4_OPTIONS, answer: 6, explanation: "Сирены, транспорт, шум за стеной: он до сих пор просыпается по ночам. Аренда высокая, но зарплаты хватает, поэтому вариант A не подходит." },
      { kind: "choice", n: 2, prompt: "Speaker 2", options: P3_T4_OPTIONS, answer: 1, explanation: "Она скучает по морю и ездит к нему на выходных. Работа и квартира её устраивают." },
      { kind: "choice", n: 3, prompt: "Speaker 3", options: P3_T4_OPTIONS, answer: 3, explanation: "Ему говорили, что он освоится за несколько недель, но это случилось только на второй год." },
      { kind: "choice", n: 4, prompt: "Speaker 4", options: P3_T4_OPTIONS, answer: 2, explanation: "Соседка принесла пирог, продавец запомнил имя: «I've been very lucky with the people I've met». О дорогом жилье она знала заранее, значит, вариант A не подходит." },
      { kind: "choice", n: 5, prompt: "Speaker 5", options: P3_T4_OPTIONS, answer: 4, explanation: "Ей пришлось самой научиться всему, и теперь она гордится, что справляется. Мама просит вернуться, но она не собирается — вариант H не подходит." },
    ],
  },
  {
    ...P3_BASE,
    slug: "listening-part-3-t5",
    test: 5,
    title: "Volunteering",
    summary: "Пять говорящих: что им дал опыт волонтёрства",
    instruction: "Пять человек рассказывают о своём опыте волонтёрства. Выберите из списка A–H, что говорит каждый. Три варианта лишние.",
    script: `Speaker one.

F: I'd always loved animals, so I volunteered at an animal shelter on Saturdays. They were short of people to run their social media, so I started writing posts and taking photos of the dogs. A year later, when I applied for a marketing job, those posts were the first thing I showed at the interview. I got the job, and I still use the same tricks I learnt there.

Speaker two.

M: I joined a group that was building houses abroad for two weeks. I'm reasonably fit, but nothing prepares you for carrying bricks for ten hours in the sun. On the second night I fell asleep at the dinner table with my fork in my hand. The organisers were very well prepared and everything ran smoothly, but I think I'd have trained for months if I'd known what to expect.

Speaker three.

F: I volunteered at a small museum, just helping to catalogue old documents. I thought it would be boring, to be honest. But one box contained letters from soldiers in my own town, and I couldn't stop reading them. I'm now taking evening classes in local history, which is something I would never have imagined a year ago.

Speaker four.

M: On my first day at the soup kitchen, I met another new volunteer called Anna. We were both nervous, and we ended up peeling potatoes together for four hours. That was ten years ago. She's now my best friend and the godmother of my daughter. I went there to help other people, and I never expected to gain something so important myself.

Speaker five.

F: I teach reading to refugee children twice a week. I'd never taught anyone anything before, and I was quite nervous at first. But last month, a boy I'd worked with for a year read a whole story aloud in front of his class. His teacher told me he'd never have done it without the extra lessons. That made all the early-morning journeys worthwhile.`,
    items: [
      { kind: "choice", n: 1, prompt: "Speaker 1", options: P3_T5_OPTIONS, answer: 0, explanation: "Посты для приюта показали на собеседовании, и она получила работу в маркетинге. Любовь к животным была и раньше — вариант F не подходит." },
      { kind: "choice", n: 2, prompt: "Speaker 2", options: P3_T5_OPTIONS, answer: 4, explanation: "Он уснул за ужином и хотел бы заранее знать, что ожидает: работа тяжелее, чем он думал. Организация была на высоте, поэтому вариант C не подходит." },
      { kind: "choice", n: 3, prompt: "Speaker 3", options: P3_T5_OPTIONS, answer: 5, explanation: "Письма солдат увлекли её, и теперь она учит местную историю — раньше она об этом даже не думала." },
      { kind: "choice", n: 4, prompt: "Speaker 4", options: P3_T5_OPTIONS, answer: 3, explanation: "Познакомился с Анной десять лет назад: «She's now my best friend and the godmother of my daughter»." },
      { kind: "choice", n: 5, prompt: "Speaker 5", options: P3_T5_OPTIONS, answer: 7, explanation: "Мальчик прочитал рассказ вслух, и учитель сказал, что без её уроков этого не было бы. Нервничала она только вначале, но не стыдилась — вариант G не подходит." },
    ],
  },
];

export const listeningPart4Tests: QuizTask[] = [
  {
    ...P4_BASE,
    slug: "listening-part-4-t2",
    test: 2,
    title: "Life beneath the waves",
    summary: "Интервью с морским биологом, 7 вопросов",
    instruction: "Вы услышите интервью с морским биологом, доктором Ханной Рейес. Для каждого вопроса выберите лучший ответ (A, B или C).",
    script: `M: Today my guest is Dr Hannah Reyes, a marine biologist who studies coral reefs. Hannah, what first drew you to the sea?

F: I grew up a long way from the coast, so there wasn't any family tradition. I did watch a lot of television programmes about reefs as a child, and I loved them. But what really changed things was a school trip to an aquarium, where a guide let me hold a starfish. I decided that very day that I wanted to work with sea creatures.

M: People imagine your work is dangerous. Is that the hardest part?

F: Not at all. We follow very strict safety rules, and diving is actually the part I find relaxing. What I find hardest is being away from home. Last year I spent five months on a research boat, and I missed my daughter's birthday. You can't get those days back.

M: You've been studying the same reefs for ten years. What have you noticed?

F: In some places, thanks to protection, reefs are starting to recover, which gives us real hope. But in the area where I work, the changes are happening faster than any of us predicted. Some corals I measured in my first year are simply gone.

M: Many tourists visit reefs. Should they be kept away?

F: I don't think so. It's badly managed tourism that causes the damage, not tourism itself. Banning visitors would also take income away from local communities, and then they'd have less reason to protect the reef. So I think we should regulate visits and teach visitors how to behave, rather than close everything.

M: You use underwater robots and drones now. Has technology changed your work?

F: It's a great help, and we can cover much larger areas. Of course, that equipment is expensive, and not every team can afford it. But nothing replaces the human eye. Last year a local fisherman told me about a patch of reef that none of our machines had noticed, and he was right.

M: You also give talks in schools. Do you enjoy that?

F: More than conferences, to be honest. Scientists nod politely, but children ask things like, "Does a fish ever get thirsty?" and suddenly I'm looking at my own subject as if for the first time.

M: And what are you working on next?

F: I'd love to write a book, but I simply don't have the time. Next year I'm leading a project to grow young corals in nurseries and then plant them on damaged reefs. It's a completely different challenge from just measuring what is lost, and I can't wait to start.`,
    items: [
      { kind: "choice", n: 1, prompt: "What made Hannah decide to work with sea creatures?", options: ["She watched a television programme about reefs.", "She went on a school visit to an aquarium.", "She spent her childhood holidays by the sea."], answer: 1, explanation: "Передачи ей нравились, но решение пришло после поездки в аквариум: «I decided that very day». Жила она далеко от моря." },
      { kind: "choice", n: 2, prompt: "What does Hannah find most difficult about her job?", options: ["the danger of deep diving", "the cost of the equipment", "being away from her family"], answer: 2, explanation: "Погружения она считает расслабляющими, а труднее всего — разлука с семьёй: «I missed my daughter's birthday»." },
      { kind: "choice", n: 3, prompt: "What does Hannah say about the reefs she studies?", options: ["They are changing faster than expected.", "They are recovering well.", "They are larger than people think."], answer: 0, explanation: "В её районе перемены идут быстрее, чем кто-либо предсказывал. Восстановление она упоминает лишь про другие места." },
      { kind: "choice", n: 4, prompt: "What is Hannah's opinion of tourism on reefs?", options: ["Tourists should be banned from visiting.", "Most tourists behave carelessly.", "Visits should be controlled, not stopped."], answer: 2, explanation: "Она против запрета: вред наносит плохо организованный туризм, поэтому нужно регулировать посещения и обучать туристов." },
      { kind: "choice", n: 5, prompt: "What does Hannah say about new technology?", options: ["It has made fieldwork unnecessary.", "It is useful but cannot replace human observation.", "It is too expensive for most scientists."], answer: 1, explanation: "«Nothing replaces the human eye»: рыбак заметил участок рифа, который не нашли машины. Цена упомянута лишь вскользь." },
      { kind: "choice", n: 6, prompt: "Why does Hannah enjoy talking to schoolchildren?", options: ["Their questions make her see her subject differently.", "She can explain her results more easily.", "She hopes to find future scientists."], answer: 0, explanation: "Детские вопросы заставляют взглянуть на предмет заново: «as if for the first time». Учёные на конференциях лишь вежливо кивают." },
      { kind: "choice", n: 7, prompt: "What is Hannah's next project?", options: ["writing a book about reefs", "leaving fieldwork to teach", "growing corals to replace lost ones"], answer: 2, explanation: "Книга — несбыточная мечта из-за нехватки времени, а проект на следующий год — выращивание кораллов и высадка на повреждённые рифы." },
    ],
  },
  {
    ...P4_BASE,
    slug: "listening-part-4-t3",
    test: 3,
    title: "Inside the kitchen",
    summary: "Интервью с шеф-поваром, 7 вопросов",
    instruction: "Вы услышите интервью с шеф-поваром Дэниелом Окафором. Для каждого вопроса выберите лучший ответ (A, B или C).",
    script: `F: Today I'm joined by Daniel Okafor, the chef and owner of a restaurant that has won several awards. Daniel, did you always want to be a chef?

M: Not really. My grandmother cooked wonderfully, but she never let me near the stove. I went to cookery school later, but honestly it taught me less than my first year as a dishwasher in a local restaurant at sixteen. I watched the chefs every night, and I was hooked.

F: What surprised you most when you opened your own restaurant?

M: How little of my day I spend cooking! I expected the long hours, but I hadn't realised I'd be dealing with suppliers, accounts, staff timetables and broken fridges. Some days I don't touch a pan until the evening.

F: How do you choose your ingredients?

M: Everything I use comes from farms within fifty miles of the restaurant, because freshness matters more to me than anything else. I'm not obsessed with organic food, as organic doesn't automatically mean tasty. And I don't go looking for exotic things just to impress people. A perfect local carrot is better.

F: Do bad reviews upset you?

M: Of course they do. My sous-chef tells me to ignore them, but I can't. I read every one, and then, once I've stopped feeling angry, I ask myself whether there's anything in it that's fair. Quite often there is, and I change something. I never reply online, though. That never helps.

F: Television chefs often shout at their staff. Is that how a real kitchen works?

M: Not in mine. I did shout when I was young and stressed, and I'm not proud of it. Frightened people make more mistakes, not fewer. A kitchen can be very busy without anyone raising their voice, and my team stays with me for years, which says something.

F: What do you cook when you're at home?

M: Very simple things. Pasta with garlic and oil, or eggs on toast. I used to cook elaborate dinners for friends, but they got so nervous about being judged that it spoiled the evening. And I do eat at the restaurant sometimes, but on my days off I want a break from it.

F: And what's next for you?

M: People keep asking if I'll open a second restaurant, but I wouldn't be able to give two places the attention they need. A publisher has asked me about a cookbook, but I'm not ready for that either. What I'd really like to do is set up a cooking school for teenagers who haven't had many opportunities. Someone gave me a chance once.`,
    items: [
      { kind: "choice", n: 1, prompt: "How did Daniel begin his career in cooking?", options: ["He learnt from his grandmother.", "He studied at cookery school.", "He worked in a restaurant as a teenager."], answer: 2, explanation: "Бабушка не пускала его к плите, а школа дала меньше, чем первый год мойщиком посуды в 16 лет." },
      { kind: "choice", n: 2, prompt: "What surprised Daniel about running a restaurant?", options: ["how little of his time is spent cooking", "how long the working days are", "how difficult it is to find customers"], answer: 0, explanation: "«How little of my day I spend cooking!» Длинные часы он как раз ожидал." },
      { kind: "choice", n: 3, prompt: "What is most important to Daniel when choosing ingredients?", options: ["They must be organic.", "They must be fresh and local.", "They must be unusual."], answer: 1, explanation: "Всё с ферм в пределах 50 миль, потому что свежесть важнее всего. Органические и экзотические продукты для него не главное." },
      { kind: "choice", n: 4, prompt: "How does Daniel react to bad reviews?", options: ["He ignores them.", "He considers whether they are fair.", "He replies to them online."], answer: 1, explanation: "Он читает каждый отзыв и, успокоившись, спрашивает себя, справедлив ли он. Игнорировать не может, онлайн не отвечает." },
      { kind: "choice", n: 5, prompt: "What does Daniel say about shouting in kitchens?", options: ["It is unnecessary and causes mistakes.", "It is normal when the kitchen is busy.", "It makes the team work faster."], answer: 0, explanation: "«Frightened people make more mistakes». Раньше он кричал, но этим не гордится." },
      { kind: "choice", n: 6, prompt: "What does Daniel cook at home?", options: ["elaborate meals for his friends", "nothing, because he eats at the restaurant", "simple dishes"], answer: 2, explanation: "Дома он готовит пасту или яичницу. Сложные ужины для друзей остались в прошлом, а в выходные ему нужен отдых от ресторана." },
      { kind: "choice", n: 7, prompt: "What would Daniel like to do next?", options: ["open another restaurant", "start a cooking school for young people", "write a cookbook"], answer: 1, explanation: "Второй ресторан и книгу он отклоняет, а хочет открыть кулинарную школу для подростков." },
    ],
  },
  {
    ...P4_BASE,
    slug: "listening-part-4-t4",
    test: 4,
    title: "Digging up the past",
    summary: "Интервью с археологом, 7 вопросов",
    instruction: "Вы услышите интервью с археологом, доктором Прией Наир. Для каждого вопроса выберите лучший ответ (A, B или C).",
    script: `M: My guest today is Dr Priya Nair, an archaeologist who has led excavations in three countries. Priya, why did you choose archaeology?

F: It started with a small coin. When I was eight, I found one in my grandparents' garden, and my grandfather took me to a museum to find out what it was. It was Roman, nearly two thousand years old. History lessons at school were rather dull, I have to say, but that coin made the past feel real.

M: Most people imagine archaeologists finding gold and jewels. Is that true?

F: Hardly ever. Most finds are broken pottery, animal bones and rubbish. But that's the exciting part, because ordinary objects tell us how people really lived: what they ate, what they threw away, what they repaired. A broken cooking pot can teach us more than a golden ring.

M: What's the hardest part of an excavation?

F: People think it's the rain or the heavy digging, and those can be tiring, of course. But the real challenge is slowness. Every layer of soil has to be measured, photographed and recorded before you remove it, because once it's gone, it's gone for ever. You can't dig a site twice.

M: How has archaeology changed in recent years?

F: Mostly through technology. We can now scan the ground from the air and see walls and roads buried under a field, so sometimes we know where to dig before we pick up a spade. More volunteers are joining projects too, but unfortunately funding hasn't increased at all.

M: How do you feel when you find something important?

F: People expect me to say excited, and I am. But the feeling I remember most is a kind of connection. I once lifted a small clay lamp and realised that the last person who held it was someone who lived two thousand years ago. It's hard to describe, but it's very moving.

M: What do you think about private collectors who buy ancient objects?

F: It worries me. Some say it brings money into the field, but an object taken without any record loses most of its story. We no longer know where it was found or what lay next to it. That information is often more valuable than the object.

M: What advice would you give to someone who'd like to become an archaeologist?

F: Join a local dig as a volunteer for a week before you decide on a degree. Some people realise it's not for them, and that's useful to know. Languages are helpful, and photography skills too, but neither is essential to start.`,
    items: [
      { kind: "choice", n: 1, prompt: "What made Priya interested in archaeology?", options: ["finding an old coin as a child", "history lessons at school", "a visit to a museum with her teacher"], answer: 0, explanation: "В восемь лет она нашла монету в саду дедушки и бабушки. Уроки истории были скучными." },
      { kind: "choice", n: 2, prompt: "What does Priya say about most archaeological finds?", options: ["They are very valuable.", "They show how ordinary people lived.", "They are too fragile to move."], answer: 1, explanation: "Большинство находок — обломки посуды и кости, но они рассказывают о повседневной жизни: «A broken cooking pot can teach us more than a golden ring»." },
      { kind: "choice", n: 3, prompt: "What does Priya find most challenging about excavation?", options: ["working in bad weather", "the heavy physical work", "recording everything carefully"], answer: 2, explanation: "Погода и тяжёлая работа утомляют, но главное — медлительность: каждый слой нужно измерить и сфотографировать, «you can't dig a site twice»." },
      { kind: "choice", n: 4, prompt: "What has changed most in archaeology recently?", options: ["Technology can show sites before digging.", "More money is available for research.", "Fewer volunteers are taking part."], answer: 0, explanation: "С воздуха можно увидеть стены под полем. Волонтёров стало больше, а финансирование не выросло." },
      { kind: "choice", n: 5, prompt: "What does Priya remember most about finding important objects?", options: ["her fear of breaking them", "her wish to tell her colleagues", "a feeling of connection with the past"], answer: 2, explanation: "Больше всего ей запомнилось чувство связи с человеком, державшим лампу две тысячи лет назад." },
      { kind: "choice", n: 6, prompt: "What is Priya's opinion of private collectors?", options: ["They help to pay for excavations.", "They destroy useful information.", "They do no harm if they keep records."], answer: 1, explanation: "Предмет без записи места находки теряет свою историю: эта информация часто ценнее самого предмета." },
      { kind: "choice", n: 7, prompt: "What advice does Priya give to future archaeologists?", options: ["Volunteer on a dig first.", "Learn several languages.", "Study photography."], answer: 0, explanation: "Сначала на неделю присоединиться к раскопкам волонтёром. Языки и фотография полезны, но не обязательны." },
    ],
  },
  {
    ...P4_BASE,
    slug: "listening-part-4-t5",
    test: 5,
    title: "On two wheels",
    summary: "Интервью с профессиональным велогонщиком, 7 вопросов",
    instruction: "Вы услышите интервью с профессиональным велогонщиком Томом Хардингом. Для каждого вопроса выберите лучший ответ (A, B или C).",
    script: `F: My guest today is Tom Harding, a professional cyclist who has competed in races across Europe. Tom, how did it all begin?

M: I used to watch big races on television as a boy, but I never imagined I could do it myself. The real start was much more ordinary. There was no bus from our village to my school, so I cycled twenty kilometres there and back every day. By fifteen I was quicker than the older boys at the local club, and they invited me to join.

F: Training must take up most of your life. What's it really like?

M: People think more is always better. It isn't. When I was twenty-two, I rode six hours a day and ended up injured for months. I do hard sessions, of course, but now I know that rest is where you actually become stronger. Sleeping and eating properly is as important as riding.

F: What has been the lowest point in your career?

M: Everyone expects me to say a crash. I did break my collarbone once, and it hurt, but I was back on the bike in two months. The worst time was after a season in which nothing went right. I lost all my motivation and seriously thought about stopping. It took a long conversation with my coach to turn that around.

F: Cycling seems like an individual sport, but you ride for a team. How do you feel about that?

M: People often tell me I should be riding for my own glory. I used to think so too. But I've spent years protecting my team leader from the wind and helping him to win, and I've come to love it. When my captain crosses the line first, I feel proud, and I don't feel I've lost out.

F: Cyclists now use a lot of technology: power meters, computers, data. Is that a good thing?

M: It's useful. Some people say it makes the sport less fair, because rich teams can afford better equipment, and that's a fair point. But my own view is that data is just a guide. In the end I trust how my legs feel, and that has rarely let me down.

F: You also cycle in towns and cities. What's that like?

M: Honestly, riding in traffic frightens me more than racing downhill at seventy kilometres an hour. Some cyclists ignore red lights, which doesn't help us. But the real problem is the roads. Cities need properly protected cycle lanes, not just a line of paint.

F: What would you like to do when you stop racing?

M: I'm too old to dream about winning the biggest race now. My brother runs a bike shop, so that's already taken care of. What I'd really like is to start a cycling club for children in my home village, so that nobody has to be as lucky as I was to find the sport.`,
    items: [
      { kind: "choice", n: 1, prompt: "How did Tom get into cycling?", options: ["He was inspired by watching races on television.", "He rode a long way to school every day.", "A local club invited him to join as a child."], answer: 1, explanation: "Из-за отсутствия автобуса он ездил в школу по 20 км. Клуб пригласил его в 15 лет, а телевизор не вдохновил на карьеру." },
      { kind: "choice", n: 2, prompt: "What has Tom learnt about training?", options: ["Rest is as important as riding.", "Training for six hours a day is the best way to improve.", "Hard sessions should be avoided."], answer: 0, explanation: "Из-за шести часов в день он получил травму и понял: «rest is where you actually become stronger». Тяжёлые тренировки он тоже делает." },
      { kind: "choice", n: 3, prompt: "What was the lowest point of Tom's career?", options: ["a serious crash", "losing an important race", "losing his motivation"], answer: 2, explanation: "Перелом ключицы зажил за два месяца, а самым плохим был сезон, после которого он потерял мотивацию и думал бросить спорт." },
      { kind: "choice", n: 4, prompt: "How does Tom feel about riding for a team?", options: ["He would prefer to compete alone.", "He often argues with his teammates.", "He is happy when his team leader wins."], answer: 2, explanation: "Раньше он думал иначе, но теперь любит помогать капитану: «When my captain crosses the line first, I feel proud»." },
      { kind: "choice", n: 5, prompt: "What does Tom say about technology in cycling?", options: ["It has made racing unfair.", "It helps, but he relies on his own feelings.", "It takes his attention away from racing."], answer: 1, explanation: "Данные — лишь подсказка, а он доверяет ощущениям. Мнение о несправедливости он признаёт, но не разделяет." },
      { kind: "choice", n: 6, prompt: "What does Tom say about cycling in cities?", options: ["Safer cycle lanes are needed.", "Cyclists are mostly to blame for accidents.", "Cycling to work is not realistic."], answer: 0, explanation: "«Cities need properly protected cycle lanes». Нарушения со стороны велосипедистов он упоминает, но называет главной проблемой дороги." },
      { kind: "choice", n: 7, prompt: "What does Tom want to do after he stops racing?", options: ["win a major race", "open a bike shop", "start a cycling club for children"], answer: 2, explanation: "Победа уже нереальна, магазин есть у брата, а сам он хочет создать клуб для детей в родной деревне." },
    ],
  },
];
