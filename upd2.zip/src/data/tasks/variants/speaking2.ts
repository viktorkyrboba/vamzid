import type { SpeakingTask } from "../types";

const instruction =
  "Сравните две картинки и ответьте на вопрос над ними. Говорите около минуты без пауз. Затем коротко ответьте на вопрос, который на экзамене задают второму кандидату.";

const tips = [
  "Не описывайте каждую картинку по отдельности — сравнивайте: In the first picture…, whereas in the second…",
  "Отвечайте на вопрос над картинками, а не только перечисляйте, что на них видно.",
  "Используйте модальные глаголы для предположений: They might be…, It could be that…",
  "Заполняйте всю минуту: если мысль закончилась, добавьте сравнение или личный пример.",
];

function make(
  test: 2 | 3 | 4 | 5,
  title: string,
  summary: string,
  intro: string,
  question: string,
  images: [string, string],
  followText: string,
  followQuestion: string,
): SpeakingTask {
  return {
    kind: "speaking",
    slug: `speaking-part-2-t${test}`,
    test,
    skill: "speaking",
    paper: "Speaking",
    part: "Part 2",
    type: "Long turn",
    title,
    summary,
    instruction,
    minutes: 3,
    stages: [
      { label: "Part 2", text: intro, question, images, seconds: 60 },
      { label: "Part 2", text: followText, question: followQuestion, images, seconds: 30 },
    ],
    tips,
  };
}

export const speakingPart2Tests: SpeakingTask[] = [
  make(
    2,
    "Celebrating in different ways",
    "Сравнение двух картинок: праздник дома и на улице, минута монолога и короткий ответ",
    "Here are two pictures. They show people celebrating in different ways. Compare the pictures, and say how you think the people are feeling.",
    "How are the people feeling?",
    ["celebrate-home", "celebrate-street"],
    "Which of these celebrations would you prefer to go to? Why?",
    "Which of these celebrations would you prefer to go to?",
  ),
  make(
    3,
    "Doing sport in different ways",
    "Сравнение двух картинок: командный и индивидуальный спорт, минута монолога и короткий ответ",
    "Here are two pictures. They show people doing sport in different ways. Compare the pictures, and say what you think the people enjoy about doing sport in these ways.",
    "What do the people enjoy about doing sport in these ways?",
    ["sport-team", "sport-solo"],
    "Which of these kinds of sport would you prefer to do? Why?",
    "Which of these kinds of sport would you prefer to do?",
  ),
  make(
    4,
    "Travelling in different ways",
    "Сравнение двух картинок: поездка на поезде и на велосипеде, минута монолога и короткий ответ",
    "Here are two pictures. They show people travelling in different ways. Compare the pictures, and say what the advantages of travelling in these ways might be.",
    "What might be the advantages of travelling in these ways?",
    ["travel-train", "travel-bike"],
    "Which of these ways of travelling would you prefer? Why?",
    "Which of these ways of travelling would you prefer?",
  ),
  make(
    5,
    "Working in different places",
    "Сравнение двух картинок: работа в офисе и в кафе, минута монолога и короткий ответ",
    "Here are two pictures. They show people working in different places. Compare the pictures, and say why you think the people have chosen to work in these places.",
    "Why have the people chosen to work in these places?",
    ["work-office", "work-cafe"],
    "Which of these places would you prefer to work in? Why?",
    "Which of these places would you prefer to work in?",
  ),
];
